#!/usr/bin/env python3
import sys
import math
import json
import time
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Imu
from std_msgs.msg import Empty, String, Float32MultiArray

from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QGroupBox, QPushButton, QSlider, QLabel, QGridLayout, QTextEdit,
                             QDoubleSpinBox)
from PyQt5.QtCore import Qt, QTimer


def quaternion_to_euler(x, y, z, w):
    siny_cosp = 2 * (w * z + x * y)
    cosy_cosp = 1 - 2 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)
    return yaw


class EdgeConsoleNode(Node):
    def __init__(self):
        super().__init__("edge_console_node")
        # 机器人运动（仅保留转向最佳角度等内部使用，不再有手动控制）
        self.pub_cmd_vel = self.create_publisher(Twist, "/cmd_vel", 10)
        self.sub_imu = self.create_subscription(Imu, "/imu/data_raw", self.imu_callback, 10)
        # 单次射频采集
        self.capture_pub = self.create_publisher(Empty, '/start_collect_iq', 10)
        self.result_sub = self.create_subscription(String, '/signals_detected', self.detection_callback, 10)
        # 启动/停止全向追踪
        self.tracking_pub = self.create_publisher(Empty, '/start_source_tracking', 10)
        self.tracking_stop_pub = self.create_publisher(Empty, '/stop_source_tracking', 10)
        # 启动定向扫描
        self.scan_trigger_pub = self.create_publisher(Float32MultiArray, '/start_scan_angles', 10)
        # 扫描/追踪最终结果订阅
        self.tracking_result_sub = self.create_subscription(
            String, '/all_direction_signal_detecting_result', self.tracking_result_callback, 10
        )

        # 视觉跟随启停发布器（保留供内部或外部使用）
        self.vis_track_start_pub = self.create_publisher(Empty, "/start_visual_tracking", 10)
        self.vis_track_stop_pub = self.create_publisher(Empty, "/stop_visual_tracking", 10)

        # 订阅 YOLO 结果与视觉跟随状态（用于左侧调试信息）
        self.yolo_result_sub = self.create_subscription(
            String, '/yolo_inference_results', self.yolo_result_callback, 10
        )
        self.vis_state_sub = self.create_subscription(
            String, '/visual_tracking_state', self.vis_state_callback, 10
        )
        self.scan_state_sub = self.create_subscription(
            String, '/signal_source_scan_state', self.scan_state_callback, 10
        )
        self.tracking_state_sub = self.create_subscription(
            String, '/signal_source_tracking_state', self.tracking_controller_state_callback, 10
        )

        self.yaw_angle = 0.0
        self.collect_start_time = 0.0
        self.result_text = "等待启动采集"
        self.tracking_result_text = "等待启动追踪或定向扫描"
        self.yolo_result_text = "暂无YOLO推理结果"
        self.vis_state_text = "视觉跟随状态：未知"
        self.scan_state_text = "扫描节点状态：未知"
        self.tracking_ctrl_state_text = "追踪控制器状态：未知"

        # 存储扫描得到的最佳角度（用于转向功能）
        self.best_signal_angle = None
        self.best_signal_power = -100.0

        # 角度对准控制参数（转向最佳角度用）
        self.ANGLE_TOLERANCE = 2.0
        self.MAX_ANG_SPEED = 0.4
        self.KP_LARGE = 0.03
        self.KP_MID = 0.02
        self.KP_SMALL = 0.01
        self.is_turning_to_best = False
        self.turn_target_angle = 0.0
        self.turn_stable_start_time = None  # 对准稳定计时

        self.app = None
        self.ui = None
        self.init_ui()

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_spin)
        self.timer.start(30)

    def init_ui(self):
        self.app = QApplication(sys.argv)
        self.ui = SimpleConsoleUI(self)
        self.ui.show()

    def imu_callback(self, msg):
        yaw_rad = quaternion_to_euler(msg.orientation.x, msg.orientation.y, msg.orientation.z, msg.orientation.w)
        self.yaw_angle = math.degrees(yaw_rad)

    def detection_callback(self, msg):
        cost_ms = (time.time() - self.collect_start_time) * 1000
        try:
            data = json.loads(msg.data)
            self.result_text = self.format_result(data, cost_ms)
        except:
            self.result_text = f"数据解析异常\n耗时：{cost_ms:.2f}ms"
        self.ui.show_single_result(self.result_text)

    def format_result(self, data, cost):
        txt = f"===== 单次检测结果 | 总耗时:{cost:.1f}ms =====\n"
        txt += f"检测门限：{data['threshold_db']:.1f} dB\n"
        txt += f"检出信号数：{data['num_detections']}\n"
        if data['num_detections'] == 0:
            txt += "未检测到有效射频信号\n"
        else:
            for idx, sig in enumerate(data["detections"], 1):
                txt += f"{idx}. 频点:{sig['center_freq']/1e6:.2f}MHz 带宽:{sig['bandwidth']/1e3:.1f}kHz 功率:{sig['peak_power_db']:.1f}dB\n"
        return txt

    def yolo_result_callback(self, msg):
        """更新 YOLO 结果文本"""
        try:
            data = json.loads(msg.data)
            nd = data.get("num_detections", 0)
            bt = data.get("best_target")
            txt = f"YOLO 检测数：{nd}\n"
            if bt:
                txt += f"最佳目标：{bt.get('class','?')} "
                txt += f"raw={bt.get('score',0):.2f} "
                txt += f"display={bt.get('display_score',0):.2f} "
                txt += f"位置({bt.get('center_x',0):.0f},{bt.get('center_y',0):.0f})"
            else:
                txt += "无最佳目标"
            self.yolo_result_text = txt
        except:
            self.yolo_result_text = "YOLO结果解析失败"
        self.ui.show_yolo_result(self.yolo_result_text)

    def vis_state_callback(self, msg):
        self.vis_state_text = f"视觉跟随状态：{msg.data}"
        self.ui.show_vis_state(self.vis_state_text)

    def scan_state_callback(self, msg):
        self.scan_state_text = f"扫描节点状态：{msg.data}"
        self.ui.show_scan_state(self.scan_state_text)

    def tracking_controller_state_callback(self, msg):
        self.tracking_ctrl_state_text = f"追踪控制器状态：{msg.data}"
        self.ui.show_tracking_ctrl_state(self.tracking_ctrl_state_text)


    # 系统总体状态显示已移除

    # ---------- 启动全向追踪 ----------
    def start_tracking(self):
        self.get_logger().info("触发信号源全向追踪")
        self.tracking_pub.publish(Empty())

    # ---------- 停止追踪（同时停止射频追踪 + 视觉跟踪） ----------
    def stop_tracking(self):
        self.get_logger().info("停止追踪：同时发送射频追踪停止 + 视觉跟踪停止")
        self.tracking_stop_pub.publish(Empty())
        self.vis_track_stop_pub.publish(Empty())
        # 确保机器人停下来
        self.publish_twist(0.0, 0.0)
        self.is_turning_to_best = False
        self.turn_stable_start_time = None

    # ---------- 启动定向扫描 ----------
    def start_scan(self, start_angle, stop_angle):
        msg = Float32MultiArray()
        # 从 UI 获取角速度（父节点 UI 已经绑定）
        ang_speed = getattr(self.ui, 'ang_speed_spin', None)
        if ang_speed is not None:
            ang_val = float(ang_speed.value())
        else:
            ang_val = 0.15
        msg.data = [float(start_angle), float(stop_angle), ang_val]
        self.scan_trigger_pub.publish(msg)
        self.get_logger().info(f"发布定向扫描指令：起始{start_angle}°，终止{stop_angle}°，角速度 {ang_val:.2f}")
        self.tracking_result_text = "定向扫描已启动，等待结果..."
        self.ui.show_tracking_result(self.tracking_result_text)

    def tracking_result_callback(self, msg):
        try:
            data = json.loads(msg.data)
            self.best_signal_angle = data.get("best_angle")
            self.best_signal_power = data.get("best_power", -100.0)
            text = self.format_tracking_result(data)
        except Exception:
            text = f"扫描结果解析失败，原始数据：\n{msg.data}"
            self.best_signal_angle = None
        self.tracking_result_text = text
        self.ui.show_tracking_result(text)

    def format_tracking_result(self, data):
        txt = "===== 全向扫描结果 =====\n"
        best_angle = data.get("best_angle")
        best_power = data.get("best_power")
        angles = data.get("angles", [])
        powers = data.get("peak_powers", [])

        if best_angle is not None and best_power is not None:
            txt += f"最佳方位：{best_angle:.1f}°\n"
            txt += f"最佳信号功率：{best_power:.2f} dB\n"
        else:
            txt += "无最佳信号信息\n"

        if angles and powers and len(angles) == len(powers):
            txt += f"采样点数：{len(angles)}\n"
            txt += "点位结果：\n"
            for idx, (angle, power) in enumerate(zip(angles, powers), start=1):
                txt += f"  {idx}. {angle:.1f}° -> {power:.2f} dB\n"
        elif angles:
            txt += f"采样角度：{len(angles)} 个\n"
            txt += "角度列表：" + ", ".join(f"{a:.1f}°" for a in angles) + "\n"
        else:
            txt += "未包含采样角度数据\n"

        return txt

    # ---------- 转向最佳信号角度（保留功能） ----------
    def turn_to_best_signal_angle(self):
        if self.best_signal_angle is None:
            self.get_logger().warn("暂无扫描最佳角度数据，请先完成定向扫描！")
            return
        self.get_logger().info(f"开始自动转向最佳信号方位：{self.best_signal_angle:.1f}°")
        self.turn_target_angle = self.best_signal_angle
        self.is_turning_to_best = True
        self.turn_stable_start_time = None  # 每次新对准重置稳定计时

    @staticmethod
    def normalize_angle_diff(angle_diff):
        while angle_diff > 180.0:
            angle_diff -= 360.0
        while angle_diff < -180.0:
            angle_diff += 360.0
        return angle_diff

    # ---------- 内部速度发布（无倍率，直接设置） ----------
    def publish_twist(self, lx, az):
        t = Twist()
        t.linear.x = lx
        t.angular.z = az
        self.pub_cmd_vel.publish(t)

    def start_single_collect(self):
        self.collect_start_time = time.time()
        self.capture_pub.publish(Empty())

    def get_yaw(self):
        return round(self.yaw_angle, 1)

    def update_spin(self):
        rclpy.spin_once(self, timeout_sec=0.001)
        self.ui.update_yaw()

        # 转向最佳角度逻辑（带0.5s稳定）
        if self.is_turning_to_best:
            angle_error = self.normalize_angle_diff(
                self.turn_target_angle - self.yaw_angle
            )
            if abs(angle_error) <= self.ANGLE_TOLERANCE:
                if self.turn_stable_start_time is None:
                    self.turn_stable_start_time = time.time()
                    self.publish_twist(0.0, 0.0)
                    self.get_logger().info(
                        f"进入最佳角度容差范围（误差 {angle_error:.1f}°），开始稳定计时0.5s..."
                    )
                elif time.time() - self.turn_stable_start_time >= 0.5:
                    self.publish_twist(0.0, 0.0)
                    self.is_turning_to_best = False
                    self.turn_stable_start_time = None
                    self.get_logger().info(
                        f"已对准最佳信号角度 {self.turn_target_angle:.1f}°（稳定0.5s确认），停止自转"
                    )
                    return
                # 稳定计时中，保持静止
                self.publish_twist(0.0, 0.0)
                return
            else:
                # 误差超出容差，重置稳定计时
                self.turn_stable_start_time = None

                abs_err = abs(angle_error)
                if abs_err >= 30.0:
                    kp = self.KP_LARGE
                elif abs_err >= 10.0:
                    kp = self.KP_MID
                else:
                    kp = self.KP_SMALL

                angular_vel = kp * angle_error
                angular_vel = max(-self.MAX_ANG_SPEED, min(self.MAX_ANG_SPEED, angular_vel))
                self.publish_twist(0.0, angular_vel)

    def run_app(self):
        return self.app.exec_()


class SimpleConsoleUI(QMainWindow):
    def __init__(self, node: EdgeConsoleNode):
        super().__init__()
        self.node = node
        self.setWindowTitle("电磁防控调试控制台")
        self.resize(1050, 800)
        main_wid = QWidget()
        self.setCentralWidget(main_wid)
        main_layout = QHBoxLayout(main_wid)

        # ========== 左侧：调试信息（YOLO + 视觉状态 + 航向角） ==========
        left_box = QGroupBox("调试信息")
        left_layout = QVBoxLayout(left_box)

        # 航向角
        self.yaw_label = QLabel(f"航向角：{self.node.get_yaw()} °")
        left_layout.addWidget(self.yaw_label)

        # 视觉跟随状态
        self.vis_state_label = QLabel("视觉跟随状态：未知")
        left_layout.addWidget(self.vis_state_label)

        self.scan_state_label = QLabel("扫描节点状态：未知")
        left_layout.addWidget(self.scan_state_label)

        self.tracking_ctrl_state_label = QLabel("追踪控制器状态：未知")
        left_layout.addWidget(self.tracking_ctrl_state_label)

        # （已移除系统总体状态显示）

        # YOLO 推理结果
        left_layout.addWidget(QLabel("YOLO 推理结果："))
        self.yolo_result_edit = QTextEdit()
        self.yolo_result_edit.setReadOnly(True)
        self.yolo_result_edit.setPlaceholderText("YOLO推理结果在此显示")
        left_layout.addWidget(self.yolo_result_edit)

        left_layout.addStretch()
        main_layout.addWidget(left_box)

        # ========== 右侧：射频采集、信号追踪 ==========
        right_box = QGroupBox("射频采集与信号追踪")
        right_layout = QVBoxLayout(right_box)

        # ---------- 扫描角度设置行 ----------
        angle_layout = QHBoxLayout()
        angle_layout.addWidget(QLabel("起始角度："))
        self.start_angle_spin = QDoubleSpinBox()
        self.start_angle_spin.setRange(0.0, 360.0)
        self.start_angle_spin.setValue(0.0)
        self.start_angle_spin.setSuffix("°")
        self.start_angle_spin.setDecimals(1)
        angle_layout.addWidget(self.start_angle_spin)

        angle_layout.addWidget(QLabel("终止角度："))
        self.stop_angle_spin = QDoubleSpinBox()
        self.stop_angle_spin.setRange(0.0, 360.0)
        self.stop_angle_spin.setValue(360.0)
        self.stop_angle_spin.setSuffix("°")
        self.stop_angle_spin.setDecimals(1)
        angle_layout.addWidget(self.stop_angle_spin)
        right_layout.addLayout(angle_layout)

        # 角速度输入（单位 rad/s）
        speed_layout = QHBoxLayout()
        speed_layout.addWidget(QLabel("角速度："))
        self.ang_speed_spin = QDoubleSpinBox()
        self.ang_speed_spin.setRange(0.01, 2.0)
        self.ang_speed_spin.setValue(0.15)
        self.ang_speed_spin.setDecimals(2)
        self.ang_speed_spin.setSuffix(" rad/s")
        speed_layout.addWidget(self.ang_speed_spin)
        right_layout.addLayout(speed_layout)

        # ---------- 按钮行：四个功能按钮 ----------
        btn_row = QHBoxLayout()
        single_btn = QPushButton("单次采集分析")
        single_btn.clicked.connect(self.node.start_single_collect)

        track_btn = QPushButton("启动全向信号源追踪")
        track_btn.setStyleSheet("background-color: #ff9500; color: white;")
        track_btn.clicked.connect(self.node.start_tracking)

        scan_btn = QPushButton("启动定向扫描")
        scan_btn.setStyleSheet("background-color: #ff9500; color: white;")
        scan_btn.clicked.connect(self.on_start_scan)

        turn_best_btn = QPushButton("对准最佳信号角度")
        turn_best_btn.setStyleSheet("background-color: #28a745; color: white;")
        turn_best_btn.clicked.connect(self.node.turn_to_best_signal_angle)

        stop_btn = QPushButton("停止追踪")
        stop_btn.setStyleSheet("background-color: #dc3545; color: white;")
        stop_btn.clicked.connect(self.node.stop_tracking)

        btn_row.addWidget(single_btn)
        btn_row.addWidget(track_btn)
        btn_row.addWidget(scan_btn)
        btn_row.addWidget(turn_best_btn)
        btn_row.addWidget(stop_btn)
        right_layout.addLayout(btn_row)

        # 单次采集结果
        right_layout.addWidget(QLabel("单次采集结果："))
        self.single_result_edit = QTextEdit()
        self.single_result_edit.setReadOnly(True)
        self.single_result_edit.setPlaceholderText("单次采集结果在此显示")
        self.single_result_edit.setFixedHeight(120)
        right_layout.addWidget(self.single_result_edit)

        # 追踪/扫描结果
        right_layout.addWidget(QLabel("追踪/扫描结果："))
        self.tracking_result_edit = QTextEdit()
        self.tracking_result_edit.setReadOnly(True)
        self.tracking_result_edit.setPlaceholderText("启动追踪或定向扫描后，最终结果在此显示")
        right_layout.addWidget(self.tracking_result_edit)

        main_layout.addWidget(right_box)

    def on_start_scan(self):
        start = self.start_angle_spin.value()
        stop = self.stop_angle_spin.value()
        self.node.start_scan(start, stop)

    def update_yaw(self):
        self.yaw_label.setText(f"航向角：{self.node.get_yaw()} °")

    def show_single_result(self, text):
        self.single_result_edit.setPlainText(text)

    def show_tracking_result(self, text):
        self.tracking_result_edit.setPlainText(text)

    def show_yolo_result(self, text):
        self.yolo_result_edit.setPlainText(text)

    def show_vis_state(self, text):
        self.vis_state_label.setText(text)

    def show_scan_state(self, text):
        self.scan_state_label.setText(text)

    def show_tracking_ctrl_state(self, text):
        self.tracking_ctrl_state_label.setText(text)


def main(args=None):
    rclpy.init(args=args)
    console_node = EdgeConsoleNode()
    console_node.run_app()
    console_node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
