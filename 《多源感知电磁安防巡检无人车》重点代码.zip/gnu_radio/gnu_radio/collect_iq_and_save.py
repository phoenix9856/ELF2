#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import time
import threading
import rclpy
from rclpy.node import Node
from std_msgs.msg import Empty
from gnuradio import blocks, gr, uhd


class CollectIqAndSaveNode(Node):
    """
    单流图、按需启停模式：
    - USRP源 -> head -> file_sink 固定连线，永不改变
    - 每次触发：停主流图 → 冲洗硬件 → 重置 head 和文件 → 启主流图
    - 完成后自动停止并触发检测话题
    """

    def __init__(self):
        super().__init__("collect_iq_and_save_node")

        # ---------- 采集参数 ----------
        self.samp_rate = 4e6
        self.center_freq = 2240e6
        self.gain = 40
        self.antenna = "RX2"
        self.save_file = "/home/elf/wheeltec_ros2/src/gnu_radio/iq_data/usrp_iq_data.raw"
        self.collect_points = 200000
        self.flush_samples = 50000

        # ---------- 内部状态 ----------
        self.is_collecting = False       # 是否正在采集（对外）
        self._tb_started = False         # 流图是否已启动
        self._lock = threading.Lock()

        # ---------- 构建固定流图 ----------
        self.tb = gr.top_block()
        self.usrp_src = uhd.usrp_source(
            ",",
            uhd.stream_args(
                cpu_format="fc32",
                args='num_recv_frames=4096',
                channels=[0],
            ),
        )
        self.usrp_src.set_samp_rate(self.samp_rate)
        self.usrp_src.set_center_freq(self.center_freq, 0)
        self.usrp_src.set_antenna(self.antenna, 0)
        self.usrp_src.set_gain(self.gain, 0)

        self.head = blocks.head(gr.sizeof_gr_complex, self.collect_points)
        self.file_sink = blocks.file_sink(gr.sizeof_gr_complex, self.save_file, False)
        self.file_sink.set_unbuffered(False)

        # 一次连线，永不修改
        self.tb.connect(self.usrp_src, self.head, self.file_sink)
        self.get_logger().info("USRP硬件初始化完毕，流图已构建")

        # ---------- ROS 接口 ----------
        self.capture_sub = self.create_subscription(
            Empty, '/start_collect_iq', self.capture_callback, 10
        )
        self.detect_trigger_pub = self.create_publisher(Empty, '/start_detect_signals', 10)
        self.get_logger().info("等待采集触发话题 /start_collect_iq")

    # ---------------------- 内部工具 ----------------------
    def _stop_tb(self):
        """安全停止流图（无论当前是否在运行）"""
        if self._tb_started:
            try:
                self.tb.stop()
                self.tb.wait()
            except Exception as e:
                self.get_logger().warn(f"停止流图时异常: {e}")
            self._tb_started = False

    def _start_tb(self):
        """启动流图并记录状态"""
        if not self._tb_started:
            self.tb.start()
            self._tb_started = True

    def _flush_hardware(self):
        """
        丢弃硬件缓存中的陈旧样本。
        前提：主流图已停止（USRP空闲）
        """
        flush_head = blocks.head(gr.sizeof_gr_complex, self.flush_samples)
        flush_sink = blocks.null_sink(gr.sizeof_gr_complex)
        flush_tb = gr.top_block()
        flush_tb.connect(self.usrp_src, flush_head, flush_sink)

        self.get_logger().info(f"冲洗硬件缓冲区，丢弃 {self.flush_samples} 个样本...")
        flush_tb.start()
        flush_tb.wait()
        flush_tb.stop()
        del flush_tb

    # ---------------------- 采集逻辑 ----------------------
    def capture_callback(self, msg):
        """收到 /start_collect_iq 触发"""
        if not self._lock.acquire(blocking=False):
            self.get_logger().warn("上一次采集尚未结束，忽略本次触发")
            return

        try:
            if self.is_collecting:
                self.get_logger().warn("正在采集中，忽略重复触发")
                return

            # 1. 确保主流图完全停止
            self._stop_tb()

            # 2. 删除旧文件
            if os.path.exists(self.save_file):
                os.remove(self.save_file)
                self.get_logger().debug("已删除旧数据文件")

            # 3. 冲洗硬件缓冲区（此时 USRP 空闲）
            self._flush_hardware()

            # 4. 重置采集模块
            self.head.reset()                        # head 归零
            self.head.set_length(self.collect_points) # 重新设置点数
            self.file_sink.open(self.save_file)      # 绑定新文件

            # 5. 启动流图
            self.is_collecting = True
            collect_time_s = self.collect_points / self.samp_rate
            self.get_logger().info(
                f"\n【开始采集】\n"
                f"中心频率：{self.center_freq/1e6:.2f} MHz\n"
                f"采样率：{self.samp_rate/1e6:.2f} MSps\n"
                f"接收带宽：{self.samp_rate/1e6:.2f} MHz\n"
                f"采集总点数：{self.collect_points:,} 点\n"
                f"单次采集时长：{collect_time_s:.3f} 秒"
            )
            self._start_tb()

            # 6. 后台线程等待采集完成
            self._completion_thread = threading.Thread(target=self._on_collection_finished)
            self._completion_thread.start()

        except Exception as e:
            self.get_logger().error(f"采集启动失败: {e}")
            self.is_collecting = False
        finally:
            self._lock.release()

    def _on_collection_finished(self):
        """后台线程：等待 head 切段自动停止，然后触发后续"""
        try:
            self.tb.wait()   # 阻塞直到 head 输出完指定点数
            self.get_logger().info("采集完成")
        except Exception as e:
            self.get_logger().error(f"采集过程异常: {e}")
        finally:
            # 无论如何都停止流图并重置标志
            self._stop_tb()
            self.is_collecting = False

            # 自动触发信号检测
            self.get_logger().info("自动触发信号检测 /start_detect_signals")
            self.detect_trigger_pub.publish(Empty())

    # ---------------------- 节点销毁 ----------------------
    def destroy_node(self):
        self.get_logger().info("正在关闭采集节点...")
        if self._completion_thread and self._completion_thread.is_alive():
            self._completion_thread.join(timeout=1.0)
        self._stop_tb()
        self.get_logger().info("采集流图已安全停止")
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = CollectIqAndSaveNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()