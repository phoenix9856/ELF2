#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import json
import numpy as np
from scipy.signal import stft
import rclpy
from rclpy.node import Node
from std_msgs.msg import Empty, String

# ===================== 全局配置参数 =====================
FILE_PATH = "/home/elf/wheeltec_ros2/src/gnu_radio/iq_data/usrp_iq_data.raw"
SAMPLE_RATE = 4e6
CENTER_FREQ = 2.24e9
ANALYSIS_DURATION = 0.05
STFT_SEGMENT = 1024
STFT_OVERLAP = 512
THRESHOLD_DB = -60.0
TOP_N_DETECTIONS = None
# =======================================================


# 此节点订阅话题/start_detect_signals，发布话题/signals_detected
class AnalyzeIqForDetectionNode(Node):
    def __init__(self):
        super().__init__("analyze_iq_for_detection_node")

        # 订阅全局检测触发话题
        self.capture_sub = self.create_subscription(
            Empty,
            '/start_detect_signals',
            self.detect_callback,
            10
        )
        # 发布检测结果（JSON字符串）
        self.result_pub = self.create_publisher(String, '/signals_detected', 10)


    def detect_callback(self, msg):
        """收到触发消息后执行一次IQ分析并发布结果"""
        self.get_logger().info("收到检测触发命令，开始分析原始IQ数据文件...")
        result_json = self.run_stft_analysis()
        if result_json is not None:
            self.result_pub.publish(String(data=result_json))
            self.get_logger().info("检测结果已发布")
        else:
            self.get_logger().warn("分析未产生有效结果，不发布空消息")



    def run_stft_analysis(self):
        if not os.path.exists(FILE_PATH):
            self.get_logger().error(f"IQ数据文件不存在：{FILE_PATH}")
            return None

        try:
            iq_data = np.fromfile(FILE_PATH, dtype=np.complex64)
            num_samples = int(ANALYSIS_DURATION * SAMPLE_RATE)
            if len(iq_data) < num_samples:
                self.get_logger().warn(f"文件样本数({len(iq_data)})不足分析所需({num_samples})，将使用全部数据")
                iq_data_used = iq_data
            else:
                iq_data_used = iq_data[:num_samples]

            self.get_logger().info(
                f"截取分析时长：{len(iq_data_used)/SAMPLE_RATE:.2f}s，有效样本数：{len(iq_data_used)}"
            )

            f, t_stft, Zxx = stft(
                iq_data_used, fs=SAMPLE_RATE,
                nperseg=STFT_SEGMENT, noverlap=STFT_OVERLAP,
                return_onesided=False
            )
            f = np.fft.fftshift(f) + CENTER_FREQ
            Zxx = np.fft.fftshift(Zxx, axes=0)
            Zxx_dB = 10 * np.log10(np.abs(Zxx) ** 2 + 1e-12)

            detections, used_threshold, noise_power_db = self.detect_signals_from_stft(
                f, t_stft, Zxx_dB, threshold_db=THRESHOLD_DB
            )

            if detections and TOP_N_DETECTIONS is not None:
                detections = sorted(detections, key=lambda x: x['peak_power_db'], reverse=True)[:TOP_N_DETECTIONS]

            result_dict = {
                "threshold_db": used_threshold,
                "noise_power_db": noise_power_db,
                "num_detections": len(detections),
                "detections": detections
            }
            result_json = json.dumps(result_dict, indent=2)

            if detections:
                self.get_logger().info(
                    f"成功检测到 {len(detections)} 组射频信号 | 检测门限：{used_threshold:.2f} dB "
                    f"| 噪声功率：{noise_power_db:.2f} dB"
                )
                for idx, d in enumerate(detections, 1):
                    self.get_logger().info(
                        f"[{idx}] 中心频点:{d['center_freq']/1e6:.3f} MHz "
                        f"信号带宽:{d['bandwidth']/1e3:.3f} kHz "
                        f"峰值功率:{d['peak_power_db']:.2f} dB"
                    )
            else:
                self.get_logger().info(
                    f"未检出有效射频信号，当前检测阈值 {used_threshold:.2f} dB，"
                    f"噪声功率 {noise_power_db:.2f} dB"
                )

            self.get_logger().info("单次分析任务执行完毕")
            return result_json

        except Exception as e:
            self.get_logger().error(f"分析过程出现异常：{e}")
            return None
        
    def detect_signals_from_stft(self, f, t, Zxx_dB, threshold_db=None, min_bandwidth_hz=None):
        """
        基于 STFT 功率谱检测信号，同时估算噪声功率。
        返回: (detections, threshold_db, noise_power_db)
        """
        power_time_max = np.max(Zxx_dB, axis=1)      # 每个频率点的最大功率
        power_time_avg = np.mean(Zxx_dB, axis=1)     # 每个频率点的平均功率
        df = np.mean(np.diff(f)) if len(f) > 1 else 1.0

        # 估算噪声功率（取平均功率的中值作为本底噪声）
        noise_floor = np.median(power_time_avg)

        if min_bandwidth_hz is None:
            min_bandwidth_hz = max(df, 1.0)
        if threshold_db is None:
            threshold_db = noise_floor + 6.0   # 若未指定阈值，使用噪声基线上浮6dB

        mask = power_time_max > threshold_db
        detections = []
        i = 0
        N = len(mask)
        while i < N:
            if not mask[i]:
                i += 1
                continue
            j = i
            while j + 1 < N and mask[j + 1]:
                j += 1
            start_f = f[i]
            end_f = f[j]
            bw = abs(end_f - start_f)
            if bw >= min_bandwidth_hz:
                seg_indices = slice(i, j + 1)
                seg_freqs = f[seg_indices]
                seg_powers = power_time_max[seg_indices]
                weights = seg_powers - np.min(seg_powers) + 1e-6
                center = np.sum(seg_freqs * weights) / np.sum(weights)
                peak_power = float(np.max(seg_powers))
                detections.append({
                    'center_freq': float(center),
                    'bandwidth': float(bw),
                    'peak_power_db': float(peak_power),
                    'start_freq': float(start_f),
                    'end_freq': float(end_f)
                })
            i = j + 1
        return detections, float(threshold_db), float(noise_floor)

def main(args=None):
    rclpy.init(args=args)
    node = AnalyzeIqForDetectionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()