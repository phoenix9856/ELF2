from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
import os
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    ws_dir = "/home/elf/wheeltec_ros2"

    # 1. 包含底盘启动launch文件
    robot_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(ws_dir, "src/turn_on_wheeltec_robot/launch/turn_on_wheeltec_robot.launch.py")
        )
    )

    # 2. GPS 驱动 (NMEA串口 → /gps/fix)
    nmea_serial_node = Node(
        package="nmea_navsat_driver",
        executable="nmea_serial_driver",
        output="screen",
        parameters=[{
            "port": "/dev/ttyACM2",
            "baud": 115200,
        }],
    )

    # 2b. GPS 路径发布 (NMEA → 机器人坐标系)
    gps_path_node = Node(
        package="wheeltec_gps_driver",
        executable="gps_path",
        output="screen",
        remappings=[("/gps_topic", "/gps/fix")],
    )

    # 3. 包含YOLO视觉一键启动launch文件
    yolo_visual_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('yolo_visual_tracker'),
                'launch',
                'yolo_visual_tracking.launch.py'
            )
        )
    )

    # 3. 电磁IQ采集节点
    collect_iq_node = Node(
        package="gnu_radio",
        executable="collect_iq_and_save",
        output="screen",
        respawn=True,
        respawn_delay=0.1,
    )

    # 3. IQ数据分析检测节点
    analyze_iq_node = Node(
        package="signal_processing",
        executable="analyze_iq_for_detection",
        output="screen"
    )

    # 4. 全向电磁环境扫描节点
    all_dir_scan_node = Node(
        package="signal_source_tracking",
        executable="signal_source_scan",
        name="signal_source_scan_node",
        output="screen"
    )

    # 5. 信号源追踪控制器节点
    track_ctrl_node = Node(
        package="signal_source_tracking",
        executable="tracking_controller",
        name="source_tracking_controller_node",
        output="screen"
    )

    # 6. 边缘控制台节点
    edge_console_node = Node(
        package="edge_console",
        executable="edge_console",
        output="screen"
    )


    return LaunchDescription([
        robot_launch,
        nmea_serial_node,
        gps_path_node,
        yolo_visual_launch,
        collect_iq_node,
        analyze_iq_node,
        all_dir_scan_node,
        track_ctrl_node,
        edge_console_node,
    ])