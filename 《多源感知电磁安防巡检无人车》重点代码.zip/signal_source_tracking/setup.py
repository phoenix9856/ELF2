import os
from glob import glob
from setuptools import find_packages, setup


package_name = 'signal_source_tracking'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # 安装所有 launch 文件到 share 目录
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='elf',
    maintainer_email='elf@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            # 全向信号扫描
            'signal_source_scan = signal_source_tracking.signal_source_scan:main',
            # 追踪控制器
            'tracking_controller = signal_source_tracking.tracking_controller:main',
        ],
    },
)