#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import math
import json
import time
import rclpy
import os
from rclpy.node import Node
from std_msgs.msg import Empty, String, Float32MultiArray
from sensor_msgs.msg import Imu
from geometry_msgs.msg import Twist


class SignalSourceScanNode(Node):
    # ------------------ 状态枚举 ------------------
    STATE_IDLE = 0
    STATE_WAIT_COLLECTOR_READY = 1
    STATE_TURN_TO_START_ANGLE = 2
    STATE_SCANNING = 3
    STATE_SCAN_FINISHED = 4
    STATE_WAIT_COLLECTOR_RECOVERY = 5

    # ------------------ 控制参数 ------------------
    KP_TURN = 0.05
    TURN_KP_SMALL = 0.02
    TURN_KP_MID = 0.05
    TURN_KP_LARGE = 0.08
    MAX_ANG_SPEED = 0.4
    SCAN_ANG_SPEED = 0.15
    ANGLE_TOLERANCE = 2.0
    STABLE_TIME = 0.35
    WAIT_BEFORE_NEXT_SAMPLE = 0.4
    COLLECT_TIMEOUT = 1.0
    COLLECTOR_STABLE_WAIT = 5.0

    def __init__(self):
        super().__init__("signal_source_scan_node")

        self.current_state = self.STATE_IDLE
        self.last_state = -1

        self.vision_tracking_state = "IDLE"

        self.current_yaw = 0.0
        self.scan_start_angle = 0.0
        self.scan_stop_unwrapped = 0.0
        self.pending_sample_yaw = None

        self.accumulated_yaw = 0.0
        self.last_yaw_for_accum = 0.0

        self.stable_start_time = 0.0
        self.is_stabilizing = False

        self.waiting_next_sample = False
        self.next_sample_wait_start = 0.0

        self.last_trigger_time = 0.0
        self.recovery_stable_start = 0.0

        self.scan_data_list = []
        self.need_collect_iq = False
        self.signal_result_arrived = False
        self.current_signal_power = -100.0

        # 当前扫描角速度（可由触发者覆盖）
        self.scan_ang_speed = self.SCAN_ANG_SPEED

        self.pending_scan_start = None
        self.pending_scan_stop = None
        self.recovering_from_collector = False

        # ---------- ROS 通信 ----------
        self.imu_sub = self.create_subscription(
            Imu, "/imu/data_raw", self.imu_callback, 10
        )
        self.scan_trigger_sub = self.create_subscription(
            Float32MultiArray, "/start_scan_angles", self.scan_trigger_callback, 10
        )
        self.signal_data_sub = self.create_subscription(
            String, "/signals_detected", self.signal_result_callback, 10
        )
        self.vision_state_sub = self.create_subscription(
            String, "/visual_tracking_state", self.vision_state_callback, 10
        )
        self.track_stop_sub = self.create_subscription(
            Empty, "/stop_source_tracking", self.stop_callback, 10
        )

        self.cmd_vel_pub = self.create_publisher(Twist, "/cmd_vel", 10)
        self.iq_collect_pub = self.create_publisher(Empty, "/start_collect_iq", 10)
        self.scan_final_result_pub = self.create_publisher(
            String, "/all_direction_signal_detecting_result", 10
        )
        self.state_pub = self.create_publisher(String, "/signal_source_scan_state", 10)
        self.last_published_state = None

        self.main_loop_timer = self.create_timer(0.02, self.control_loop)
        self.get_logger().info("扫描节点启动完成（带采集节点崩溃自动恢复 + 视觉状态同步）")

    # ===================== 核心状态机 =====================
    def control_loop(self):
        match self.current_state:
            case self.STATE_IDLE:
                # 初次进入逻辑
                if self.current_state != self.last_state:
                    self.last_state = self.current_state
                    self.get_logger().info("进入空闲待机状态")

            case self.STATE_WAIT_COLLECTOR_READY:
                # 初次进入逻辑
                if self.current_state != self.last_state:
                    self.last_state = self.current_state
                    self.get_logger().info("等待采集节点上线...")
                    self.publish_set_vehicle_speed(0.0, 0.0)

                # 检查采集节点是否上线
                if self.iq_collect_pub.get_subscription_count() > 0:
                    self.get_logger().info("采集节点已就绪，启动扫描")
                    if self.pending_scan_start is not None and self.pending_scan_stop is not None:
                        self._initiate_scan(self.pending_scan_start, self.pending_scan_stop, self.pending_ang_speed)
                        self.pending_scan_start = None
                        self.pending_scan_stop = None
                        self.pending_ang_speed = None
                        self.current_state = self.STATE_TURN_TO_START_ANGLE
                    else:
                        self.get_logger().error("无待执行扫描参数，返回空闲")
                        self.current_state = self.STATE_IDLE

            case self.STATE_TURN_TO_START_ANGLE:
                # 初次进入逻辑
                if self.current_state != self.last_state:
                    self.last_state = self.current_state
                    self.get_logger().info("开始转向扫描起始角度")
                    self.accumulated_yaw = self.scan_start_angle
                    self.last_yaw_for_accum = self.current_yaw
                    self.is_stabilizing = False

                delta = self.normalize_angle_diff(self.current_yaw - self.last_yaw_for_accum)
                self.accumulated_yaw += delta
                self.last_yaw_for_accum = self.current_yaw


                angle_error = self.normalize_angle_diff(
                    self.scan_start_angle - self.current_yaw
                )
                if abs(angle_error) <= self.ANGLE_TOLERANCE:
                    self.publish_set_vehicle_speed(0.0, 0.0)
                    if not self.is_stabilizing:
                        self.stable_start_time = time.time()
                        self.is_stabilizing = True
                        self.get_logger().info("到达扫描起始角度，开始稳定计时...")
                    elif time.time() - self.stable_start_time >= self.STABLE_TIME:
                        self.get_logger().info("已稳定0.35秒，进入连续扫描")
                        self.is_stabilizing = False
                        self.accumulated_yaw = self.scan_start_angle
                        self.last_yaw_for_accum = self.current_yaw
                        self.waiting_next_sample = False
                        self.current_state = self.STATE_SCANNING
                        return
                else:
                    self.is_stabilizing = False
                    abs_err = abs(angle_error)
                    if abs_err >= 30.0:
                        kp = self.TURN_KP_LARGE
                    elif abs_err >= 10.0:
                        kp = self.TURN_KP_MID
                    else:
                        kp = self.TURN_KP_SMALL
                    angular_vel = kp * angle_error
                    angular_vel = max(-self.MAX_ANG_SPEED, min(self.MAX_ANG_SPEED, angular_vel))
                    self.publish_set_vehicle_speed(0.0, angular_vel)

            case self.STATE_SCANNING:
                # 初次进入逻辑
                if self.current_state != self.last_state:
                    if self.recovering_from_collector:
                        self.last_state = self.current_state
                        self.recovering_from_collector = False
                        self.get_logger().info("恢复扫描，继续已有进度")
                        if not self.need_collect_iq and not self.signal_result_arrived and not self.waiting_next_sample:
                            self._safe_trigger_iq_sample()
                    else:
                        self.last_state = self.current_state
                        self.get_logger().info("进入连续扫描状态，开始循环采集IQ")
                        self.accumulated_yaw = self.scan_start_angle
                        self.last_yaw_for_accum = self.current_yaw
                        self.waiting_next_sample = False
                        self._safe_trigger_iq_sample()

                # 累计航向变化量
                delta = self.normalize_angle_diff(self.current_yaw - self.last_yaw_for_accum)
                self.accumulated_yaw += delta
                self.last_yaw_for_accum = self.current_yaw

                # 执行旋转动作（使用触发时指定的角速度）
                self.publish_set_vehicle_speed(0.0, self.scan_ang_speed)

                # 检查采集节点是否崩溃
                if self.need_collect_iq and not self.signal_result_arrived:
                    if time.time() - self.last_trigger_time > self.COLLECT_TIMEOUT:
                        self.get_logger().warn("采集节点超时未响应，扫描暂停，进入等待恢复状态")
                        self.publish_set_vehicle_speed(0.0, 0.0)
                        self.need_collect_iq = False
                        self.signal_result_arrived = False
                        self.recovery_stable_start = 0.0
                        self.current_state = self.STATE_WAIT_COLLECTOR_RECOVERY
                        return

                # 检查是否需要触发下一次采样
                if self.waiting_next_sample:
                    if time.time() - self.next_sample_wait_start >= self.WAIT_BEFORE_NEXT_SAMPLE:
                        self.waiting_next_sample = False
                        self._safe_trigger_iq_sample()
                    return

                # 检查是否已收到采样结果
                if self.signal_result_arrived:
                    self.scan_data_list.append({
                        "angle": self.pending_sample_yaw,
                        "peak_power": self.current_signal_power
                    })
                    self.get_logger().info(
                        f"采样完成：航向 {self.pending_sample_yaw:.1f}°，信号强度 {self.current_signal_power:.2f}dB"
                    )

                    self.signal_result_arrived = False
                    self.need_collect_iq = False
                    self.pending_sample_yaw = None

                    # 如果已完成扫描任务，则停止旋转并发布扫描结果
                    if self.is_scan_task_finish():
                        self.publish_set_vehicle_speed(0.0, 0.0)
                        self.publish_all_scan_result()
                        self.current_state = self.STATE_SCAN_FINISHED
                    #否则，等待下一次采样
                    else:
                        self.waiting_next_sample = True
                        self.next_sample_wait_start = time.time()
                        self.get_logger().info(
                            f"等待 {self.WAIT_BEFORE_NEXT_SAMPLE:.2f}s 后触发下一次采集..."
                        )

            case self.STATE_WAIT_COLLECTOR_RECOVERY:
                # 初次进入逻辑
                if self.current_state != self.last_state:
                    self.last_state = self.current_state
                    self.get_logger().warn("进入崩溃恢复等待状态")
                    self.recovery_stable_start = 0.0

                # 检查采集节点是否恢复上线
                if self.iq_collect_pub.get_subscription_count() > 0:
                    if self.recovery_stable_start == 0.0:
                        self.recovery_stable_start = time.time()
                        self.get_logger().info("采集节点出现，等待5s USRP初始化稳定后恢复扫描")
                    elif time.time() - self.recovery_stable_start >= self.COLLECTOR_STABLE_WAIT:
                        self.get_logger().info("5s已过，USRP初始化稳定，恢复扫描")
                        self.recovering_from_collector = True
                        self.current_state = self.STATE_SCANNING
                        self.last_state = self.STATE_WAIT_COLLECTOR_RECOVERY
                        return
                else:
                    if self.recovery_stable_start != 0.0:
                        self.get_logger().warn("采集节点再次消失，重置等待")
                        self.recovery_stable_start = 0.0

                self.publish_set_vehicle_speed(0.0, 0.0)

            case self.STATE_SCAN_FINISHED:
                if self.current_state != self.last_state:
                    self.last_state = self.current_state
                    self.get_logger().info("扫描完成，返回空闲状态")
                    self.publish_set_vehicle_speed(0.0, 0.0)
                    self.publish_all_scan_result()
                    self.waiting_next_sample = False
                    self.current_state = self.STATE_IDLE

        self._publish_state()


    # ===================== 视觉状态回调 =====================
    def vision_state_callback(self, msg):
        new_state = msg.data.upper()
        if new_state == "TRACKING" and self.vision_tracking_state != "TRACKING":
            self._enter_idle_for_visual_tracking()
        self.vision_tracking_state = new_state

    def stop_callback(self, msg):
        """收到停止指令，立即停止扫描并返回空闲"""
        if self.current_state == self.STATE_IDLE:
            return
        self.get_logger().info("收到停止指令，中止扫描返回空闲")
        self.publish_set_vehicle_speed(0.0, 0.0)
        self.pending_scan_start = None
        self.pending_scan_stop = None
        self.need_collect_iq = False
        self.signal_result_arrived = False
        self.pending_sample_yaw = None
        self.waiting_next_sample = False
        self.current_state = self.STATE_IDLE

    def _enter_idle_for_visual_tracking(self):
        if self.current_state in (
            self.STATE_TURN_TO_START_ANGLE,
            self.STATE_SCANNING,
            self.STATE_WAIT_COLLECTOR_READY,
            self.STATE_WAIT_COLLECTOR_RECOVERY,
        ):
            self.publish_set_vehicle_speed(0.0, 0.0)
            self.pending_scan_start = None
            self.pending_scan_stop = None
            self.need_collect_iq = False
            self.signal_result_arrived = False
            self.pending_sample_yaw = None
            self.waiting_next_sample = False
            self.get_logger().info(
                "【视觉接管】扫描节点直接返回空闲状态，交由视觉控制"
            )
        self.current_state = self.STATE_IDLE


    # ===================== 回调函数 =====================
    def scan_trigger_callback(self, msg):
        if self.vision_tracking_state == "TRACKING":
            self.get_logger().warn("当前视觉正在跟随，拒绝下发射频扫描指令")
            return
        if self.current_state not in (self.STATE_IDLE, self.STATE_SCAN_FINISHED):
            self.get_logger().warn("当前扫描任务未结束，拒绝新扫描指令")
            return
        # 支持两种格式：
        #  - [start, stop]
        #  - [start, stop, ang_speed]
        if len(msg.data) not in (2, 3):
            self.get_logger().error("扫描指令参数错误，期望 [start, stop] 或 [start, stop, ang_speed]")
            return

        if len(msg.data) == 2:
            start_angle, stop_angle = msg.data
            ang_speed = self.SCAN_ANG_SPEED
        else:
            start_angle, stop_angle, ang_speed = msg.data
        self.pending_scan_start = float(start_angle) % 360.0
        raw_stop = float(stop_angle)

        # 角速度优先使用触发参数
        self.pending_ang_speed = float(ang_speed)

        if self.iq_collect_pub.get_subscription_count() == 0:
            self.get_logger().warn("采集节点未就绪，进入等待状态")
            self.pending_scan_stop = raw_stop
            self.publish_set_vehicle_speed(0.0, 0.0)
            self.current_state = self.STATE_WAIT_COLLECTOR_READY
        else:
            self._initiate_scan(self.pending_scan_start, raw_stop, self.pending_ang_speed)
            self.pending_scan_start = None
            self.pending_scan_stop = None
            self.current_state = self.STATE_TURN_TO_START_ANGLE

    def _initiate_scan(self, start_angle, stop_angle, ang_speed=None):
        self.scan_start_angle = start_angle
        raw_stop = stop_angle
        if raw_stop <= self.scan_start_angle:
            raw_stop += 360.0
        self.scan_stop_unwrapped = raw_stop

        self.scan_data_list.clear()
        self.pending_sample_yaw = None
        self.need_collect_iq = False
        self.signal_result_arrived = False
        self.current_signal_power = -100.0
        self.accumulated_yaw = 0.0
        self.last_yaw_for_accum = 0.0
        self.is_stabilizing = False
        self.waiting_next_sample = False
        self.recovery_stable_start = 0.0

        # 设置扫描角速度（触发器可以覆盖）
        if ang_speed is None:
            self.scan_ang_speed = self.SCAN_ANG_SPEED
        else:
            try:
                self.scan_ang_speed = float(ang_speed)
            except Exception:
                self.scan_ang_speed = self.SCAN_ANG_SPEED

        self.get_logger().info(
            f"启动扫描：起始{self.scan_start_angle:.1f}°，终止{raw_stop:.1f}°"
        )

    def signal_result_callback(self, msg):
        if self.current_state != self.STATE_SCANNING:
            return
        try:
            json_data = json.loads(msg.data)
            detect_list = json_data.get("detections", [])
            if detect_list:
                self.current_signal_power = max(
                    d["peak_power_db"] for d in detect_list
                )
            else:
                self.current_signal_power = json_data.get("noise_power_db", -100.0)
            self.signal_result_arrived = True
        except Exception as e:
            self.get_logger().error(f"信号数据解析异常：{str(e)}")
            self.current_signal_power = -100.0
            self.signal_result_arrived = True

    def imu_callback(self, msg):
        yaw = self.quat_to_yaw_deg(
            msg.orientation.x, msg.orientation.y,
            msg.orientation.z, msg.orientation.w
        )
        self.current_yaw = yaw

    # ===================== 采集触发与恢复 =====================
    def _safe_trigger_iq_sample(self):
        if self.iq_collect_pub.get_subscription_count() == 0:
            self.get_logger().warn("采集节点不在线，无法触发采集，进入等待恢复")
            self.publish_set_vehicle_speed(0.0, 0.0)
            self.recovery_stable_start = 0.0
            self.current_state = self.STATE_WAIT_COLLECTOR_RECOVERY
            return
        self.publish_trigger_iq_sample()

    def publish_trigger_iq_sample(self):
        self.pending_sample_yaw = self.current_yaw
        self.need_collect_iq = True
        self.signal_result_arrived = False
        self.last_trigger_time = time.time()
        self.iq_collect_pub.publish(Empty())
        self.get_logger().info(
            f"触发IQ数据采集，采样航向：{self.pending_sample_yaw:.1f}°"
        )

    # ===================== 车辆控制 =====================
    def publish_set_vehicle_speed(self, linear_x, angular_z):
        twist_msg = Twist()
        twist_msg.linear.x = linear_x
        twist_msg.angular.z = angular_z
        self.cmd_vel_pub.publish(twist_msg)

    def publish_scan_final_result(self, result_json):
        self.scan_final_result_pub.publish(String(data=result_json))

    def _publish_state(self):
        state_map = {
            self.STATE_IDLE: "IDLE",
            self.STATE_WAIT_COLLECTOR_READY: "WAIT_COLLECTOR_READY",
            self.STATE_TURN_TO_START_ANGLE: "TURN_TO_START_ANGLE",
            self.STATE_SCANNING: "SCANNING",
            self.STATE_SCAN_FINISHED: "SCAN_FINISHED",
            self.STATE_WAIT_COLLECTOR_RECOVERY: "WAIT_COLLECTOR_RECOVERY",
        }
        state_str = state_map.get(self.current_state, f"UNKNOWN({self.current_state})")
        if state_str != self.last_published_state:
            self.state_pub.publish(String(data=state_str))
            self.last_published_state = state_str

    # ===================== 工具方法 =====================
    def is_scan_task_finish(self):
        return self.accumulated_yaw >= (self.scan_stop_unwrapped - self.ANGLE_TOLERANCE)

    def publish_all_scan_result(self):
        if not self.scan_data_list:
            return
        best_item = max(self.scan_data_list, key=lambda x: x["peak_power"])
        angle_list = [item["angle"] for item in self.scan_data_list]
        power_list = [item["peak_power"] for item in self.scan_data_list]

        result_dict = {
            "angles": angle_list,
            "peak_powers": power_list,
            "best_angle": best_item["angle"],
            "best_power": best_item["peak_power"]
        }
        json_str = json.dumps(result_dict)
        self.publish_scan_final_result(json_str)
        self.get_logger().info(
            f"扫描汇总完成，总采样点数:{len(self.scan_data_list)} "
            f"最强方位:{best_item['angle']:.1f}° 强度:{best_item['peak_power']:.2f}dB"
        )

    def destroy_node(self):
        self.publish_set_vehicle_speed(0.0, 0.0)
        super().destroy_node()

    # ===================== 数学工具 =====================
    def quat_to_yaw_deg(self, x, y, z, w):
        siny_cosp = 2 * (w * z + x * y)
        cosy_cosp = 1 - 2 * (y * y + z * z)
        yaw_rad = math.atan2(siny_cosp, cosy_cosp)
        yaw_deg = math.degrees(yaw_rad)
        return yaw_deg % 360.0

    @staticmethod
    def normalize_angle_diff(angle_diff):
        while angle_diff > 180.0:
            angle_diff -= 360.0
        while angle_diff < -180.0:
            angle_diff += 360.0
        return angle_diff


def main(args=None):
    os.environ["UHD_RX_BUFFER_SIZE"] = "512M"
    rclpy.init(args=args)
    scan_node = SignalSourceScanNode()
    try:
        rclpy.spin(scan_node)
    except KeyboardInterrupt:
        pass
    scan_node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()