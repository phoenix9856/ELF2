#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import math
import time
import json
import rclpy
from rclpy.node import Node
from std_msgs.msg import Empty, String, Float32MultiArray
from sensor_msgs.msg import Imu
from geometry_msgs.msg import Twist


class SignalSourceTrackingNode(Node):
    # ------------------ 状态定义 ------------------
    STATE_IDLE = 0                # 空闲等待触发
    STATE_SCANNING_AROUND = 1     # 等待360°全向扫描结果
    STATE_FINE_SCANNING = 2       # 等待精细扫描结果
    STATE_TURN_TO_TARGET = 3      # 转向最强信号角度
    STATE_MOVE_FORWARD = 4        # 直行靠近
    STATE_VISUAL_TRACKING = 5     # 已转入视觉跟随（中断射频追踪）

    # ------------------ 宏定义参数（统一固定参数）------------------
    # 精细扫描固定：中心±30° 总60°扇形区域
    FINE_SCAN_HALF_RANGE = 30.0

    # 统一前进参数
    UNIFORM_MOVE_SPEED = 0.35
    UNIFORM_MOVE_DURATION = 3

    # 转向控制参数
    TURN_KP = 0.05
    TURN_KP_SMALL = 0.02
    TURN_KP_MID = 0.05
    TURN_KP_LARGE = 0.08
    MAX_ANG_VEL = 0.4
    ANGLE_TOL = 2.0               # 度

    # YOLO 触发间隔
    YOLO_TRIGGER_INTERVAL = 0.2  # 秒
    # 连续有效帧数阈值：5帧才切入视觉
    NEED_CONTINUOUS_YOLO_FRAMES = 3
    # 视觉丢失后等待2s再启动电磁跟踪
    VISUAL_LOST_DELAY = 2.0  # 秒

    def __init__(self):
        super().__init__("signal_source_tracking_node")

        # ---------- 状态变量 ----------
        self.state = self.STATE_IDLE
        self.prev_state = -1  
        self.current_yaw = 0.0
        self.target_yaw = 0.0
        self.best_signal_power = -100.0
        self.move_start_time = 0.0
        self.scan_result_ready = False
        self.last_move_scan_power = None
        self.align_stable_time = 1.0    # 需要稳定的最短时间（秒）
        self.align_stable_start = None  # 误差初次进入阈值的时间戳

        # 固定精细扫描与前进参数
        self.fine_half_range = self.FINE_SCAN_HALF_RANGE
        self.move_speed = self.UNIFORM_MOVE_SPEED
        self.move_duration = self.UNIFORM_MOVE_DURATION

        # YOLO 相关：记录上次触发时间
        self.yolo_trigger_timer = time.time()
        # 连续有效目标计数
        self.continuous_valid_yolo = 0
        # 扫描过程中实时检测到的信号强度
        self.current_signal_power = -100.0

        # 视觉跟随状态
        self.vis_tracking_state = "IDLE"  # 从话题接收
        # 视觉丢失时间戳（用于2s延迟启动电磁跟踪）
        self.visual_lost_time = None

        # ---------- ROS 接口 ----------
        self.track_start_sub = self.create_subscription(
            Empty, "/start_source_tracking", self.track_start_callback, 10
        )
        self.track_stop_sub = self.create_subscription(
            Empty, "/stop_source_tracking", self.track_stop_callback, 10
        )
        # 发布扫描指令
        self.scan_start_pub = self.create_publisher(
            Float32MultiArray, "/start_scan_angles", 10
        )
        # 订阅扫描结果
        self.scan_result_sub = self.create_subscription(
            String, "/all_direction_signal_detecting_result", self.scan_result_callback, 10
        )
        self.imu_sub = self.create_subscription(
            Imu, "/imu/data_raw", self.imu_callback, 10
        )
        self.cmd_vel_pub = self.create_publisher(Twist, "/cmd_vel", 10)

        # 触发 YOLO 推理
        self.yolo_trigger_pub = self.create_publisher(Empty, "/start_yolo_inference", 10)
        # 订阅 YOLO 结果
        self.yolo_result_sub = self.create_subscription(
            String, "/yolo_inference_results", self.yolo_result_callback, 10
        )
        # 订阅实时信号检测结果，用于扫描中提前判断是否可切入视觉跟随
        self.signal_detected_sub = self.create_subscription(
            String, "/signals_detected", self.signal_detected_callback, 10
        )
        # 发布视觉跟随启动指令
        self.vis_track_start_pub = self.create_publisher(Empty, "/start_visual_tracking", 10)
        # 订阅视觉跟随状态
        self.vis_state_sub = self.create_subscription(
            String, "/visual_tracking_state", self.vis_tracking_state_callback, 10
        )
        self.state_pub = self.create_publisher(String, "/signal_source_tracking_state", 10)
        self.last_published_state = None

        # 主循环 50Hz
        self.timer = self.create_timer(0.02, self.state_loop)
        self.get_logger().info("信号源追踪控制器启动完成，等待控制台触发")
        self.get_logger().info(f"规则：连续{self.NEED_CONTINUOUS_YOLO_FRAMES}帧YOLO有效目标 → 切入视觉跟随")

    # ===================== 状态机主循环 =====================
    def state_loop(self):
        match self.state:
            case self.STATE_IDLE:
                # 初次进入逻辑
                if self.state != self.prev_state:
                    self.stop_car()
                    self.prev_state = self.state

            case self.STATE_SCANNING_AROUND:
                # 检查是否切入视觉跟随
                if self.check_visual_tracking():
                    return
                
                # 初次进入逻辑
                if self.state != self.prev_state:
                    self.scan_result_ready = False
                    start_angle = self.current_yaw
                    # 全向扫描使用较快角速度（0.4）
                    ang_speed = 0.4
                    self.scan_start_pub.publish(
                        Float32MultiArray(data=[start_angle, start_angle + 360.0, ang_speed])
                    )
                    self.get_logger().info(
                        f"已触发全向扫描 (起始 {start_angle:.1f}°，终止 {start_angle + 360.0:.1f}°)，角速度 {ang_speed:.2f} rad/s"
                    )
                    self.prev_state = self.state
                
                # 扫描完成逻辑
                if self.scan_result_ready:
                    self.get_logger().info(
                        f"全向扫描完成：最佳角度 {self.target_yaw:.1f}°，"
                        f"强度 {self.best_signal_power:.1f} dB"
                    )
                    self._start_fine_scan(center_angle=self.target_yaw)
                    self.state = self.STATE_FINE_SCANNING

            case self.STATE_FINE_SCANNING:
                # 检查是否切入视觉跟随
                if self.check_visual_tracking():
                    return
                
                # 初次进入逻辑
                if self.state != self.prev_state:
                    self.scan_result_ready = False
                    self.prev_state = self.state

                # 扫描完成逻辑
                if self.scan_result_ready:
                    self.get_logger().info(
                        f"精细扫描完成：最佳角度 {self.target_yaw:.1f}°，"
                        f"强度 {self.best_signal_power:.1f} dB"
                    )

                    # 360°全向扫描重试条件：无有效信号或当前精细扫描强度低于前次前进前的扫描强度
                    if self.best_signal_power <= -60.0 or (
                        self.last_move_scan_power is not None
                        and self.best_signal_power < self.last_move_scan_power
                    ):
                        self.get_logger().warn(
                            "当前精细扫描结果无效/强度下降，重新发起360°全向扫描"
                        )
                        self.last_move_scan_power = None
                        self.state = self.STATE_SCANNING_AROUND
                        self.prev_state = -1
                        return

                    # 转向最强信号角度
                    self.finish_after_alignment = False
                    self.state = self.STATE_TURN_TO_TARGET

            case self.STATE_TURN_TO_TARGET:
                # 检查是否切入视觉跟随
                if self.check_visual_tracking():
                    return
                
                # 初次进入逻辑
                if self.state != self.prev_state:
                    self.prev_state = self.state
                    self.align_stable_start = None
                
                # 检查是否对准最强信号角度
                err = self.normalize_angle_diff(self.target_yaw - self.current_yaw)
                if abs(err) <= self.ANGLE_TOL:
                    if self.align_stable_start is None:
                        self.align_stable_start = time.time()
                    elif time.time() - self.align_stable_start >= self.align_stable_time:
                        self.stop_car()
                        self.get_logger().info("航向对准完成，开始前进")
                        self.move_start_time = time.time()
                        self.state = self.STATE_MOVE_FORWARD
                    else:
                        self.set_speed(0.0, 0.0)
                    return
                else:
                    self.align_stable_start = None
                
                # 执行转向动作
                abs_err = abs(err)
                if abs_err >= 30.0:
                    kp = self.TURN_KP_LARGE
                elif abs_err >= 10.0:
                    kp = self.TURN_KP_MID
                else:
                    kp = self.TURN_KP_SMALL
                ang_spd = kp * err
                ang_spd = max(-self.MAX_ANG_VEL, min(self.MAX_ANG_VEL, ang_spd))
                self.set_speed(0.0, ang_spd)

            case self.STATE_MOVE_FORWARD:
                # 检查是否切入视觉跟随
                if self.check_visual_tracking():
                    return
                
                # 初次进入逻辑
                if self.state != self.prev_state:
                    self.prev_state = self.state

                # 检查是否完成前进动作
                if time.time() - self.move_start_time >= self.move_duration:
                    self.stop_car()
                    self.get_logger().info("前进结束，发起新一轮精细扫描（以当前航向为中心）")
                    self.last_move_scan_power = self.best_signal_power
                    self._start_fine_scan(center_angle=self.current_yaw)
                    self.state = self.STATE_FINE_SCANNING
                    return

                # 执行前进动作
                self.set_speed(self.move_speed, 0.0)

            case self.STATE_VISUAL_TRACKING:
                # 检查视觉跟随是否丢失或停止
                if self.vis_tracking_state != "TRACKING":
                    now = time.time()
                    if self.visual_lost_time is None:
                        # 视觉刚丢失，记录时间戳，开始2s等待
                        self.visual_lost_time = now
                        self.get_logger().info(
                            f"视觉跟随丢失，等待{self.VISUAL_LOST_DELAY:.0f}s后启动电磁跟踪..."
                        )
                        self.stop_car()
                    elif now - self.visual_lost_time >= self.VISUAL_LOST_DELAY:
                        # 2s等待期满，启动电磁跟踪
                        self.get_logger().info(
                            f"视觉丢失已{self.VISUAL_LOST_DELAY:.0f}s，重新启动电磁跟踪"
                        )
                        self.visual_lost_time = None
                        self.continuous_valid_yolo = 0
                        self._restart_rf_tracking()
                    return

                # 视觉恢复，重置丢失计时
                self.visual_lost_time = None

                # 初次进入逻辑
                if self.state != self.prev_state:
                    self.stop_car()
                    self.get_logger().info("已进入视觉跟随模式，射频追踪挂起")
                    self.visual_lost_time = None
                    self.prev_state = self.state

        self._publish_state()

    # ===================== 回调函数 =====================
    def track_start_callback(self, msg):
        """重置节点资源并启动射频追踪"""
        if self.state in (self.STATE_IDLE, self.STATE_VISUAL_TRACKING):
            self._restart_rf_tracking()
        else:
            self.get_logger().warn("追踪任务运行中，忽略重复触发")

    def track_stop_callback(self, msg):
        """停止射频追踪，返回空闲状态"""
        if self.state != self.STATE_IDLE:
            self.get_logger().info("收到停止指令，返回空闲状态")
            self.stop_car()
            self.state = self.STATE_IDLE
            self.prev_state = -1
            self.continuous_valid_yolo = 0

    def _restart_rf_tracking(self):
        self.best_signal_power = -100.0
        self.current_signal_power = -100.0
        self.scan_result_ready = False
        self.target_yaw = 0.0
        self.last_move_scan_power = None
        self.continuous_valid_yolo = 0
        self.state = self.STATE_SCANNING_AROUND
        self.get_logger().info("启动射频追踪")

    def scan_result_callback(self, msg):
        if self.state not in (self.STATE_SCANNING_AROUND, self.STATE_FINE_SCANNING):
            return
        try:
            data = json.loads(msg.data)
            self.target_yaw = float(data["best_angle"])
            self.best_signal_power = float(data["best_power"])
            self.scan_result_ready = True
        except Exception as e:
            self.get_logger().error(f"扫描结果解析失败: {e}")
            self.state = self.STATE_IDLE

    def yolo_result_callback(self, msg):
        """统计连续有效YOLO帧数"""
        try:
            data = json.loads(msg.data)
            # 存在检测目标 = 有效帧
            if data.get("num_detections", 0) > 0:
                self.continuous_valid_yolo += 1
                self.get_logger().debug(f"YOLO有效帧计数: {self.continuous_valid_yolo}/{self.NEED_CONTINUOUS_YOLO_FRAMES}")
            else:
                # 无目标直接清零连续计数
                self.continuous_valid_yolo = 0
        except Exception as e:
            self.get_logger().error(f"YOLO结果解析失败: {e}")
            # 解析错误也清零
            self.continuous_valid_yolo = 0

    def signal_detected_callback(self, msg):
        """接收即时射频检测结果，更新扫描中信号强度用于提前视觉触发。"""
        try:
            data = json.loads(msg.data)
            detect_list = data.get("detections", [])
            if detect_list:
                power = max(d.get("peak_power_db", -100.0) for d in detect_list)
            else:
                power = data.get("noise_power_db", -100.0)
            self.current_signal_power = float(power)
        except Exception as e:
            self.get_logger().error(f"实时信号数据解析失败: {e}")
            self.current_signal_power = -100.0

    def vis_tracking_state_callback(self, msg):
        """记录视觉跟随状态"""
        self.vis_tracking_state = msg.data

    def _state_to_str(self):
        return {
            self.STATE_IDLE: "IDLE",
            self.STATE_SCANNING_AROUND: "SCANNING_AROUND",
            self.STATE_FINE_SCANNING: "FINE_SCANNING",
            self.STATE_TURN_TO_TARGET: "TURN_TO_TARGET",
            self.STATE_MOVE_FORWARD: "MOVE_FORWARD",
            self.STATE_VISUAL_TRACKING: "VISUAL_TRACKING",
        }.get(self.state, f"UNKNOWN({self.state})")

    def _publish_state(self):
        state_str = self._state_to_str()
        if state_str != self.last_published_state:
            self.state_pub.publish(String(data=state_str))
            self.last_published_state = state_str

    def imu_callback(self, msg):
        x = msg.orientation.x
        y = msg.orientation.y
        z = msg.orientation.z
        w = msg.orientation.w
        siny_cosp = 2 * (w * z + x * y)
        cosy_cosp = 1 - 2 * (y * y + z * z)
        yaw_rad = math.atan2(siny_cosp, cosy_cosp)
        self.current_yaw = math.degrees(yaw_rad) % 360.0

    # ===================== 内部工具函数 =====================
    def check_visual_tracking(self):
        """在射频追踪状态期间触发 YOLO 并检测是否切换到视觉跟随"""
        if self.state in (self.STATE_SCANNING_AROUND, self.STATE_FINE_SCANNING,
                          self.STATE_TURN_TO_TARGET, self.STATE_MOVE_FORWARD):
            now = time.time()
            if now - self.yolo_trigger_timer >= self.YOLO_TRIGGER_INTERVAL:
                self.yolo_trigger_timer = now
                self.yolo_trigger_pub.publish(Empty())
        else:
            self.yolo_trigger_timer = time.time()

        is_strong_signal = self.best_signal_power > -40.0 or self.current_signal_power > -40.0
        if self.continuous_valid_yolo >= self.NEED_CONTINUOUS_YOLO_FRAMES \
                and self.state not in (self.STATE_IDLE, self.STATE_VISUAL_TRACKING) \
                and is_strong_signal:
            self.get_logger().info(
                f"连续{self.NEED_CONTINUOUS_YOLO_FRAMES}帧检测到目标，信号强度 {self.current_signal_power:.1f}/{self.best_signal_power:.1f} dB，切换视觉跟随"
            )
            self.continuous_valid_yolo = 0
            self.stop_car()
            self.vis_track_start_pub.publish(Empty())
            self.state = self.STATE_VISUAL_TRACKING
            self.prev_state = -1
            self._publish_state()
            return True
        return False

    def _start_fine_scan(self, center_angle):
        start = (center_angle - self.fine_half_range) % 360.0
        stop = center_angle + self.fine_half_range
        # 精细扫描使用较慢角速度（0.15）
        ang_speed = 0.15
        self.scan_start_pub.publish(Float32MultiArray(data=[start, stop, ang_speed]))
        self.get_logger().info(
            f"发起60°扇形精细扫描: 起始 {start:.1f}°, 终止 {stop:.1f}° (中心 {center_angle:.1f}°)，角速度 {ang_speed:.2f} rad/s"
        )
        self.scan_result_ready = False

    def set_speed(self, lx, az):
        twist = Twist()
        twist.linear.x = lx
        twist.angular.z = az
        self.cmd_vel_pub.publish(twist)

    def stop_car(self):
        self.set_speed(0.0, 0.0)

    @staticmethod
    def normalize_angle_diff(angle_diff):
        while angle_diff > 180.0:
            angle_diff -= 360.0
        while angle_diff < -180.0:
            angle_diff += 360.0
        return angle_diff

    def destroy_node(self):
        self.stop_car()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = SignalSourceTrackingNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()