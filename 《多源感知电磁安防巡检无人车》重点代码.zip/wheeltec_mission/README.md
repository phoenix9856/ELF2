# wheeltec_mission — 不依赖 RViz 的设定点巡航

建完图之后，编辑配置文件，一键启动，机器人自动巡航。全程不需要 RViz。

---

## 全流程

### 第一步：建图

```bash
# 1. 把机器人放在地上，在这个位置贴个胶带做标记
#    这就是你的"出发点"，以后每次都从这里出发

# 2. 启动建图
ros2 launch slam_gmapping slam_gmapping.launch.py

# 3. 用键盘/手柄控制机器人走遍整个房间，走完之后保存地图
ros2 launch wheeltec_nav2 save_map.launch.py
```

地图保存在 `~/wheeltec_ros2/install/wheeltec_nav2/share/wheeltec_nav2/map/`。

> **胶带标记处 = 地图原点 (0, 0, 0)，机器人朝向 = yaw = 0。**

---

### 第二步：在地图上选巡航点

**推荐使用 Qt 版**（鼠标悬停实时显示坐标、自动检测障碍物）：

```bash
ros2 run wheeltec_mission pick_waypoints_qt \
    ~/wheeltec_ros2/install/wheeltec_nav2/share/wheeltec_nav2/map/WHEELTEC.yaml
```

| 操作 | 效果 |
|------|------|
| 鼠标悬停 | 状态栏实时显示地图坐标 `(x, y)` + 区域安全状态 |
| 鼠标左键点击 | 添加巡航点（障碍物区域会弹窗警告） |
| 鼠标右键 | 删除上一个点 |
| 滚轮 | 平滑缩放（以鼠标为中心） |
| 中键拖拽 | 平移地图 |
| Enter | 完成并输出坐标 |

地图上颜色标注：**灰色**=空闲安全、**红色**=障碍物、**淡黄**=未知区域。

---
---

### 第三步：写入配置

编辑 `config/mission.yaml`，把上一步输出的坐标粘贴进去：

```yaml
mission:
  initial_pose:
    x: 0.0        # 胶带标记处 = 地图原点
    y: 0.0
    yaw: 0.0      # 朝向和建图时一样
  loop: true      # true=循环巡逻, false=走完一次就停
  waypoints:
    - {x: 2.50, y: 1.30, yaw: 0.0}
    - {x: -0.80, y: 3.20, yaw: 0.0}
    - {x: -2.10, y: -1.50, yaw: 0.0}
```

---

### 第四步：编译

```bash
cd ~/wheeltec_ros2
colcon build --packages-select wheeltec_mission
source install/setup.bash
```

---

### 第五步：启动巡航

```bash
# 把机器人放到胶带标记处，朝向和建图时一样
ros2 launch wheeltec_mission mission.launch.py
```

终端实时打印进度：

```
[mission_node]: ==================================================
[mission_node]: STEP 1: Setting initial pose...
[mission_node]: Publishing initial pose: (0.00, 0.00, yaw=0.00)
[mission_node]: Initial pose confirmed — AMCL is tracking!
[mission_node]: ==================================================
[mission_node]: STEP 2: Waiting for Nav2 action server...
[mission_node]: Nav2 action server ready!
[mission_node]: ==================================================
[mission_node]: STEP 3: Starting waypoint navigation...
[mission_node]: >>> Navigating to waypoint 0: (2.50, 1.30)
[mission_node]: Navigation goal ACCEPTED — robot is moving!
[mission_node]: <<< Waypoint 0 (2.50, 1.30) REACHED!
[mission_node]: >>> Navigating to waypoint 1: (-0.80, 3.20)
...
```

机器人开始自动巡航。

---

### 以后每天

```bash
# 1. 机器人放到胶带标记处
# 2. 一条命令
ros2 launch wheeltec_mission mission.launch.py
```

---

## 命令速查

| 命令 | 功能 |
|------|------|
| `pick_waypoints_qt <地图yaml>` | 打开地图窗口，鼠标悬停显示坐标，自动检测障碍物区域 |
| `mission.launch.py` | 一键启动巡航 |

---

## 安装依赖

```bash
# Qt 版（推荐）
sudo apt install python3-pyqt5
# 或者
pip3 install PyQt5 numpy pyyaml
```

---

## 目录结构

```
wheeltec_mission/
├── README.md                     # 本文档
├── package.xml
├── setup.py
├── setup.cfg
├── resource/wheeltec_mission
├── config/
│   └── mission.yaml              # 巡航配置文件
├── launch/
│   └── mission.launch.py         # 一键启动
└── wheeltec_mission/
    ├── __init__.py
    ├── mission_node.py           # 核心巡航节点
    └── qt_waypoint_picker.py     # 航点选择工具
```

---

## 不依赖 RViz 的原理

- **gmapping 源码**：`map_to_odom_.setIdentity()` → 建图启动位置 = 地图原点 `(0, 0, 0)`
- **AMCL**：订阅 `/initialpose` 话题，`frame_id` 必须是 `"map"`
- **mission_node**：从配置文件读初始位姿 → 自动发 `/initialpose` → 用 `NavigateToPose` action 依次导航
- **pick_waypoints**：读取 PGM 地图 + YAML 元数据 → matplotlib 显示 → 鼠标点击坐标转换为 map 坐标
