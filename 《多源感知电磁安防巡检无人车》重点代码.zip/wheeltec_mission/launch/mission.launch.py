"""
mission.launch.py

One-click launch for Wheeltec robot navigation with waypoint mission.
Replaces the RViz-based workflow (2D Pose Estimate + Publish Point + waypoint_cycle).

Usage:
    ros2 launch wheeltec_mission mission.launch.py
    ros2 launch wheeltec_mission mission.launch.py mission_config:=/path/to/custom_mission.yaml
"""

import os
import yaml
from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def load_yaml(file_path: Path) -> dict:
    with open(file_path, 'r') as f:
        return yaml.safe_load(f)


def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time', default='false')

    # ---- robot model config ----
    wheeltec_robot_dir = get_package_share_directory('turn_on_wheeltec_robot')
    wheeltec_launch_dir = os.path.join(wheeltec_robot_dir, 'launch')
    cfg_params = load_yaml(
        os.path.join(wheeltec_robot_dir, 'config', 'wheeltec_param.yaml'))
    car_mode = cfg_params['car_mode']
    print(f'car_mode: {car_mode}')

    # ---- nav2 config ----
    wheeltec_nav_dir = get_package_share_directory('wheeltec_nav2')
    wheeltec_nav_launch_dir = os.path.join(wheeltec_nav_dir, 'launch')

    map_dir = os.path.join(wheeltec_nav_dir, 'map')
    map_file = LaunchConfiguration('map', default=os.path.join(
        map_dir, 'WHEELTEC.yaml'))

    param_dir = os.path.join(wheeltec_nav_dir, 'param', 'wheeltec_params')
    param_file = LaunchConfiguration('params', default=os.path.join(
        param_dir, f'param_{car_mode}.yaml'))

    # ---- mission config ----
    mission_dir = get_package_share_directory('wheeltec_mission')
    mission_config = LaunchConfiguration('mission_config', default=os.path.join(
        mission_dir, 'config', 'mission.yaml'))

    return LaunchDescription([
        # ---- Launch arguments ----
        DeclareLaunchArgument(
            'map', default_value=map_file,
            description='Full path to map file to load'),
        DeclareLaunchArgument(
            'params', default_value=param_file,
            description='Full path to Nav2 param file'),
        DeclareLaunchArgument(
            'mission_config', default_value=mission_config,
            description='Full path to mission.yaml config'),

        # ---- Mission node (replaces waypoint_cycle) ----
        Node(
            package='wheeltec_mission',
            executable='mission_node',
            name='mission_node',
            output='screen',
            arguments=['--config', mission_config],
        ),

        # ---- IMU processor ----
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                [wheeltec_launch_dir, '/imu_processor.launch.py']),
        ),

        # ---- Robot driver ----
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                [wheeltec_launch_dir, '/turn_on_wheeltec_robot.launch.py']),
            launch_arguments={
                'carto_slam': 'false',
                'robot_nav': 'false',
            }.items(),
        ),

        # ---- Lidar ----
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                [wheeltec_launch_dir, '/wheeltec_lidar.launch.py']),
        ),

        # ---- Nav2 bringup (AMCL + map_server + planner + controller + behaviors) ----
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                [wheeltec_nav_launch_dir, '/bringup_launch.py']),
            launch_arguments={
                'map': map_file,
                'use_sim_time': use_sim_time,
                'params_file': param_file,
            }.items(),
        ),

        # ====================================================================
        # Signal tracking nodes (coexist with navigation; idle until triggered)
        # ====================================================================

        # IQ collection node (USRP-based signal acquisition)
        Node(
            package='gnu_radio',
            executable='collect_iq_and_save',
            name='collect_iq_node',
            output='screen',
            respawn=True,
            respawn_delay=0.1,
        ),

        # IQ analysis / signal detection node
        Node(
            package='signal_processing',
            executable='analyze_iq_for_detection',
            name='analyze_iq_node',
            output='screen',
        ),

        # Omnidirectional scan execution node
        Node(
            package='signal_source_tracking',
            executable='signal_source_scan',
            name='signal_source_scan_node',
            output='screen',
        ),

        # Electromagnetic tracking controller (starts in IDLE, triggered by /start_source_tracking)
        Node(
            package='signal_source_tracking',
            executable='tracking_controller',
            name='source_tracking_controller_node',
            output='screen',
        ),

        # ====================================================================
        # YOLO visual tracking (camera + YOLO inference + visual tracker)
        # ====================================================================
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(
                    get_package_share_directory('yolo_visual_tracker'),
                    'launch',
                    'yolo_visual_tracking.launch.py'
                )
            )
        ),
    ])
