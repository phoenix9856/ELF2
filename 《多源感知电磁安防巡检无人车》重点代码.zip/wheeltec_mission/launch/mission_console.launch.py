"""
mission_console.launch.py — 一键启动巡航任务控制台

用法:
    ros2 launch wheeltec_mission mission_console.launch.py
    ros2 launch wheeltec_mission mission_console.launch.py map_yaml:=/path/to/WHEELTEC.yaml
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    # 自动检测地图路径
    wheeltec_nav_dir = get_package_share_directory('wheeltec_nav2')
    default_map = os.path.join(wheeltec_nav_dir, 'map', 'WHEELTEC.yaml')

    map_yaml = LaunchConfiguration('map_yaml', default=default_map)

    return LaunchDescription([
        DeclareLaunchArgument(
            'map_yaml', default_value=default_map,
            description='Full path to map YAML file (WHEELTEC.yaml)'),

        Node(
            package='wheeltec_mission',
            executable='mission_console',
            name='mission_console',
            output='screen',
            arguments=[map_yaml],
        ),
    ])
