import os
from glob import glob
from setuptools import setup

package_name = 'wheeltec_mission'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'config'),
            glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='wheeltec',
    maintainer_email='wheeltec@todo.todo',
    description='One-click mission node: set initial pose and cruise waypoints without RViz',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'mission_node = wheeltec_mission.mission_node:main',
            'pick_waypoints_qt = wheeltec_mission.qt_waypoint_picker:main',
            'mission_console = wheeltec_mission.mission_console:main',
        ],
    },
)
