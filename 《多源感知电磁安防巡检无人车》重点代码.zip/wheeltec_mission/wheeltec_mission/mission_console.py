#!/usr/bin/env python3
"""
mission_console.py — 巡航任务控制台 (PyQt5)

集成功能:
  - 地图显示 + 鼠标点选航点（实时坐标、障碍物警告）
  - 航点列表（增删改、拖拽排序暂不支持）
  - 一键清除原点周围建图假障碍物
  - 读取/保存 mission.yaml

用法:
  ros2 run wheeltec_mission mission_console <地图yaml路径> [mission.yaml路径]

依赖: PyQt5, numpy, pyyaml
"""

import os, sys, re, argparse, subprocess, shutil
import numpy as np
import yaml

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QGroupBox, QPushButton, QGraphicsView, QGraphicsScene,
    QGraphicsPixmapItem, QGraphicsEllipseItem, QGraphicsLineItem,
    QGraphicsTextItem,
    QStatusBar, QLabel, QTextEdit, QMessageBox, QListWidget,
    QListWidgetItem, QSplitter, QFileDialog, QTabWidget, QComboBox,
)
from PyQt5.QtCore import Qt, QPointF, QRectF, QEvent
from PyQt5.QtGui import (
    QPixmap, QImage, QPen, QColor, QBrush, QPainter, QFont, QTransform,
    QKeyEvent,
)


# =====================================================================
# Console Redirector — 将 stdout/stderr 重定向到 QTextEdit
# =====================================================================
class ConsoleRedirector:
    def __init__(self, text_edit: QTextEdit):
        self.text_edit = text_edit

    def write(self, text):
        if text.strip():
            self.text_edit.append(text.rstrip())
            scrollbar = self.text_edit.verticalScrollBar()
            scrollbar.setValue(scrollbar.maximum())

    def flush(self):
        pass


# =====================================================================
# Map View
# =====================================================================
class MapView(QGraphicsView):
    TAP_THRESHOLD = 6      # 移动小于此像素视为点击而非拖拽

    def __init__(self, scene, console):
        super().__init__(scene)
        self.console = console
        self._zoom = 0
        self._zoom_factor = 1.12
        self._max_zoom = 40
        self._min_zoom = -20
        self._press_pos = None       # 按下时的屏幕坐标
        self._press_scene_pos = None # 按下时的场景坐标
        self._dragging = False
        self._last_pan_pos = None
        self.setRenderHints(QPainter.Antialiasing | QPainter.SmoothPixmapTransform)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.AnchorUnderMouse)
        self.setViewportUpdateMode(QGraphicsView.SmartViewportUpdate)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setDragMode(QGraphicsView.NoDrag)  # 手动处理拖拽
        self.viewport().setCursor(Qt.OpenHandCursor)

        # XY 方向指示（固定在视图左上角，直角坐标系风格）
        self._compass = QLabel(self.viewport())
        self._compass.setStyleSheet(
            "background: rgba(0,0,0,100); color: #fff; "
            "font-family: Consolas, monospace; font-size: 13px; "
            "font-weight: bold; padding: 3px 5px; border-radius: 3px; "
            "line-height: 1;")
        self._compass.setText(
            "<span style='color:#6f6'>↑Y</span><br>"
            "<span style='color:#f66'>→X</span>"
        )
        self._compass.adjustSize()
        self._compass.move(8, 8)

        # 比例尺浮层（固定在视图左下角，缩放时自动更新）
        self._scale_label = QLabel(self.viewport())
        self._scale_label.setStyleSheet(
            "background: rgba(0,0,0,120); color: #fff; "
            "font-size: 9px; font-weight: bold; padding: 2px 6px; "
            "border-radius: 3px;")
        self._scale_label.setAlignment(Qt.AlignCenter)
        self._update_scale_bar()

    # -----------------------------------------------------------------
    # 比例尺更新
    # -----------------------------------------------------------------
    def _update_scale_bar(self):
        """根据当前缩放换算比例尺文本"""
        ppm = (self._zoom_factor ** self._zoom) / self.console.resolution
        # 选一个漂亮的距离：让比例尺宽度 ≈ 50~100 像素
        nice = [0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100]
        best_m = 1.0
        for m in nice:
            if ppm * m >= 40:
                best_m = m
                break
        bar_px = int(ppm * best_m)
        n = min(bar_px // 4, 20)  # 用多少个 "─" 画线
        line = "─" * max(n, 4)
        if best_m >= 1:
            text = f"{best_m:.0f} m"
        else:
            text = f"{best_m * 100:.0f} cm"
        self._scale_label.setText(f"├{line}┤\n  {text}")
        self._scale_label.adjustSize()
        # 固定在左下角
        vh = self.viewport().height()
        self._scale_label.move(8, vh - self._scale_label.height() - 8)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_scale_bar()

    # -----------------------------------------------------------------
    # 滚轮缩放
    # -----------------------------------------------------------------
    def wheelEvent(self, event):
        factor = self._zoom_factor if event.angleDelta().y() > 0 else 1.0 / self._zoom_factor
        if (self._zoom >= self._max_zoom and factor > 1) or \
           (self._zoom <= self._min_zoom and factor < 1):
            return
        self._zoom += 1 if factor > 1 else -1
        self.scale(factor, factor)
        self._update_scale_bar()

    # -----------------------------------------------------------------
    # 鼠标/触摸事件 — 拖拽/点击智能区分
    # -----------------------------------------------------------------
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._press_pos = event.pos()
            self._press_scene_pos = self.mapToScene(event.pos())
            self._dragging = False
            self._last_pan_pos = event.pos()
            self.viewport().setCursor(Qt.ClosedHandCursor)
            event.accept()
        elif event.button() == Qt.RightButton:
            self.console.remove_last_waypoint()
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        # 悬停信息
        pos = self.mapToScene(event.pos())
        self.console.on_hover(pos.x(), pos.y())

        # 拖拽平移
        if self._press_pos is not None:
            delta = event.pos() - self._press_pos
            if abs(delta.x()) > self.TAP_THRESHOLD or abs(delta.y()) > self.TAP_THRESHOLD:
                self._dragging = True
            if self._dragging and self._last_pan_pos is not None:
                d = event.pos() - self._last_pan_pos
                self.horizontalScrollBar().setValue(self.horizontalScrollBar().value() - d.x())
                self.verticalScrollBar().setValue(self.verticalScrollBar().value() - d.y())
            self._last_pan_pos = event.pos()
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.viewport().setCursor(Qt.OpenHandCursor)
            if not self._dragging and self._press_scene_pos is not None:
                px, py = int(self._press_scene_pos.x()), int(self._press_scene_pos.y())
                if 0 <= px < self.console.img_w and 0 <= py < self.console.img_h:
                    self.console._click_map(px, py)
            self._press_pos = None
            self._press_scene_pos = None
            self._dragging = False
            self._last_pan_pos = None
            event.accept()
        else:
            super().mouseReleaseEvent(event)

    # -----------------------------------------------------------------
    # 键盘
    # -----------------------------------------------------------------
    def keyPressEvent(self, event):
        if event.key() == Qt.Key_F11:
            self.console.toggle_fullscreen()
        elif event.key() in (Qt.Key_Return, Qt.Key_Enter):
            self.console.export_config()
        elif event.key() == Qt.Key_Escape:
            self.console.close()
        else:
            super().keyPressEvent(event)


# =====================================================================
# Main Console
# =====================================================================
class MissionConsole(QMainWindow):
    def __init__(self, map_yaml_path, mission_yaml_path=None):
        super().__init__()
        self.setWindowTitle("多源感知电磁安防巡检无人车")
        self.resize(1024, 600)
        self.setStyleSheet("""
            QMainWindow {
                background-color: #0d1117;
            }
            QWidget {
                background-color: #0d1117;
                color: #e6edf3;
                font-family: 'Segoe UI', 'Microsoft YaHei', sans-serif;
            }
            QGroupBox {
                font-size: 13px; font-weight: bold;
                color: #58a6ff;
                border: 1px solid #30363d;
                border-radius: 6px;
                margin-top: 10px;
                padding-top: 14px;
                background-color: #161b22;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 2px 8px;
                color: #58a6ff;
            }
            QListWidget {
                font-size: 10px;
                background-color: #0d1117;
                border: 1px solid #30363d;
                border-radius: 4px;
                color: #e6edf3;
            }
            QListWidget::item {
                padding: 3px 6px;
            }
            QListWidget::item:selected {
                background-color: #1f6feb;
                color: white;
            }
            QListWidget::item:hover {
                background-color: #21262d;
            }
            QPushButton {
                font-size: 11px;
            }
            QPushButton:hover {
                opacity: 0.85;
            }
            QPushButton:pressed {
                opacity: 0.7;
            }
            QTabWidget::pane {
                border: 1px solid #30363d;
                border-radius: 4px;
                background-color: #161b22;
            }
            QTabBar::tab {
                font-size: 12px; font-weight: bold;
                padding: 5px 12px;
                background-color: #21262d;
                color: #8b949e;
                border: 1px solid #30363d;
                border-bottom: none;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background-color: #161b22;
                color: #58a6ff;
                border-bottom: 2px solid #1f6feb;
            }
            QTabBar::tab:hover:!selected {
                color: #e6edf3;
                background-color: #30363d;
            }
            QStatusBar {
                background-color: #161b22;
                color: #8b949e;
                border-top: 1px solid #30363d;
                font-size: 10px;
            }
            QSplitter::handle {
                background-color: #30363d;
                height: 2px;
            }
            QLabel {
                background: transparent;
            }
            QScrollBar:vertical {
                background: #0d1117;
                width: 8px;
                border-radius: 4px;
            }
            QScrollBar::handle:vertical {
                background: #484f58;
                border-radius: 4px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background: #6e7681;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)
        self._is_fullscreen = True

        # ---- 加载地图 ----
        self._load_map(map_yaml_path)
        self.mission_yaml_path = mission_yaml_path

        # ---- 数据 ----
        self.waypoints_px = []  # [(px, py), ...]
        self._slam_process = None  # 建图子进程
        self._cruise_process = None  # 巡航子进程

        # ---- 构建 UI ----
        self._build_ui()

        # ---- 状态栏（必须在加载 mission.yaml 之前创建） ----
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage("左键+点 | 右键-删 | Enter导出 | Esc退出 | 滚轮缩放 | 中键拖拽", 0)

        # ---- 加载已有 mission.yaml ----
        if mission_yaml_path and os.path.exists(mission_yaml_path):
            self._load_mission_yaml()

    # =================================================================
    # 地图加载
    # =================================================================
    def _load_map(self, yaml_path):
        if not os.path.exists(yaml_path):
            QMessageBox.critical(self, "错误", f"地图文件不存在:\n{yaml_path}")
            sys.exit(1)
        with open(yaml_path, 'r') as f:
            self.map_meta = yaml.safe_load(f)
        self.resolution = float(self.map_meta['resolution'])
        self.origin_x = float(self.map_meta['origin'][0])
        self.origin_y = float(self.map_meta['origin'][1])

        yaml_dir = os.path.dirname(os.path.abspath(yaml_path))
        pgm_path = os.path.join(yaml_dir, self.map_meta['image'])
        if not os.path.exists(pgm_path):
            QMessageBox.critical(self, "错误", f"PGM 不存在:\n{pgm_path}")
            sys.exit(1)

        self.map_yaml_path = yaml_path
        self._pgm_path = pgm_path
        self.pgm_data = self._read_pgm(pgm_path)
        self.img_h, self.img_w = self.pgm_data.shape

    def _read_pgm(self, path):
        with open(path, 'rb') as f:
            magic = f.readline().decode().strip()
            line = f.readline().decode().strip()
            while line.startswith('#'):
                line = f.readline().decode().strip()
            w, h = map(int, line.split())
            maxval = int(f.readline().decode().strip())
            if magic == 'P5':
                data = np.frombuffer(f.read(), dtype=np.uint8).reshape(h, w).copy()
            elif magic == 'P2':
                raw = b''
                for line in f:
                    raw += line
                data = np.array(raw.decode().split(), dtype=np.uint8).reshape(h, w)
            else:
                raise ValueError(f"Unsupported PGM: {magic}")
        if maxval != 255:
            data = (data.astype(np.float32) / maxval * 255).astype(np.uint8)
        return data

    # =================================================================
    # 坐标转换
    # =================================================================
    def px_to_world(self, px, py):
        x = self.origin_x + px * self.resolution
        y = self.origin_y + (self.img_h - py) * self.resolution
        return x, y

    def world_to_px(self, wx, wy):
        px = int((wx - self.origin_x) / self.resolution)
        py = int(self.img_h - (wy - self.origin_y) / self.resolution)
        return px, py

    # =================================================================
    # UI 构建
    # =================================================================
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        outer_layout = QVBoxLayout(central)
        outer_layout.setContentsMargins(2, 2, 2, 2)

        # ---- 垂直分割器：上方功能面板 / 下方控制台 ----
        self._splitter = QSplitter(Qt.Vertical)
        outer_layout.addWidget(self._splitter)

        # ============================================================
        # 上半部分：地图 + 右侧面板
        # ============================================================
        self._top_widget = QWidget()
        top_layout = QHBoxLayout(self._top_widget)
        top_layout.setContentsMargins(0, 0, 0, 0)

        # ---- 左侧：地图 ----
        left_box = QGroupBox("地图")
        left_layout = QVBoxLayout(left_box)
        self.scene = QGraphicsScene(self)
        self.view = MapView(self.scene, self)
        left_layout.addWidget(self.view)

        # ---- 右侧面板（标签页切换） ----
        tabs = QTabWidget()

        # ========== Tab 1: 航点 ==========
        wp_tab = QWidget()
        wp_tab_layout = QVBoxLayout(wp_tab)
        wp_tab_layout.setContentsMargins(2, 2, 2, 2)

        self.wp_list = QListWidget()
        self.wp_list.itemDoubleClicked.connect(self._on_wp_double_click)
        wp_tab_layout.addWidget(self.wp_list)

        wp_btn_layout = QHBoxLayout()
        wp_btn_layout.setSpacing(4)
        del_btn = QPushButton("删除选中")
        del_btn.setStyleSheet(
            "background-color: #4a5058; color: white; padding: 5px; "
            "font-size: 11px; font-weight: bold; border-radius: 4px;")
        del_btn.clicked.connect(self._delete_selected_wp)
        clear_btn = QPushButton("清空全部")
        clear_btn.setStyleSheet(
            "background-color: #4a5058; color: white; padding: 5px; "
            "font-size: 11px; font-weight: bold; border-radius: 4px;")
        clear_btn.clicked.connect(self._clear_all_wp)
        wp_btn_layout.addWidget(del_btn)
        wp_btn_layout.addWidget(clear_btn)
        wp_tab_layout.addLayout(wp_btn_layout)

        # 坐标信息
        font = QFont("Monospace", 9)
        self.hover_label = QLabel("X: ---   Y: ---")
        self.hover_label.setFont(font)
        wp_tab_layout.addWidget(self.hover_label)
        self.pixel_label = QLabel("像素: (---, ---)  值: ---")
        self.pixel_label.setFont(font)
        wp_tab_layout.addWidget(self.pixel_label)
        self.dist_label = QLabel("距原点: --- m")
        self.dist_label.setFont(font)
        wp_tab_layout.addWidget(self.dist_label)
        self.zone_label = QLabel("")
        self.zone_label.setFont(QFont("Sans", 9, QFont.Bold))
        self.zone_label.setStyleSheet("padding: 4px 8px; border-radius: 4px;")
        wp_tab_layout.addWidget(self.zone_label)

        # 配置文件操作
        save_btn = QPushButton("保存航点到巡航配置")
        save_btn.setStyleSheet(
            "background-color: #007acc; color: white; padding: 5px; "
            "font-size: 11px; font-weight: bold; border-radius: 4px;")
        save_btn.clicked.connect(self._save_mission_yaml)
        wp_tab_layout.addWidget(save_btn)

        load_btn = QPushButton("加载导航航点")
        load_btn.setStyleSheet(
            "background-color: #4a5058; color: white; padding: 5px; "
            "font-size: 11px; font-weight: bold; border-radius: 4px;")
        load_btn.clicked.connect(self._load_mission_yaml)
        wp_tab_layout.addWidget(load_btn)

        # 巡航控制
        start_cruise_btn = QPushButton("点击启动巡航")
        start_cruise_btn.setStyleSheet(
            "background-color: #007acc; color: white; padding: 6px; "
            "font-size: 11px; font-weight: bold; border-radius: 4px;")
        start_cruise_btn.clicked.connect(self._start_cruise)
        wp_tab_layout.addWidget(start_cruise_btn)

        stop_cruise_btn = QPushButton("停止巡航")
        stop_cruise_btn.setStyleSheet(
            "background-color: #4a5058; color: white; padding: 5px; "
            "font-size: 11px; font-weight: bold; border-radius: 4px;")
        stop_cruise_btn.clicked.connect(self._stop_cruise)
        wp_tab_layout.addWidget(stop_cruise_btn)

        wp_tab_layout.addStretch()
        tabs.addTab(wp_tab, "巡航")

        # ========== Tab 2: 建图 ==========
        slam_tab = QWidget()
        slam_tab_layout = QVBoxLayout(slam_tab)
        slam_tab_layout.setContentsMargins(2, 4, 2, 4)

        # 建图算法选择
        self.slam_algo_combo = QComboBox()
        self.slam_algo_combo.addItem("gmapping", "slam_gmapping")
        self.slam_algo_combo.addItem("slam_toolbox", "slam_toolbox")
        self.slam_algo_combo.addItem("cartographer", "cartographer")
        self.slam_algo_combo.setStyleSheet("""
            QComboBox {
                background-color: #21262d;
                color: #e6edf3;
                border: 1px solid #30363d;
                border-radius: 4px;
                padding: 5px 8px;
                font-size: 11px;
                font-weight: bold;
            }
            QComboBox::drop-down {
                border: none;
                width: 20px;
            }
            QComboBox QAbstractItemView {
                background-color: #21262d;
                color: #e6edf3;
                selection-background-color: #1f6feb;
                border: 1px solid #30363d;
            }
        """)
        slam_tab_layout.addWidget(self.slam_algo_combo)

        start_slam_btn = QPushButton("开启建图")
        start_slam_btn.setStyleSheet(
            "background-color: #007acc; color: white; padding: 5px; "
            "font-weight: bold; border-radius: 4px;")
        start_slam_btn.clicked.connect(self._start_mapping)
        slam_tab_layout.addWidget(start_slam_btn)

        stop_slam_btn = QPushButton("停止建图")
        stop_slam_btn.setStyleSheet(
            "background-color: #4a5058; color: white; padding: 5px; "
            "font-weight: bold; border-radius: 4px;")
        stop_slam_btn.clicked.connect(self._stop_mapping)
        slam_tab_layout.addWidget(stop_slam_btn)

        save_map_btn = QPushButton("存图")
        save_map_btn.setStyleSheet(
            "background-color: #4a5058; color: white; padding: 5px; "
            "font-weight: bold; border-radius: 4px;")
        save_map_btn.clicked.connect(self._save_map_launch)
        slam_tab_layout.addWidget(save_map_btn)

        refresh_btn = QPushButton("刷新地图")
        refresh_btn.setStyleSheet(
            "background-color: #4a5058; color: white; padding: 5px; "
            "font-weight: bold; border-radius: 4px;")
        refresh_btn.clicked.connect(self._refresh_map)
        slam_tab_layout.addWidget(refresh_btn)

        fix_03_btn = QPushButton("清除0.3m障碍")
        fix_03_btn.setStyleSheet(
            "background-color: #4a5058; color: white; padding: 5px; "
            "font-weight: bold; border-radius: 4px;")
        fix_03_btn.clicked.connect(lambda: self._fix_map(0.30))
        slam_tab_layout.addWidget(fix_03_btn)

        fix_05_btn = QPushButton("清除0.5m障碍")
        fix_05_btn.setStyleSheet(
            "background-color: #4a5058; color: white; padding: 5px; "
            "font-weight: bold; border-radius: 4px;")
        fix_05_btn.clicked.connect(lambda: self._fix_map(0.50))
        slam_tab_layout.addWidget(fix_05_btn)

        fix_07_btn = QPushButton("清除0.7m障碍")
        fix_07_btn.setStyleSheet(
            "background-color: #4a5058; color: white; padding: 5px; "
            "font-weight: bold; border-radius: 4px;")
        fix_07_btn.clicked.connect(lambda: self._fix_map(0.70))
        slam_tab_layout.addWidget(fix_07_btn)
        slam_tab_layout.addStretch()
        tabs.addTab(slam_tab, "建图")

        # ========== Tab 3: 帮助 ==========
        help_tab = QWidget()
        help_tab_layout = QVBoxLayout(help_tab)
        help_tab_layout.setContentsMargins(4, 6, 4, 6)

        help_text = QTextEdit()
        help_text.setReadOnly(True)
        help_text.setStyleSheet("""
            QTextEdit {
                background-color: #161b22;
                color: #e6edf3;
                border: none;
                font-size: 11px;
                font-family: 'Microsoft YaHei', 'Segoe UI', sans-serif;
            }
        """)
        help_text.setHtml("""
<h3 style='color:#58a6ff;'>📋 无人车使用指南</h3>

<p style='color:#8b949e; font-size:10px;'>
<b>坐标说明：</b><br>
<b>X / Y</b> — 世界坐标，单位 <b>米</b>，建图原点为 (0, 0)<br>
<b>像素</b> — 地图图片上的行列位置<br>
<b>值</b> — 0=障碍物(黑) 255=空闲(白) 中间=未知<br>
<b>距原点</b> — 当前位置离建图起点的直线距离
</p>

<hr style='border-color:#30363d;'>

<p><b style='color:#f0883e;'>1. 建图</b><br>
切换到 <b>建图</b> 标签页，点击 <b>开启建图</b>。<br>
使用 <b>手柄</b> 遥控无人车在场地内行驶一圈，<br>
完成后点 <b>存图</b>，再点 <b>停止建图</b>。</p>

<p><b style='color:#f0883e;'>2. 刷新地图</b><br>
存图后控制台不会自动加载新地图，<br>
点 <b>刷新地图</b> 即可看到刚保存的地图。</p>

<p><b style='color:#f0883e;'>3. 清除障碍</b><br>
如果原点周围有建图时留下的假障碍物，<br>
选择合适的半径点清除。</p>

<p><b style='color:#f0883e;'>4. 规划航点</b><br>
在 <b>航点</b> 标签页，鼠标在地图上 <b>左键</b> 点击添加航点。<br>
<b>右键</b> 删除最后一个，或选中列表项点 <b>删除选中</b>。<br>
航点将按顺序逐段连线，最后自动闭合。</p>

<p><b style='color:#f0883e;'>5. 保存配置</b><br>
规划完成后点 <b>保存航点到巡航配置</b>，<br>
配置文件自动同步到 install 和 src 目录。</p>

<p><b style='color:#f0883e;'>6. 启动巡航</b><br>
将无人车放置到 <b>建图起始点</b>（原点位置），<br>
在 <b>巡航</b> 标签页点击 <b>点击启动巡航</b>，<br>
确认弹窗后无人车将按航点顺序自动巡航。</p>

<hr style='border-color:#30363d;'>

<p style='color:#8b949e; font-size:10px;'>
<b>快捷键：</b> 左键+点 | 右键-删 | 滚轮缩放 | 中键拖拽 | F11全屏 | Esc退出<br>
<b>编译命令：</b> <code style='color:#58a6ff;'>colcon build --packages-select wheeltec_mission</code>
</p>
        """)
        help_tab_layout.addWidget(help_text)
        tabs.addTab(help_tab, "帮助")

        top_layout.addWidget(left_box, 2)
        right_layout = QVBoxLayout()
        right_layout.addWidget(tabs)

        # 控制台开关按钮
        self._console_toggle_btn = QPushButton("☰ 日志")
        self._console_toggle_btn.setStyleSheet(
            "background-color: #21262d; color: #8b949e; padding: 3px; "
            "font-size: 10px; font-weight: bold; border-radius: 4px;")
        self._console_toggle_btn.clicked.connect(self._toggle_console)
        right_layout.addWidget(self._console_toggle_btn)

        right_widget = QWidget()
        right_widget.setLayout(right_layout)
        right_widget.setMaximumWidth(280)
        top_layout.addWidget(right_widget, 1)

        self._splitter.addWidget(self._top_widget)

        # ============================================================
        # 下半部分：运行控制台（紧凑）
        # ============================================================
        self._bottom_box = QGroupBox("控制台")
        bottom_layout = QVBoxLayout(self._bottom_box)
        bottom_layout.setContentsMargins(2, 2, 2, 2)
        bottom_layout.setSpacing(2)

        self.console_edit = QTextEdit()
        self.console_edit.setReadOnly(True)
        self.console_edit.setPlaceholderText("日志输出...")
        self.console_edit.setMaximumHeight(80)
        self.console_edit.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #d4d4d4;
                font-family: Consolas, 'Courier New', monospace;
                font-size: 9px;
            }
        """)
        bottom_layout.addWidget(self.console_edit)

        console_btn_row = QHBoxLayout()
        console_btn_row.setContentsMargins(0, 0, 0, 0)
        console_btn_row.setSpacing(4)
        self._console_max_btn = QPushButton("□ 展开")
        self._console_max_btn.setFixedSize(52, 22)
        self._console_max_btn.setStyleSheet(
            "background-color: #007acc; color: white; padding: 2px; "
            "font-size: 9px; font-weight: bold; border-radius: 4px;")
        self._console_max_btn.clicked.connect(self.toggle_console_max)
        console_btn_row.addWidget(self._console_max_btn)
        console_btn_row.addStretch()
        clear_console_btn = QPushButton("清空")
        clear_console_btn.setFixedSize(40, 22)
        clear_console_btn.setStyleSheet(
            "background-color: #4a5058; color: white; padding: 2px; "
            "font-size: 9px; font-weight: bold; border-radius: 4px;")
        clear_console_btn.clicked.connect(self.console_edit.clear)
        console_btn_row.addWidget(clear_console_btn)
        bottom_layout.addLayout(console_btn_row)

        self._splitter.addWidget(self._bottom_box)

        # 分割比例：上方占大部分，下方控制台默认隐藏
        self._splitter.setStretchFactor(0, 87)
        self._splitter.setStretchFactor(1, 13)
        self._splitter.setSizes([500, 0])
        self._bottom_box.setVisible(False)
        self._console_visible = False

        # ---- 重定向 stdout/stderr 到控制台 ----
        self._redirector = ConsoleRedirector(self.console_edit)
        self._old_stdout = sys.stdout
        self._old_stderr = sys.stderr
        sys.stdout = self._redirector
        sys.stderr = self._redirector

        # 控制台最大化状态
        self._console_maxed = False
        self._console_visible = False

        # 显示地图
        self._render_map()

    # =================================================================
    # 全屏切换（F11）与控制台最大化
    # =================================================================
    def toggle_fullscreen(self):
        """F11 窗口全屏"""
        self._is_fullscreen = not self._is_fullscreen
        if self._is_fullscreen:
            self.showFullScreen()
        else:
            self.showNormal()

    def _toggle_console(self):
        """显示/隐藏底部控制台"""
        self._console_visible = not self._console_visible
        self._bottom_box.setVisible(self._console_visible)
        if self._console_visible:
            self._splitter.setSizes([500, 100])
            self._console_toggle_btn.setText("☰ 日志 ▲")
        else:
            self._splitter.setSizes([500, 0])
            self._console_toggle_btn.setText("☰ 日志")

    def toggle_console_max(self):
        """点击按钮：控制台充满整个窗口 / 恢复"""
        self._console_maxed = not self._console_maxed
        if self._console_maxed:
            # 隐藏上半部分，控制台占据全部空间
            self._top_widget.setVisible(False)
            self.console_edit.setMaximumHeight(16777215)  # 去掉高度限制
            self._console_max_btn.setText("❐ 还原")
            self._bottom_box.setTitle("控制台（已展开）")
        else:
            # 恢复上半部分 + 紧凑控制台
            self._top_widget.setVisible(True)
            self.console_edit.setMaximumHeight(80)
            self._console_max_btn.setText("□ 展开")
            self._bottom_box.setTitle("控制台")

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key_F11:
            # 如果控制台处于最大化状态，先还原
            if self._console_maxed:
                self.toggle_console_max()
            self.toggle_fullscreen()
        elif event.key() == Qt.Key_Escape:
            self.close()
        else:
            super().keyPressEvent(event)

    def closeEvent(self, event):
        """关闭窗口时恢复 stdout/stderr，清理建图/巡航进程"""
        for proc in [self._slam_process, self._cruise_process]:
            if proc is not None and proc.poll() is None:
                try:
                    os.killpg(os.getpgid(proc.pid), 2)
                    proc.wait(timeout=3)
                except Exception:
                    try:
                        os.killpg(os.getpgid(proc.pid), 9)
                    except Exception:
                        pass
        sys.stdout = self._old_stdout
        sys.stderr = self._old_stderr
        super().closeEvent(event)

    # =================================================================
    # 地图渲染
    # =================================================================
    def _render_map(self):
        self.scene.clear()
        h, w = self.pgm_data.shape
        rgba = np.zeros((h, w, 4), dtype=np.uint8)
        gray = self.pgm_data.astype(np.float32)

        # ---- 三区配色（仿 costmap / RViz 风格） ----
        mask_free = gray >= 250                          # 已知空闲
        mask_occ  = gray <= 50                           # 障碍物
        mask_unk  = (gray > 50) & (gray < 250)           # 未知

        # 空闲区 — 浅灰白
        rgba[mask_free] = [235, 237, 239, 255]

        # 未知区 — 深灰蓝渐变（越暗越不确定）
        g = gray[mask_unk]
        t = (g - 50) / 200.0  # 0..1，0=近障碍 → 暗, 1=近空闲 → 亮
        rgba[mask_unk, 0] = (88  + t * 72).astype(np.uint8)   # 88→160
        rgba[mask_unk, 1] = (96  + t * 48).astype(np.uint8)   # 96→144
        rgba[mask_unk, 2] = (110 + t * 40).astype(np.uint8)   # 110→150
        rgba[mask_unk, 3] = 255

        # 障碍物区 — 深色 + 红色边缘
        rgba[mask_occ] = [25, 28, 33, 255]
        # 边缘检测（纯 numpy）：障碍物膨胀一圈，与非障碍物取交集
        dilated = np.zeros_like(mask_occ)
        dilated[:-1, :] |= mask_occ[1:, :]     # 上
        dilated[1:, :]  |= mask_occ[:-1, :]    # 下
        dilated[:, :-1] |= mask_occ[:, 1:]     # 左
        dilated[:, 1:]  |= mask_occ[:, :-1]    # 右
        # 对角线
        dilated[:-1, :-1] |= mask_occ[1:, 1:]
        dilated[:-1, 1:]  |= mask_occ[1:, :-1]
        dilated[1:, :-1]  |= mask_occ[:-1, 1:]
        dilated[1:, 1:]   |= mask_occ[:-1, :-1]
        edge = dilated & ~mask_occ
        rgba[edge] = [220, 60, 60, 255]

        qimg = QImage(rgba.data, w, h, w * 4, QImage.Format_RGBA8888)
        pixmap = QPixmap.fromImage(qimg)
        self.map_item = QGraphicsPixmapItem(pixmap)
        self.map_item.setZValue(0)
        self.scene.addItem(self.map_item)
        self.scene.setSceneRect(QRectF(0, 0, w, h))
        self.view._zoom = 0
        self.view.fitInView(self.scene.sceneRect(), Qt.KeepAspectRatio)

        # 航点绘制层
        self._wp_circles = []
        self._wp_lines = []  # 折线——逐段连接相邻航点

        # 十字线
        self._cross_h = QGraphicsLineItem()
        self._cross_h.setPen(QPen(QColor(0, 200, 255, 150), 1, Qt.DashLine))
        self._cross_h.setZValue(20)
        self._cross_v = QGraphicsLineItem()
        self._cross_v.setPen(QPen(QColor(0, 200, 255, 150), 1, Qt.DashLine))
        self._cross_v.setZValue(20)
        self.scene.addItem(self._cross_h)
        self.scene.addItem(self._cross_v)

        # ---- 原点标记（圆点 + 文字） ----
        px0 = int((0 - self.origin_x) / self.resolution)
        py0 = int(self.img_h - (0 - self.origin_y) / self.resolution)
        if 0 <= px0 < w and 0 <= py0 < h:
            origin_dot = QGraphicsEllipseItem(px0 - 4, py0 - 4, 8, 8)
            origin_dot.setPen(QPen(QColor(0, 200, 255), 2))
            origin_dot.setBrush(QBrush(QColor(0, 200, 255, 60)))
            origin_dot.setZValue(25)
            self.scene.addItem(origin_dot)

    # =================================================================
    # 悬停交互
    # =================================================================
    def on_hover(self, px, py):
        if px < 0 or px >= self.img_w or py < 0 or py >= self.img_h:
            self.hover_label.setText("X: ---   Y: ---")
            self.pixel_label.setText("像素: (---, ---)  值: ---")
            self.dist_label.setText("距原点: --- m")
            self.zone_label.setText("")
            self._cross_h.setLine(0, 0, 0, 0)
            self._cross_v.setLine(0, 0, 0, 0)
            return

        wx, wy = self.px_to_world(px, py)
        ipx, ipy = int(px), int(py)
        val = self.pgm_data[ipy, ipx]
        dist = (wx ** 2 + wy ** 2) ** 0.5

        self.hover_label.setText(f"X: {wx:7.2f}   Y: {wy:7.2f}")
        self.pixel_label.setText(f"像素: ({ipx}, {ipy})  值: {val}")
        self.dist_label.setText(f"距原点: {dist:.2f} m")

        info = self._check_footprint(ipx, ipy)
        n_occ, n_unk, total = info['occupied'], info['unknown'], info['total']

        if n_occ > 0:
            self.zone_label.setText(f"⚠ 障碍物! ({n_occ}px)")
            self.zone_label.setStyleSheet(
                "color: #fff; background: #4a5058; padding: 2px 8px; border-radius: 4px;")
        elif n_unk > total * 0.3:
            self.zone_label.setText(f"⚠ 未知区域 ({n_unk}px)")
            self.zone_label.setStyleSheet(
                "color: #333; background: #ffd33d; padding: 2px 8px; border-radius: 4px;")
        else:
            self.zone_label.setText("✓ 安全")
            self.zone_label.setStyleSheet(
                "color: #fff; background: #4a5058; padding: 2px 8px; border-radius: 4px;")

        self._cross_h.setLine(0, py, self.img_w, py)
        self._cross_v.setLine(px, 0, px, self.img_h)

    def _check_footprint(self, px, py, margin=8):
        x1, x2 = max(0, px - margin), min(self.img_w, px + margin + 1)
        y1, y2 = max(0, py - margin), min(self.img_h, py + margin + 1)
        region = self.pgm_data[y1:y2, x1:x2]
        return {
            'occupied': int(np.sum(region <= 50)),
            'unknown': int(np.sum((region > 50) & (region < 250))),
            'free': int(np.sum(region >= 250)),
            'total': region.size,
        }

    # =================================================================
    # 航点操作
    # =================================================================
    def _click_map(self, px, py):
        """点击地图：检查是否在已有航点附近，是则询问删除，否则添加"""
        HIT_RADIUS = 10  # 像素，点击距航点多近算"选中"
        for i, (wx, wy) in enumerate(self.waypoints_px):
            if ((px - wx) ** 2 + (py - wy) ** 2) ** 0.5 <= HIT_RADIUS:
                reply = QMessageBox.question(
                    self, "删除航点",
                    f"是否删除航点 #{i}？",
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                if reply == QMessageBox.Yes:
                    del self.waypoints_px[i]
                    self._refresh_wp_list()
                    self._redraw_waypoints()
                return
        # 没命中已有航点 → 添加
        self.add_waypoint(px, py)

    def add_waypoint(self, px, py, silent=False):
        info = self._check_footprint(px, py)
        if info['occupied'] > 0 and not silent:
            r = QMessageBox.warning(self, "⚠ 障碍物区域",
                f"该位置 {info['occupied']} 个障碍物像素！\n是否仍然添加？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if r == QMessageBox.No:
                return
        elif info['unknown'] > info['total'] * 0.3 and not silent:
            r = QMessageBox.question(self, "⚠ 未知区域",
                f"该位置 {info['unknown']}/{info['total']} 像素为未知区域。\n是否仍然添加？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if r == QMessageBox.No:
                return

        self.waypoints_px.append((px, py))
        self._refresh_wp_list()
        self._redraw_waypoints()

    def remove_last_waypoint(self):
        if self.waypoints_px:
            self.waypoints_px.pop()
            self._refresh_wp_list()
            self._redraw_waypoints()

    def _delete_selected_wp(self):
        row = self.wp_list.currentRow()
        if 0 <= row < len(self.waypoints_px):
            del self.waypoints_px[row]
            self._refresh_wp_list()
            self._redraw_waypoints()

    def _clear_all_wp(self):
        self.waypoints_px.clear()
        self._refresh_wp_list()
        self._redraw_waypoints()

    def _on_wp_double_click(self, item):
        row = self.wp_list.row(item)
        if 0 <= row < len(self.waypoints_px):
            px, py = self.waypoints_px[row]
            wx, wy = self.px_to_world(px, py)
            self.view.centerOn(px, py)

    def _refresh_wp_list(self):
        self.wp_list.clear()
        for i, (px, py) in enumerate(self.waypoints_px):
            wx, wy = self.px_to_world(px, py)
            self.wp_list.addItem(f"#{i}: ({wx:.2f}, {wy:.2f})")

    def _redraw_waypoints(self):
        for c in self._wp_circles:
            self.scene.removeItem(c)
        self._wp_circles.clear()
        for line in self._wp_lines:
            self.scene.removeItem(line)
        self._wp_lines.clear()

        if not self.waypoints_px:
            return

        # 折线：逐段连接相邻航点
        for i in range(len(self.waypoints_px) - 1):
            x1, y1 = self.waypoints_px[i]
            x2, y2 = self.waypoints_px[i + 1]
            line = QGraphicsLineItem(x1, y1, x2, y2)
            line.setPen(QPen(QColor(255, 80, 80), 2, Qt.DashLine))
            line.setZValue(10)
            self.scene.addItem(line)
            self._wp_lines.append(line)

        # 首尾闭合（2个以上航点），浅色区分
        if len(self.waypoints_px) >= 2:
            x1, y1 = self.waypoints_px[-1]
            x2, y2 = self.waypoints_px[0]
            line = QGraphicsLineItem(x1, y1, x2, y2)
            line.setPen(QPen(QColor(255, 130, 130), 1.5, Qt.DotLine))
            line.setZValue(9)
            self.scene.addItem(line)
            self._wp_lines.append(line)

        for i, (px, py) in enumerate(self.waypoints_px):
            r = 5
            c = QGraphicsEllipseItem(px - r, py - r, r * 2, r * 2)
            c.setZValue(15)
            c.setPen(QPen(QColor(255, 50, 50), 2))
            c.setBrush(QBrush(QColor(255, 100, 100, 180)))
            c.setToolTip(f"#{i}: ({px},{py})")
            self.scene.addItem(c)
            self._wp_circles.append(c)

    # =================================================================
    # 工具功能
    # =================================================================
    def _fix_map(self, radius_m=0.70):
        """清除原点周围指定半径内的所有障碍物"""
        R = int(radius_m / self.resolution)
        px0 = int((0 - self.origin_x) / self.resolution)
        py0 = int(self.img_h - (0 - self.origin_y) / self.resolution)

        cleared = 0
        for dy in range(-R, R + 1):
            for dx in range(-R, R + 1):
                px, py = px0 + dx, py0 + dy
                if 0 <= px < self.img_w and 0 <= py < self.img_h:
                    if self.pgm_data[py, px] <= 50:
                        self.pgm_data[py, px] = 254
                        cleared += 1

        if cleared == 0:
            QMessageBox.information(self, "完成", "原点周围没有障碍物像素，无需清除。")
            return

        # 保存 PGM → install
        bak = self._pgm_path + '.bak'
        if not os.path.exists(bak):
            shutil.copy2(self._pgm_path, bak)

        with open(self._pgm_path, 'wb') as f:
            f.write(b'P5\n')
            f.write(f'{self.img_w} {self.img_h}\n'.encode())
            f.write(b'255\n')
            f.write(self.pgm_data.tobytes())

        # 同步写回 src（install → src 反推）
        pgm_name = os.path.basename(self._pgm_path)
        script_dir = os.path.dirname(os.path.abspath(__file__))
        ws_install = os.path.dirname(os.path.dirname(
            os.path.dirname(os.path.dirname(script_dir))))
        ws_root = os.path.dirname(ws_install)
        src_candidates = [
            os.path.join(ws_root, 'src', 'wheeltec_robot_nav2', 'map', pgm_name),
        ]
        src_saved = False
        for src_path in src_candidates:
            if os.path.exists(os.path.dirname(src_path)):
                shutil.copy2(self._pgm_path, src_path)
                src_saved = True
                break
        if not src_saved:
            # 回退：在 src/ 下递归搜索同名文件
            src_dir = os.path.join(ws_root, 'src')
            if os.path.isdir(src_dir):
                for root, dirs, files in os.walk(src_dir):
                    if pgm_name in files:
                        shutil.copy2(self._pgm_path, os.path.join(root, pgm_name))
                        src_saved = True
                        break

        # 刷新显示
        self._render_map()
        msg = (f"已清除原点 {radius_m:.2f}m 半径内 {cleared} 个障碍物像素\n"
               f"install: {self._pgm_path}\n备份: {bak}")
        if src_saved:
            msg += f"\nsrc: 已同步"
        QMessageBox.information(self, "完成", msg)

    # =================================================================
    # 建图控制
    # =================================================================
    def _start_mapping(self):
        """开启建图：根据选择的算法启动 slam + rviz2"""
        if self._slam_process is not None and self._slam_process.poll() is None:
            QMessageBox.information(self, "提示", "建图已在运行中。")
            return

        algo = self.slam_algo_combo.currentData()
        if algo == "slam_toolbox":
            slam_cmd = "ros2 launch wheeltec_slam_toolbox online_sync.launch.py"
            algo_name = "slam_toolbox"
        elif algo == "cartographer":
            slam_cmd = "ros2 launch wheeltec_cartographer cartographer.launch.py"
            algo_name = "cartographer"
        else:
            slam_cmd = "ros2 launch slam_gmapping slam_gmapping.launch.py"
            algo_name = "slam_gmapping"

        try:
            cmd = (f"{slam_cmd} "
                   "& ros2 launch wheeltec_rviz2 wheeltec_rviz.launch.py & wait")
            self._slam_process = subprocess.Popen(
                cmd, shell=True, executable='/bin/bash',
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                preexec_fn=os.setsid)
            self.showMinimized()  # 最小化控制台，让出屏幕给 RViz2
            self.status.showMessage(f"建图已启动 ({algo_name} + rviz2)，控制台已最小化", 0)
            print(f"[建图] {algo_name} + rviz2 已启动")
        except Exception as e:
            QMessageBox.warning(self, "错误", f"启动建图失败:\n{e}")

    def _stop_mapping(self):
        """停止建图"""
        if self._slam_process is None or self._slam_process.poll() is not None:
            QMessageBox.information(self, "提示", "建图未在运行。")
            return
        try:
            # 杀掉整个进程组
            os.killpg(os.getpgid(self._slam_process.pid), 2)  # SIGINT
            self._slam_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(os.getpgid(self._slam_process.pid), 9)  # SIGKILL
            self._slam_process.wait()
        except Exception:
            pass
        self._slam_process = None
        self.showFullScreen()  # 恢复全屏
        QMessageBox.information(self, "建图", "建图已停止，控制台已恢复。")
        print("[建图] 已停止")

    # =================================================================
    # 巡航控制
    # =================================================================
    def _start_cruise(self):
        """启动巡航任务: ros2 launch wheeltec_mission mission.launch.py
        日志自动保存到 ~/mission_log/ 目录"""
        if self._cruise_process is not None and self._cruise_process.poll() is None:
            QMessageBox.information(self, "提示", "巡航已在运行中。")
            return

        # 确认弹窗：提醒将机器人放到建图起始点
        reply = QMessageBox.question(
            self, "启动巡航",
            "请确认机器人已放置在建图起始点\n\n"
            "（建图时的原点位置，方向与建图时一致）\n\n"
            "确认启动？",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply != QMessageBox.Yes:
            return

        import time
        log_dir = os.path.expanduser('~/mission_log')
        os.makedirs(log_dir, exist_ok=True)
        timestamp = time.strftime('%Y%m%d_%H%M%S')
        log_file = os.path.join(log_dir, f'mission_{timestamp}.log')

        cmd = (
            f"ros2 launch wheeltec_mission mission.launch.py "
            f"2>&1 | tee {log_file}"
        )
        try:
            self._cruise_process = subprocess.Popen(
                cmd, shell=True, executable='/bin/bash',
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                preexec_fn=os.setsid)
            self.status.showMessage(f"巡航任务启动中，日志: {log_file}", 0)
            print(f"[巡航] 启动: {cmd}")
            print(f"[巡航] 日志文件: {log_file}")
        except Exception as e:
            QMessageBox.warning(self, "错误", f"启动巡航失败:\n{e}")
            print(f"[巡航] 启动失败: {e}")

    def _stop_cruise(self):
        """停止巡航任务"""
        if self._cruise_process is None or self._cruise_process.poll() is not None:
            QMessageBox.information(self, "提示", "巡航未在运行。")
            self._cruise_process = None
            return
        try:
            os.killpg(os.getpgid(self._cruise_process.pid), 2)  # SIGINT
            self._cruise_process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(os.getpgid(self._cruise_process.pid), 9)  # SIGKILL
            self._cruise_process.wait()
        except Exception:
            pass
        self._cruise_process = None
        QMessageBox.information(self, "巡航", "巡航已停止。")
        print("[巡航] 已停止")

    def _save_map_launch(self):
        """执行 ros2 launch wheeltec_nav2 save_map.launch.py"""
        try:
            self.status.showMessage("正在保存地图...", 0)
            result = subprocess.run(
                "ros2 launch wheeltec_nav2 save_map.launch.py",
                shell=True, executable='/bin/bash',
                capture_output=True, text=True, timeout=30)
            print(result.stdout)
            if result.returncode == 0:
                QMessageBox.information(self, "存图", "地图保存完成！")
                print("[存图] 完成")
            else:
                QMessageBox.warning(self, "存图", "存图失败，请查看控制台日志。")
                print(f"[存图] 失败:\n{result.stderr}")
        except subprocess.TimeoutExpired:
            QMessageBox.warning(self, "错误", "存图超时（30秒）")
        except Exception as e:
            QMessageBox.warning(self, "错误", f"存图失败:\n{e}")

    def _refresh_map(self):
        """重新加载 install 下的地图文件并刷新显示"""
        try:
            self.pgm_data = self._read_pgm(self._pgm_path)
            self.img_h, self.img_w = self.pgm_data.shape
            self._render_map()
            self._redraw_waypoints()
            self.status.showMessage("地图已刷新", 3000)
            print("[刷新] 地图已重新加载")
        except Exception as e:
            QMessageBox.warning(self, "错误", f"刷新地图失败:\n{e}")

    def export_config(self):
        """输出到终端"""
        if not self.waypoints_px:
            print("\n未选择航点。")
            return
        print("\n" + "=" * 50)
        print(" 复制以下到 mission.yaml:")
        print("=" * 50)
        print("  waypoints:")
        for i, (px, py) in enumerate(self.waypoints_px):
            wx, wy = self.px_to_world(px, py)
            print(f"    - {{x: {wx:.2f}, y: {wy:.2f}, yaw: 0.0}}")
        print("=" * 50)

    # =================================================================
    # mission.yaml 读写
    # =================================================================
    def _load_mission_yaml(self):
        try:
            with open(self.mission_yaml_path, 'r') as f:
                cfg = yaml.safe_load(f)
            wps = cfg.get('mission', {}).get('waypoints', [])
            self.waypoints_px.clear()
            for wp in wps:
                px, py = self.world_to_px(wp['x'], wp['y'])
                self.add_waypoint(px, py, silent=True)
            self._refresh_wp_list()
            self._redraw_waypoints()
            self.status.showMessage(f"已加载 {len(wps)} 个航点", 3000)
        except Exception as e:
            QMessageBox.warning(self, "错误", f"读取失败: {e}")

    def _load_mission_yaml_dialog(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "选择 mission.yaml", "", "YAML (*.yaml *.yml)")
        if path:
            self.mission_yaml_path = path
            self._load_mission_yaml()

    def _save_mission_yaml(self):
        if not self.mission_yaml_path:
            path, _ = QFileDialog.getSaveFileName(
                self, "保存 mission.yaml", "", "YAML (*.yaml *.yml)")
            if not path:
                return
            self.mission_yaml_path = path

        try:
            # 尝试保留原有结构
            if os.path.exists(self.mission_yaml_path):
                with open(self.mission_yaml_path, 'r') as f:
                    cfg = yaml.safe_load(f) or {}
            else:
                cfg = {}
            if 'mission' not in cfg:
                cfg['mission'] = {}
            cfg['mission']['waypoints'] = []
            for px, py in self.waypoints_px:
                wx, wy = self.px_to_world(px, py)
                cfg['mission']['waypoints'].append({'x': round(wx, 2), 'y': round(wy, 2), 'yaw': 0.0})

            with open(self.mission_yaml_path, 'w') as f:
                yaml.dump(cfg, f, default_flow_style=False, allow_unicode=True, sort_keys=False)

            # 同步写回 src
            yaml_name = os.path.basename(self.mission_yaml_path)
            script_dir = os.path.dirname(os.path.abspath(__file__))
            # install 路径: <ws>/install/wheeltec_mission/lib/wheeltec_mission/
            ws_install = os.path.dirname(os.path.dirname(
                os.path.dirname(os.path.dirname(script_dir))))
            ws_root = os.path.dirname(ws_install)

            # 候选 src 路径（按优先级）
            src_candidates = [
                os.path.join(ws_root, 'src', 'wheeltec_mission', 'config', yaml_name),
            ]
            # 如果 ws_root 下面没有 src，尝试 ws_root 本身（扁平项目结构）
            if os.path.isdir(ws_root) and not os.path.isdir(os.path.join(ws_root, 'src')):
                for d in os.listdir(ws_root):
                    p = os.path.join(ws_root, d, 'config', yaml_name)
                    if os.path.exists(os.path.dirname(p)):
                        src_candidates.append(p)

            src_saved_path = None
            for src_path in src_candidates:
                os.makedirs(os.path.dirname(src_path), exist_ok=True)
                shutil.copy2(self.mission_yaml_path, src_path)
                src_saved_path = src_path
                break

            if src_saved_path is None:
                # 回退：在整个 ws_root 下搜（排除 install）
                for root, dirs, files in os.walk(ws_root):
                    dirs[:] = [d for d in dirs if 'install' not in d.split(os.sep)]
                    if yaml_name in files and 'mission' in root:
                        p = os.path.join(root, yaml_name)
                        shutil.copy2(self.mission_yaml_path, p)
                        src_saved_path = p
                        break

            msg = f"install: {self.mission_yaml_path}"
            if src_saved_path:
                msg += f"\nsrc:     {src_saved_path}"
            else:
                msg += "\nsrc:     未找到，未同步"
            QMessageBox.information(self, "保存完成", msg)
        except Exception as e:
            QMessageBox.warning(self, "错误", f"保存失败: {e}")


# =====================================================================
# Entry
# =====================================================================
def _find_install_dir():
    """根据本脚本路径 + AMENT_PREFIX_PATH 推断文件位置"""
    candidates = []

    # 方法1: 从脚本路径推断 workspace install 根目录
    # 脚本在: install/wheeltec_mission/lib/wheeltec_mission/mission_console
    script_dir = os.path.dirname(os.path.abspath(__file__))
    ws_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(script_dir))))
    candidates.append(ws_root)

    # 方法2: AMENT_PREFIX_PATH
    for p in os.environ.get('AMENT_PREFIX_PATH', '').split(os.pathsep):
        if p.strip():
            candidates.append(p.strip())

    # 方法3: 常见默认路径
    candidates.append(os.path.expanduser('~/wheeltec_ros2/install'))

    for d in candidates:
        map_yaml = os.path.join(d, 'wheeltec_nav2', 'share', 'wheeltec_nav2', 'map', 'WHEELTEC.yaml')
        if os.path.exists(map_yaml):
            mission_yaml = os.path.join(d, 'wheeltec_mission', 'share', 'wheeltec_mission', 'config', 'mission.yaml')
            return map_yaml, mission_yaml

    return None, None


def main():
    map_default, mission_default = _find_install_dir()

    parser = argparse.ArgumentParser(description='Mission Console — 巡航任务控制台')
    parser.add_argument('map_yaml', nargs='?', default=map_default,
                        help='地图 YAML 路径（自动检测）')
    parser.add_argument('mission_yaml', nargs='?', default=mission_default,
                        help='mission.yaml 路径（自动检测）')
    args, _ = parser.parse_known_args()

    if not args.map_yaml or not os.path.exists(args.map_yaml):
        print(f'[ERROR] 找不到地图文件，请传入路径: mission_console <WHEELTEC.yaml>')
        sys.exit(1)

    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    console = MissionConsole(args.map_yaml, args.mission_yaml)
    console.showFullScreen()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
