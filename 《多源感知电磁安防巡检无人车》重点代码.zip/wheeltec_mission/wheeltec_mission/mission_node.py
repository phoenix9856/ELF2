"""
mission_node.py - One-click mission execution for Wheeltec robot.

Reads a YAML config file to:
1. Set the initial pose (replaces RViz "2D Pose Estimate")
2. Navigate through waypoints in a loop (replaces RViz "Publish Point" + waypoint_cycle)

Usage:
    ros2 launch wheeltec_mission mission.launch.py
"""

import json
import math
import os
import sys
import time
import yaml

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.duration import Duration

from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped
from nav2_msgs.action import NavigateToPose
from action_msgs.msg import GoalStatus
from sensor_msgs.msg import Imu
from std_msgs.msg import Empty, String, Float32MultiArray
from ament_index_python.packages import get_package_share_directory

from rcl_interfaces.srv import SetParameters
from rclpy.parameter import Parameter


class MissionNode(Node):
    """Mission node: set initial pose, then cruise waypoints."""

    def __init__(self, config_file=None):
        super().__init__('mission_node')

        # Load config
        if config_file is None:
            config_file = os.path.join(
                get_package_share_directory('wheeltec_mission'),
                'config', 'mission.yaml')
        self.get_logger().info(f'Loading mission config: {config_file}')
        self.config = self._load_config(config_file)

        # Publishers
        self.initial_pose_pub = self.create_publisher(
            PoseWithCovarianceStamped, '/initialpose', 10)

        # Signal scan/tracking publishers
        self.scan_trigger_pub = self.create_publisher(
            Float32MultiArray, '/start_scan_angles', 10)
        self.tracking_trigger_pub = self.create_publisher(
            Empty, '/start_source_tracking', 10)

        # Subscribers
        self.amcl_pose_received = False
        self.amcl_pose_sub = self.create_subscription(
            PoseWithCovarianceStamped, '/amcl_pose',
            self._amcl_pose_callback, 10)

        # IMU for current heading (used as scan start angle)
        self.current_yaw = 0.0
        self.imu_sub = self.create_subscription(
            Imu, '/imu/data_raw', self._imu_callback, 10)

        # Scan result subscriber
        self.scan_result_sub = self.create_subscription(
            String, '/all_direction_signal_detecting_result',
            self._scan_result_callback, 10)

        # Action client for NavigateToPose
        self.nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')

        # State
        self.current_waypoint_index = 0
        self.retry_count = 0
        self.goal_handle = None
        self.result_future = None
        self.mission_active = False
        self.waiting_for_scan = False  # True while waiting for scan result at waypoint

        # Signal tracking config
        self.scan_enabled = self.config.get('scan_at_waypoint', True)
        self.signal_threshold = self.config.get('signal_threshold', -60.0)
        self.get_logger().info(
            f'Signal scan at waypoint: {"enabled" if self.scan_enabled else "disabled"}, '
            f'threshold={self.signal_threshold} dB')

        # Timer to start mission after a short delay (let Nav2 finish starting up)
        self.start_timer = self.create_timer(2.0, self._start_mission)

        self.get_logger().info('MissionNode initialized — waiting for Nav2 startup...')

    # ------------------------------------------------------------------
    # Config
    # ------------------------------------------------------------------

    def _load_config(self, path):
        """Load and validate the mission YAML config."""
        if not os.path.exists(path):
            self.get_logger().fatal(f'Config file not found: {path}')
            sys.exit(1)

        with open(path, 'r') as f:
            cfg = yaml.safe_load(f)

        mission = cfg.get('mission', {})
        if not mission:
            self.get_logger().fatal("Config missing top-level 'mission' key")
            sys.exit(1)

        # Validate required fields
        for field in ['initial_pose', 'waypoints']:
            if field not in mission:
                self.get_logger().fatal(f"Config missing 'mission.{field}'")
                sys.exit(1)

        ip = mission['initial_pose']
        for coord in ['x', 'y', 'yaw']:
            if coord not in ip:
                self.get_logger().fatal(f"Config missing 'mission.initial_pose.{coord}'")
                sys.exit(1)

        wp = mission['waypoints']
        if not wp or len(wp) == 0:
            self.get_logger().fatal('Config must have at least one waypoint')
            sys.exit(1)

        self.get_logger().info(
            f'Loaded {len(wp)} waypoints, '
            f'initial_pose=({ip["x"]:.2f}, {ip["y"]:.2f}, {ip["yaw"]:.2f}), '
            f'loop={mission.get("loop", True)}, '
            f'dwell={mission.get("dwell_time", 0):.1f}s, '
            f'max_speed={mission.get("max_speed", "default")}, '
            f'scan_at_waypoint={mission.get("scan_at_waypoint", True)}, '
            f'signal_threshold={mission.get("signal_threshold", -60.0)} dB')
        return mission

    # ------------------------------------------------------------------
    # Initial pose
    # ------------------------------------------------------------------

    def _amcl_pose_callback(self, msg):
        """Called when AMCL publishes its pose estimate."""
        self.amcl_pose_received = True

    def _imu_callback(self, msg):
        """Track current yaw from IMU for scan start angle."""
        x = msg.orientation.x
        y = msg.orientation.y
        z = msg.orientation.z
        w = msg.orientation.w
        siny_cosp = 2.0 * (w * z + x * y)
        cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
        self.current_yaw = math.degrees(math.atan2(siny_cosp, cosy_cosp)) % 360.0

    def _set_initial_pose(self):
        """Publish initial pose to /initialpose once.

        Does NOT wait for amcl_pose — AMCL publishes amcl_pose only after the
        particle filter converges on laser scans, which can take a long time if
        the initial pose is in a bad map area. Navigation can start before
        full convergence; AMCL refines the pose while the robot moves.
        """
        ip = self.config['initial_pose']
        yaw = ip['yaw']

        msg = PoseWithCovarianceStamped()
        msg.header.frame_id = 'map'
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.pose.pose.position.x = float(ip['x'])
        msg.pose.pose.position.y = float(ip['y'])
        msg.pose.pose.position.z = 0.0
        msg.pose.pose.orientation.z = math.sin(yaw / 2.0)
        msg.pose.pose.orientation.w = math.cos(yaw / 2.0)
        msg.pose.covariance = [
            0.25, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.25, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.0, 0.0, 0.0, 0.0, 0.06853892326654787,
        ]

        self.initial_pose_pub.publish(msg)
        self.get_logger().info(
            f'Published initial pose: ({ip["x"]:.2f}, {ip["y"]:.2f}, '
            f'yaw={yaw:.2f}) — AMCL will converge while robot moves')

        # Brief wait so AMCL can at least receive and process the message
        # before the BT navigator starts (which needs initial_pose_received).
        deadline = time.time() + 10.0
        while time.time() < deadline:
            rclpy.spin_once(self, timeout_sec=0.2)
            if self.amcl_pose_received:
                self.get_logger().info(
                    f'Initial pose confirmed by AMCL! (fast converge)')
                return True

        # Not confirmed, but proceed anyway — AMCL will converge during motion
        self.get_logger().warn(
            'AMCL pose not confirmed within 10s, '
            'proceeding anyway (will localize during movement)')
        return True

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def _set_controller_max_speed(self, speed_mps):
        """Dynamically set controller_server max linear velocity."""
        param_cli = self.create_client(
            SetParameters, '/controller_server/set_parameters')
        if not param_cli.wait_for_service(timeout_sec=3.0):
            self.get_logger().warn(
                'controller_server param service not available, '
                'max_speed not applied')
            return

        req = SetParameters.Request()
        p = Parameter('FollowPath.vx_max', Parameter.Type.DOUBLE, speed_mps)
        req.parameters = [p.to_parameter_msg()]

        future = param_cli.call_async(req)
        rclpy.spin_until_future_complete(self, future, timeout_sec=2.0)

        if future.done() and future.result() is not None:
            results = future.result().results
            if results and results[0].successful:
                self.get_logger().info(
                    f'Max speed set to {speed_mps:.2f} m/s')
            else:
                self.get_logger().warn(
                    f'Failed to set max_speed: {results[0].reason if results else "no result"}')
        else:
            self.get_logger().warn('max_speed param call timed out')

    def _start_mission(self):
        """Called by timer after Nav2 has time to start up."""
        self.start_timer.cancel()

        # Step 1: Set initial pose
        self.get_logger().info('=' * 50)
        self.get_logger().info('STEP 1: Setting initial pose...')
        if not self._set_initial_pose():
            self.get_logger().error('Cannot start mission without initial pose')
            return

        # Step 2: Wait for Nav2 action server
        self.get_logger().info('=' * 50)
        self.get_logger().info('STEP 2: Waiting for Nav2 action server...')
        if not self.nav_client.wait_for_server(timeout_sec=10.0):
            self.get_logger().error('NavigateToPose action server not available')
            return
        self.get_logger().info('Nav2 action server ready!')

        # Step 2.5: Set max speed if configured
        max_speed = self.config.get('max_speed', None)
        if max_speed is not None:
            self._set_controller_max_speed(float(max_speed))

        # Step 3: Start waypoint navigation
        self.get_logger().info('=' * 50)
        self.get_logger().info('STEP 3: Starting waypoint navigation...')
        self.mission_active = True
        self._navigate_to_next_waypoint()

    def _navigate_to_next_waypoint(self):
        """Send the current waypoint as a navigation goal."""
        if not self.mission_active:
            return

        waypoints = self.config['waypoints']
        idx = self.current_waypoint_index
        wp = waypoints[idx]
        yaw = wp.get('yaw', 0.0)

        self.get_logger().info(
            f'>>> Navigating to waypoint {idx}: ({wp["x"]:.2f}, {wp["y"]:.2f})')

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = 'map'
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = float(wp['x'])
        goal_msg.pose.pose.position.y = float(wp['y'])
        goal_msg.pose.pose.position.z = 0.0
        goal_msg.pose.pose.orientation.z = math.sin(yaw / 2.0)
        goal_msg.pose.pose.orientation.w = math.cos(yaw / 2.0)
        goal_msg.behavior_tree = ''  # Use default behavior tree

        self._send_goal(goal_msg)

    def _send_goal(self, goal_msg):
        """Send goal and set up async result handling."""
        send_goal_future = self.nav_client.send_goal_async(
            goal_msg, feedback_callback=self._feedback_callback)
        send_goal_future.add_done_callback(self._goal_response_callback)

    def _goal_response_callback(self, future):
        """Handle goal acceptance/rejection."""
        self.goal_handle = future.result()
        if not self.goal_handle or not self.goal_handle.accepted:
            self.get_logger().error('Navigation goal was REJECTED by server')
            self._handle_navigation_failure()
            return

        self.get_logger().info('Navigation goal ACCEPTED — robot is moving!')
        self.result_future = self.goal_handle.get_result_async()
        self.result_future.add_done_callback(self._result_callback)

    def _feedback_callback(self, feedback_msg):
        """Log navigation progress periodically."""
        feedback = feedback_msg.feedback
        remaining = Duration.from_msg(feedback.estimated_time_remaining).nanoseconds / 1e9
        distance = feedback.distance_remaining
        if feedback.number_of_recoveries > 0:
            self.get_logger().info(
                f'Recoveries: {feedback.number_of_recoveries}')

    def _result_callback(self, future):
        """Handle navigation result."""
        status = future.result().status
        idx = self.current_waypoint_index
        wp = self.config['waypoints'][idx]

        if status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info(
                f'<<< Waypoint {idx} ({wp["x"]:.2f}, {wp["y"]:.2f}) REACHED!')
            self.retry_count = 0

            # Dwell at waypoint if configured
            dwell = self.config.get('dwell_time', 0)
            if dwell > 0:
                self.get_logger().info(f'Pausing {dwell:.1f}s at waypoint...')
                time.sleep(dwell)

            # Trigger omnidirectional scan at waypoint if enabled
            if self.scan_enabled:
                self._trigger_waypoint_scan()
            else:
                self._advance_waypoint()

        elif status == GoalStatus.STATUS_CANCELED:
            self.get_logger().warn(f'Waypoint {idx} was CANCELED')
            self.retry_count = 0
            self._advance_waypoint()

        else:
            self.get_logger().error(
                f'Waypoint {idx} FAILED (status={status})')
            self._handle_navigation_failure()

    def _handle_navigation_failure(self):
        """Retry once after a 1s delay, then skip to next waypoint."""
        self.retry_count += 1
        idx = self.current_waypoint_index

        if self.retry_count <= 1:
            self.get_logger().warn(
                f'Retrying waypoint {idx} in 1s (attempt {self.retry_count + 1})...')
            # One-shot timer for delayed retry
            retry_timer = self.create_timer(1.0, self._retry_callback)
            # Store reference so it doesn't get garbage collected before firing
            self._active_retry_timer = retry_timer
        else:
            self.get_logger().warn(
                f'Skipping waypoint {idx} after failed retry')
            self.retry_count = 0
            self._advance_waypoint()

    def _retry_callback(self):
        """Called after retry delay; cancel the timer and restart navigation."""
        if hasattr(self, '_active_retry_timer'):
            self._active_retry_timer.cancel()
        self._navigate_to_next_waypoint()

    # ------------------------------------------------------------------
    # Signal scan at waypoint
    # ------------------------------------------------------------------

    def _trigger_waypoint_scan(self):
        """Trigger a 360° omnidirectional scan at the current waypoint.

        The scan starts from the robot's current heading to avoid unnecessary
        rotation.  Results arrive asynchronously via _scan_result_callback.
        """
        self.waiting_for_scan = True
        ang_speed = float(self.config.get('scan_ang_speed', 0.4))
        scan_msg = Float32MultiArray()
        scan_msg.data = [
            float(self.current_yaw),
            float(self.current_yaw + 360.0),
            ang_speed,
        ]
        self.scan_trigger_pub.publish(scan_msg)
        self.get_logger().info(
            f'=== Triggered 360° scan at waypoint {self.current_waypoint_index} '
            f'(start={self.current_yaw:.1f}°, ang_speed={ang_speed:.2f} rad/s) ===')

    def _scan_result_callback(self, msg):
        """Process scan results: if signal > threshold, switch to tracking."""
        if not self.waiting_for_scan:
            return

        try:
            data = json.loads(msg.data)
            best_power = float(data.get('best_power', -100.0))
            best_angle = float(data.get('best_angle', 0.0))
        except Exception as e:
            self.get_logger().error(f'Failed to parse scan result: {e}')
            self.waiting_for_scan = False
            self._advance_waypoint()
            return

        self.get_logger().info(
            f'Scan result at waypoint {self.current_waypoint_index}: '
            f'best_angle={best_angle:.1f}°, best_power={best_power:.1f} dB, '
            f'threshold={self.signal_threshold:.1f} dB')

        if best_power > self.signal_threshold:
            self.get_logger().info(
                f'!!! STRONG SIGNAL DETECTED ({best_power:.1f} dB > {self.signal_threshold:.1f} dB) !!!\n'
                f'    Terminating navigation, launching electromagnetic tracking...')
            self.waiting_for_scan = False

            # Cancel any active navigation goal
            if self.goal_handle is not None:
                self.get_logger().info('Cancelling active navigation goal...')
                cancel_future = self.goal_handle.cancel_goal_async()
                # Wait briefly for cancellation to process
                rclpy.spin_until_future_complete(self, cancel_future, timeout_sec=2.0)

            # Stop mission navigation
            self.mission_active = False

            # Trigger electromagnetic following via signal_tracking
            self.tracking_trigger_pub.publish(Empty())
            self.get_logger().info(
                'Published /start_source_tracking — electromagnetic following ACTIVE.\n'
                'Mission navigation TERMINATED.')
        else:
            self.get_logger().info(
                f'No strong signal ({best_power:.1f} dB <= {self.signal_threshold:.1f} dB), '
                f'continuing to next waypoint.')
            self.waiting_for_scan = False
            self._advance_waypoint()

    # ------------------------------------------------------------------
    # Waypoint advancement
    # ------------------------------------------------------------------

    def _advance_waypoint(self):
        """Move to the next waypoint (or loop)."""
        waypoints = self.config['waypoints']
        loop = self.config.get('loop', True)

        self.current_waypoint_index += 1

        if self.current_waypoint_index >= len(waypoints):
            if loop:
                self.get_logger().info(
                    '=== All waypoints completed — LOOPING back to first ===')
                self.current_waypoint_index = 0
            else:
                self.get_logger().info(
                    '=== All waypoints completed — mission DONE! ===')
                self.mission_active = False
                return

        self._navigate_to_next_waypoint()


def main(args=None):
    rclpy.init(args=args)

    # Allow overriding config file via command line
    config_file = None
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, default=None,
                        help='Path to mission.yaml')
    parsed, _ = parser.parse_known_args()
    if parsed.config:
        config_file = parsed.config

    node = MissionNode(config_file=config_file)

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Mission interrupted by user')
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
