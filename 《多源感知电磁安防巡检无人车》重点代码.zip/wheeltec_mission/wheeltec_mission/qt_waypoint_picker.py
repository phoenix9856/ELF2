#!/usr/bin/env python3
"""
qt_waypoint_picker.py — PyQt5 地图巡航点选择工具

特性:
  - 鼠标悬停实时显示地图坐标 (x, y)
  - 自动检测障碍物/未知区域，红色高亮不可选区域
  - 平滑缩放（以鼠标为中心，步长小不跳变）
  - 左键添加航点，右键删除，Enter 完成输出
  - 输出格式可直接复制到 mission.yaml

用法:
  ros2 run wheeltec_mission pick_waypoints_qt <地图yaml路径>

依赖: PyQt5, numpy, pyyaml (pip install PyQt5)
"""

import math
import os
import sys
import argparse

import numpy as np
import yaml
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QGraphicsView, QGraphicsScene,
    QGraphicsPixmapItem, QStatusBar, QLabel, QMessageBox,
    QGraphicsEllipseItem, QGraphicsLineItem, QMenu, QAction,
)
from PyQt5.QtCore import Qt, QPointF, QRectF
from PyQt5.QtGui import (
    QPixmap, QImage, QPen, QColor, QBrush, QPainter, QFont,
    QTransform,
)


class MapView(QGraphicsView):
    """支持平滑缩放、坐标跟踪、点击选点的地图视图"""

    def __init__(self, scene, picker):
        super().__init__(scene)
        self.picker = picker
        self._zoom = 0
        self._zoom_factor = 1.12  # 每次滚轮缩放倍率（小步长）
        self._max_zoom = 40
        self._min_zoom = -20

        self.setRenderHints(QPainter.Antialiasing | QPainter.SmoothPixmapTransform)
        self.setDragMode(QGraphicsView.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.AnchorUnderMouse)
        self.setViewportUpdateMode(QGraphicsView.SmartViewportUpdate)
        self.setMouseTracking(True)  # 鼠标移动即触发事件
        self.setFocusPolicy(Qt.StrongFocus)

    def wheelEvent(self, event):
        """平滑缩放，每次 12%"""
        if event.angleDelta().y() > 0:
            factor = self._zoom_factor
        else:
            factor = 1.0 / self._zoom_factor

        if (self._zoom >= self._max_zoom and factor > 1) or \
           (self._zoom <= self._min_zoom and factor < 1):
            return

        self._zoom += 1 if factor > 1 else -1
        self.scale(factor, factor)

    def mouseMoveEvent(self, event):
        """实时更新鼠标坐标"""
        pos = self.mapToScene(event.pos())
        self.picker.update_cursor_pos(pos.x(), pos.y())
        super().mouseMoveEvent(event)

    def mousePressEvent(self, event):
        """左键添加、右键删除"""
        pos = self.mapToScene(event.pos())
        px, py = pos.x(), pos.y()

        if px < 0 or px >= self.picker.img_w or py < 0 or py >= self.picker.img_h:
            super().mousePressEvent(event)
            return

        if event.button() == Qt.LeftButton:
            self.picker._add_waypoint(int(px), int(py))
        elif event.button() == Qt.RightButton:
            self.picker._remove_last()
        else:
            super().mousePressEvent(event)

    def keyPressEvent(self, event):
        """Enter 完成，Esc 退出"""
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            self.picker._finish()
        elif event.key() == Qt.Key_Escape:
            self.picker.close()
        else:
            super().keyPressEvent(event)


class WaypointPicker(QMainWindow):
    def __init__(self, map_yaml_path):
        super().__init__()
        self.setWindowTitle("Waypoint Picker")
        self.resize(1400, 900)

        # ---- 加载地图 ----
        self._load_map(map_yaml_path)

        # ---- UI 布局 ----
        self.scene = QGraphicsScene(self)
        self.view = MapView(self.scene, self)
        self.setCentralWidget(self.view)

        # 状态栏
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        font = QFont("Monospace", 10)
        self.coord_label = QLabel(" X: ---   Y: ---")
        self.coord_label.setFont(font)
        self.coord_label.setStyleSheet("color: #333; padding: 2px 8px;")
        self.status.addPermanentWidget(self.coord_label)

        self.pixel_label = QLabel(" 像素: (---, ---)  值: ---")
        self.pixel_label.setFont(font)
        self.pixel_label.setStyleSheet("color: #555; padding: 2px 8px;")
        self.status.addPermanentWidget(self.pixel_label)

        self.zone_label = QLabel("")
        self.zone_label.setFont(QFont("Sans", 10, QFont.Bold))
        self.zone_label.setStyleSheet("padding: 2px 12px; border-radius: 4px;")
        self.status.addWidget(self.zone_label)

        self.count_label = QLabel(" 已选: 0 个点")
        self.count_label.setFont(font)
        self.count_label.setStyleSheet("color: #0366d6; padding: 2px 8px;")
        self.status.addPermanentWidget(self.count_label)

        # ---- 显示地图 ----
        self._show_map()

        # ---- 数据 ----
        self.waypoints_px = []   # [(px, py), ...]

        # ---- 提示 ----
        self.status.showMessage(
            "左键添加 | 右键删除 | 滚轮缩放 | 中键拖拽 | Enter 完成",
            0)

    # =================================================================
    # 地图加载
    # =================================================================

    def _load_map(self, yaml_path):
        if not os.path.exists(yaml_path):
            QMessageBox.critical(self, "错误", f"地图文件不存在:\n{yaml_path}")
            sys.exit(1)

        with open(yaml_path, 'r') as f:
            self.map_meta = yaml.safe_load(f)

        self.resolution = float(self.map_meta['resolution'])
        self.origin_x = float(self.map_meta['origin'][0])
        self.origin_y = float(self.map_meta['origin'][1])

        yaml_dir = os.path.dirname(os.path.abspath(yaml_path))
        pgm_path = os.path.join(yaml_dir, self.map_meta['image'])
        if not os.path.exists(pgm_path):
            QMessageBox.critical(self, "错误", f"PGM 文件不存在:\n{pgm_path}")
            sys.exit(1)

        # 读取 PGM（P5 二进制或 P2 文本格式）
        self.pgm_data = self._read_pgm(pgm_path)
        self.img_h, self.img_w = self.pgm_data.shape

        print(f"地图: {self.img_w}x{self.img_h} 像素, "
              f"分辨率 {self.resolution}m/pix")
        print(f"范围: X [{self.origin_x:.2f}, "
              f"{self.origin_x + self.img_w * self.resolution:.2f}], "
              f"Y [{self.origin_y:.2f}, "
              f"{self.origin_y + self.img_h * self.resolution:.2f}]")

    def _read_pgm(self, path):
        """读取 PGM（支持 P2 ASCII / P5 二进制）"""
        with open(path, 'rb') as f:
            magic = f.readline().decode().strip()
            line = f.readline().decode().strip()
            while line.startswith('#'):
                line = f.readline().decode().strip()
            w, h = map(int, line.split())
            maxval = int(f.readline().decode().strip())

            if magic == 'P5':
                data = np.frombuffer(f.read(), dtype=np.uint8).reshape(h, w)
            elif magic == 'P2':
                # ASCII PGM
                raw = b''
                for line in f:
                    raw += line
                data = np.array(raw.decode().split(), dtype=np.uint8).reshape(h, w)
            else:
                raise ValueError(f"Unsupported PGM format: {magic}")

        # 如果 maxval != 255，做归一化
        if maxval != 255:
            data = (data.astype(np.float32) / maxval * 255).astype(np.uint8)
        return data

    # =================================================================
    # 显示
    # =================================================================

    def _show_map(self):
        """将 PGM 数组转为 QPixmap 显示"""
        h, w = self.pgm_data.shape

        # 构建 RGBA 图像：障碍物=红色半透明叠层
        rgba = np.zeros((h, w, 4), dtype=np.uint8)
        gray = self.pgm_data

        # 基础灰度
        rgba[:, :, 0] = gray
        rgba[:, :, 1] = gray
        rgba[:, :, 2] = gray
        rgba[:, :, 3] = 255

        # 障碍物区域（值 < 65）：红色叠层
        obstacle_mask = gray <= 50
        rgba[obstacle_mask, 0] = 220
        rgba[obstacle_mask, 1] = 50
        rgba[obstacle_mask, 2] = 50
        rgba[obstacle_mask, 3] = 255

        # 未知区域（值 50~250）：淡黄色叠层
        unknown_mask = (gray > 50) & (gray < 250)
        rgba[unknown_mask, 0] = np.clip(gray[unknown_mask] + 60, 0, 255)
        rgba[unknown_mask, 1] = np.clip(gray[unknown_mask] + 50, 0, 255)
        rgba[unknown_mask, 2] = np.clip(gray[unknown_mask] + 0, 0, 255)

        qimg = QImage(rgba.data, w, h, w * 4, QImage.Format_RGBA8888)
        pixmap = QPixmap.fromImage(qimg)
        self.map_item = QGraphicsPixmapItem(pixmap)
        self.map_item.setZValue(0)
        self.scene.addItem(self.map_item)

        # 场景范围
        self.scene.setSceneRect(QRectF(0, 0, w, h))
        self.view.fitInView(self.scene.sceneRect(), Qt.KeepAspectRatio)

        # 航点绘图层
        self.waypoint_items = []    # QGraphicsEllipseItem
        self.line_item = QGraphicsLineItem()
        self.line_item.setPen(QPen(QColor(255, 80, 80), 2, Qt.DashLine))
        self.line_item.setZValue(10)
        self.scene.addItem(self.line_item)

        # 当前悬停十字线
        self.cross_h = QGraphicsLineItem()
        self.cross_h.setPen(QPen(QColor(0, 200, 255, 180), 1, Qt.DashLine))
        self.cross_h.setZValue(20)
        self.cross_v = QGraphicsLineItem()
        self.cross_v.setPen(QPen(QColor(0, 200, 255, 180), 1, Qt.DashLine))
        self.cross_v.setZValue(20)
        self.scene.addItem(self.cross_h)
        self.scene.addItem(self.cross_v)

    # =================================================================
    # 坐标工具
    # =================================================================

    def px_to_world(self, px, py):
        """像素坐标 → 地图世界坐标"""
        x = self.origin_x + px * self.resolution
        y = self.origin_y + (self.img_h - py) * self.resolution
        return x, y

    def world_to_px(self, wx, wy):
        """地图世界坐标 → 像素坐标"""
        px = int((wx - self.origin_x) / self.resolution)
        py = int(self.img_h - (wy - self.origin_y) / self.resolution)
        return px, py

    def check_pixel(self, px, py):
        """
        检查像素是否安全（free / unknown / occupied）
        返回: 'free', 'unknown', 'occupied'
        """
        if px < 0 or px >= self.img_w or py < 0 or py >= self.img_h:
            return 'out_of_bounds'
        val = self.pgm_data[py, px]
        if val <= 50:
            return 'occupied'
        elif val < 250:
            return 'unknown'
        else:
            return 'free'

    def check_footprint_safe(self, px, py, margin_px=8):
        """
        检查以 (px,py) 为中心、margin 半径内是否全部 free。
        margin_px=8 对应 ~0.4m（0.05m/pix），覆盖 senior 4wd 的 footprint。
        """
        x1, x2 = max(0, px - margin_px), min(self.img_w, px + margin_px + 1)
        y1, y2 = max(0, py - margin_px), min(self.img_h, py + margin_px + 1)
        region = self.pgm_data[y1:y2, x1:x2]

        n_occ = int(np.sum(region <= 50))
        n_unk = int(np.sum((region > 50) & (region < 250)))
        n_free = int(np.sum(region >= 250))

        center_val = self.pgm_data[py, px]
        return {
            'center': 'free' if center_val >= 250 else
                      ('unknown' if center_val > 50 else 'occupied'),
            'occupied': n_occ,
            'unknown': n_unk,
            'free': n_free,
            'total': region.size,
        }

    # =================================================================
    # 交互回调
    # =================================================================

    def update_cursor_pos(self, px, py):
        """鼠标移动 → 更新状态栏坐标"""
        if px < 0 or px >= self.img_w or py < 0 or py >= self.img_h:
            self.coord_label.setText(" X: ---   Y: ---")
            self.pixel_label.setText(" 像素: (---, ---)  值: ---")
            self.zone_label.setText("")
            self.cross_h.setLine(0, 0, 0, 0)
            self.cross_v.setLine(0, 0, 0, 0)
            return

        wx, wy = self.px_to_world(px, py)
        val = self.pgm_data[int(py), int(px)]

        # 坐标显示
        self.coord_label.setText(f" X: {wx:7.2f}   Y: {wy:7.2f}")

        # 像素信息
        self.pixel_label.setText(f" 像素: ({int(px)}, {int(py)})  值: {val}")

        # 区域安全状态
        info = self.check_footprint_safe(int(px), int(py))
        n_occ = info['occupied']
        n_unk = info['unknown']

        if n_occ > 0:
            self.zone_label.setText(f"⚠ 障碍物! ({n_occ}像素)")
            self.zone_label.setStyleSheet(
                "color: #fff; background: #d73a49; padding: 2px 12px; border-radius: 4px;")
        elif n_unk > info['total'] * 0.3:
            self.zone_label.setText(f"⚠ 未知区域 ({n_unk}像素)")
            self.zone_label.setStyleSheet(
                "color: #333; background: #ffd33d; padding: 2px 12px; border-radius: 4px;")
        else:
            self.zone_label.setText("✓ 安全")
            self.zone_label.setStyleSheet(
                "color: #fff; background: #28a745; padding: 2px 12px; border-radius: 4px;")

        # 悬停十字线
        self.cross_h.setLine(0, py, self.img_w, py)
        self.cross_v.setLine(px, 0, px, self.img_h)

    # =================================================================
    # 航点操作
    # =================================================================

    def _add_waypoint(self, px, py):
        info = self.check_footprint_safe(px, py)

        if info['occupied'] > 0:
            # 有障碍物，弹确认框
            reply = QMessageBox.warning(
                self, "⚠ 障碍物区域",
                f"该位置 {info['occupied']} 个像素为障碍物！\n"
                f"机器人 footprint 可能无法在此处安全停靠。\n\n"
                f"是否仍然添加？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.No:
                return
        elif info['unknown'] > info['total'] * 0.3:
            reply = QMessageBox.question(
                self, "⚠ 未知区域",
                f"该位置 {info['unknown']}/{info['total']} 像素为未知区域。\n"
                f"导航可能失败。\n\n"
                f"是否仍然添加？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.No:
                return

        self.waypoints_px.append((px, py))
        wx, wy = self.px_to_world(px, py)
        print(f"  ✅ 添加 #{len(self.waypoints_px)}: "
              f"像素({px},{py}) → 地图({wx:.2f}, {wy:.2f})")

        self._redraw_waypoints()
        self.count_label.setText(f" 已选: {len(self.waypoints_px)} 个点")

    def _remove_last(self):
        if not self.waypoints_px:
            return
        removed = self.waypoints_px.pop()
        print(f"  ❌ 删除 #{len(self.waypoints_px)+1}: "
              f"像素({removed[0]},{removed[1]})")
        self._redraw_waypoints()
        self.count_label.setText(f" 已选: {len(self.waypoints_px)} 个点")

    def _redraw_waypoints(self):
        # 清除旧的
        for item in self.waypoint_items:
            self.scene.removeItem(item)
        self.waypoint_items.clear()

        if not self.waypoints_px:
            self.line_item.setLine(0, 0, 0, 0)
            return

        # 画连接线
        pts = [QPointF(p[0], p[1]) for p in self.waypoints_px]
        if len(pts) > 1:
            self.line_item.setLine(
                pts[0].x(), pts[0].y(),
                pts[-1].x(), pts[-1].y())
        else:
            self.line_item.setLine(0, 0, 0, 0)

        # 画航点圆圈
        for i, (px, py) in enumerate(self.waypoints_px):
            r = 5
            ellipse = QGraphicsEllipseItem(px - r, py - r, r * 2, r * 2)
            ellipse.setZValue(15)
            ellipse.setPen(QPen(QColor(255, 50, 50), 2))
            ellipse.setBrush(QBrush(QColor(255, 100, 100, 180)))
            ellipse.setToolTip(f"#{i+1}: 像素({px},{py})")
            self.scene.addItem(ellipse)
            self.waypoint_items.append(ellipse)

    # =================================================================
    # 输出
    # =================================================================

    def _finish(self):
        if not self.waypoints_px:
            print("\n未选择任何航点。")
            self.close()
            return

        print("\n" + "=" * 55)
        print(" 复制以下内容到 mission.yaml 的 waypoints 部分：")
        print("=" * 55)
        print("  waypoints:")
        for i, (px, py) in enumerate(self.waypoints_px):
            wx, wy = self.px_to_world(px, py)
            info = self.check_footprint_safe(px, py)
            tag = ""
            if info['occupied'] > 0:
                tag = "  # ⚠ 有障碍物!"
            elif info['unknown'] > info['total'] * 0.3:
                tag = "  # ⚠ 未知区域"
            print(f"    - {{x: {wx:.2f}, y: {wy:.2f}, yaw: 0.0}}{tag}")
        print("=" * 55)

        self.close()


def main(args=None):
    parser = argparse.ArgumentParser(
        description='Qt 地图巡航点选择工具 - 实时显示坐标，检测障碍物')
    parser.add_argument('map_yaml', type=str, help='地图 YAML 文件路径')
    parsed, _ = parser.parse_known_args()

    app = QApplication(sys.argv)
    app.setStyle('Fusion')

    picker = WaypointPicker(parsed.map_yaml)
    picker.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
