#!/usr/bin/env python3
"""
一键启动：摄像头 + YOLO EM 空间加权推理
规范写法：调用包内注册节点，不直接执行py脚本
用法：
    ros2 launch yolo_inference yolo_inference.launch.py
"""
import os

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    # 1. 启动底盘相机
    camera_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('turn_on_wheeltec_robot'),
                'launch',
                'wheeltec_camera.launch.py'
            )
        )
    )

    # 2. 启动YOLO推理节点（标准调用包内注册可执行文件）
    yolo_infer_node = Node(
        package="yolo_inference",
        executable="yolo_em_infer",
        name="yolo_em_infer_node",
        output="screen",
        emulate_tty=True
    )

    return LaunchDescription([
        camera_launch,
        yolo_infer_node
    ])
