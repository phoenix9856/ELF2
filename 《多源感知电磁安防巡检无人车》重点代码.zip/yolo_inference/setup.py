import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'yolo_inference'

# 基于 setup.py 所在目录定位文件，再转为相对路径（colcon 要求）
_pkg_dir = os.path.dirname(os.path.abspath(__file__))
_launch_rel = [os.path.relpath(f, _pkg_dir) for f in glob(os.path.join(_pkg_dir, 'launch', '*.launch.py'))]
_config_rel = [os.path.relpath(f, _pkg_dir) for f in glob(os.path.join(_pkg_dir, 'config', '*.yaml'))]

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), _launch_rel),
        (os.path.join('share', package_name, 'config'), _config_rel),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='elf',
    maintainer_email='elf@wheeltec.com',
    description='ELF2 YOLO inference node with EM spatial weighting (RKNN NPU)',
    license='Apache License 2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'yolo_em_infer = yolo_inference.yolo_em_infer_node:main',
        ],
    },
)
