#!/usr/bin/env python3
"""
ELF2 YOLO + EM 空间加权推理节点（拍照版）
=============================================
模式：  MODE='auto' → 每帧自动推理 | MODE='trigger' → 外部 Empty 触发
触发：  订阅 /start_yolo_inference (Empty)  —— trigger 模式使用
拍照：  订阅 /capture_photo (Empty)          —— 保存带 EM 加权置信度框的图片
结果：  发布 /yolo_inference_results (String, JSON)
拍照结果：发布 /capture_photo_result (String, JSON) → {"path": "...", "success": bool}
可视化：ENABLE_VIS = True 时弹出 OpenCV 窗口

置信度分离设计：
  - raw_score  (原始模型置信度) → 用于视觉跟踪判断（不受 EM 权重影响）
  - display_score (EM 空间加权置信度) → 用于照片展示（中心×1.0 → 边缘×0.3）
  - best_target 按 raw_score 选择，确保跟踪不受电磁强度干扰
"""
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

import cv2
import numpy as np
import time
import json
import os
import threading
from datetime import datetime
from std_msgs.msg import Empty, String
from rknnlite.api import RKNNLite

# ================= 配置参数 =================
MODEL_PATH = '/home/elf/YOLO/best.rknn'      # ⚠️ ROS 2 运行需要绝对路径
CLASSES_PATH = '/home/elf/YOLO/test.txt'
IMG_SIZE = (640, 640)      # ⚠️ 必须与模型训练输入尺寸一致（640→307200 vs 1228800）
CONF_THRES = 0.45        # 最终 NMS 原始置信度阈值
IOU_THRES = 0.45
# ============================================

# ===== 相机话题（按实际相机发布的话题名修改）=====
CAMERA_TOPIC = '/camera/color/image_raw'  # Astra / USB 常用
# CAMERA_TOPIC = '/color/image_raw'       # 部分 Astra 固件用这个
# CAMERA_TOPIC = '/rgb/image_raw'         # 备选
# ===============================================

# ===== 空间置信度加权（高斯函数，图像中心 = 最高权重） =====
# 始终启用，用于照片展示的 display_score
# 视觉跟踪使用 raw_score，不受此权重影响
# weight(x) = MIN_WEIGHT + (MAX_WEIGHT - MIN_WEIGHT) * exp(-0.5 * ((x - center) / (sigma * img_w))^2)
ENABLE_SPATIAL_WEIGHT = True    # 始终计算 EM 空间权重
SIGMA = 0.20
MIN_WEIGHT = 0.3     # 边缘权重（最低）
MAX_WEIGHT = 1.0     # 中间置信度权重（最高）
# ===========================================================

# ===== 推理模式 & 可视化 =====
MODE = 'trigger'        # 'trigger'=外部 Empty 触发 | 'auto'=每帧自动推理
ENABLE_VIS = False      # OpenCV 调试窗口（生产环境关闭提帧率）
# =============================

# ===== 解码参数 =====
PRE_NMS_CONF = 0.10     # 解码预过滤阈值（太低浪费 NMS 计算，太高丢失候选）
FIRST_NMS_CONF = 0.30   # 第一次 NMS 原始置信度阈值（跟踪门槛）
# ====================

# ===== 拍照参数 =====
PHOTO_SAVE_DIR = os.path.expanduser('~/elf2_photos')   # 照片保存目录
PHOTO_COOLDOWN_S = 5.0   # 拍照冷却时间（秒），防止连拍
# ====================


# ---------------------------------------------------------------------------
#  工具函数
# ---------------------------------------------------------------------------
def load_classes(path):
    with open(path, 'r') as f:
        return [line.strip() for line in f.readlines()]


def letterbox(im, new_shape=(640, 640), color=(114, 114, 114)):
    shape = im.shape[:2]
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]
    dw /= 2
    dh /= 2
    if shape[::-1] != new_unpad:
        im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    im = cv2.copyMakeBorder(im, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)
    return im, r, (dw, dh)


def decode_predictions(outputs, img_h, img_w, ratio, pad_w, pad_h, classes, pre_nms_conf=PRE_NMS_CONF):
    predictions = np.squeeze(outputs[0])
    if predictions.shape[0] < predictions.shape[1]:
        predictions = predictions.T

    candidates = []
    for pred in predictions:
        box = pred[0:4]
        class_scores = pred[4:]
        class_id = int(np.argmax(class_scores))
        score = float(class_scores[class_id])

        cx, cy, w, h = box
        cx = (cx - pad_w) / ratio
        cy = (cy - pad_h) / ratio
        w = w / ratio
        h = h / ratio
        x_min = cx - (w / 2)
        y_min = cy - (h / 2)

        if score >= pre_nms_conf:
            candidates.append({
                'class': classes[class_id],
                'class_id': class_id,
                'score': score,              # 原始模型置信度 (raw_score)
                'box': [int(x_min), int(y_min), int(w), int(h)],
                'center_x': float(cx)
            })
    return candidates


def compute_spatial_weight(center_x, img_w, sigma=SIGMA, min_weight=MIN_WEIGHT, max_weight=MAX_WEIGHT):
    """高斯空间加权：中心最高(1.0) → 边缘最低(0.3)，梯度递减。
    当 ENABLE_SPATIAL_WEIGHT=False 时，统一返回 1.0（不做空间加权）。"""
    if not ENABLE_SPATIAL_WEIGHT:
        return 1.0
    dx = (center_x - (img_w / 2.0)) / (sigma * img_w)
    weight = min_weight + (max_weight - min_weight) * np.exp(-0.5 * dx * dx)
    return float(weight)


def fuse_and_nms(candidates, img_w, sigma=SIGMA, min_weight=MIN_WEIGHT, max_weight=MAX_WEIGHT,
                 conf_thres=CONF_THRES, iou_thres=IOU_THRES):
    """空间加权 + NMS（NMS 使用 raw_score，跟踪不受 EM 影响）。
    返回: (results, fused_list)
      results[i].score          = raw_score（用于跟踪）
      results[i].display_score  = EM 加权置信度（用于照片展示）
      results[i].spatial_weight = 空间权重系数
    """
    # 1) 计算 display_score 和 spatial_weight
    fused = []
    for c in candidates:
        raw_score = float(c['score'])
        weight = compute_spatial_weight(c['center_x'], img_w, sigma, min_weight, max_weight)
        fc = c.copy()
        fc['raw_score'] = raw_score
        fc['display_score'] = min(raw_score * weight, 0.999)
        fc['spatial_weight'] = float(weight)
        fused.append(fc)

    # 2) NMS 使用 raw_score（不受 EM 权重影响）
    boxes, raw_scores, indices_map = [], [], []
    for i, c in enumerate(fused):
        if c['raw_score'] > conf_thres:
            boxes.append(c['box'])
            raw_scores.append(c['raw_score'])
            indices_map.append(i)

    results = []
    if boxes:
        inds = cv2.dnn.NMSBoxes(boxes, raw_scores, conf_thres, iou_thres)
        if len(inds) > 0:
            for idx in inds.flatten():
                map_i = indices_map[idx]
                sel = fused[map_i]
                results.append({
                    'class': sel['class'],
                    'score': sel['raw_score'],              # 原始置信度 → 跟踪用
                    'display_score': sel['display_score'],  # EM 加权 → 照片展示用
                    'box': sel['box'],
                    'spatial_weight': float(sel['spatial_weight'])
                })
    return results, fused


def nms_filter_candidates(candidates, conf_thresh=FIRST_NMS_CONF, iou_thres=0.5):
    """第一次 NMS 过滤，使用原始置信度（不受 EM 影响）"""
    if not candidates:
        return []
    boxes, scores = [], []
    for c in candidates:
        boxes.append(c['box'])
        scores.append(float(c['score']))

    indices_map, boxes_f, scores_f = [], [], []
    for i, s in enumerate(scores):
        if s >= conf_thresh:
            boxes_f.append(boxes[i])
            scores_f.append(s)
            indices_map.append(i)

    if not boxes_f:
        return []
    try:
        inds = cv2.dnn.NMSBoxes(boxes_f, scores_f, conf_thresh, iou_thres)
    except Exception:
        return [candidates[i] for i in indices_map]
    if len(inds) == 0:
        return []

    result = []
    for idx in inds.flatten():
        result.append(candidates[indices_map[idx]])
    return result


def draw_em_zone(img, img_w, img_h, sigma, min_wt, max_wt):
    """Draw two thin green lines marking the EM hot-zone boundaries."""
    cx = img_w // 2
    half_w = int(sigma * img_w)

    # 左右两条绿线标出热区边界
    cv2.line(img, (cx - half_w, 0), (cx - half_w, img_h), (0, 255, 0), 1)
    cv2.line(img, (cx + half_w, 0), (cx + half_w, img_h), (0, 255, 0), 1)

    # 顶部小标签
    cv2.putText(img, f"center x{max_wt:.1f}", (cx - 40, 18),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 1, cv2.LINE_AA)
    cv2.putText(img, f"edge x{min_wt:.1f}", (cx + half_w + 4, 18),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1, cv2.LINE_AA)
    return img


def draw_detections_on_image(img, detections, best_target=None, meta=None):
    """在图像上绘制检测框 + EM 加权置信度 + 深度信息。
    - 红框：最终检测（标注 display_score = EM 加权置信度）
    - 绿粗框：最佳跟踪目标
    - 顶部/底部信息栏：时间戳、深度、目标距离
    meta: {"depth_m": 0.32, "target_depth": 0.3, "reason": "first_detection"}
    """
    if meta is None:
        meta = {}
    img_h, img_w = img.shape[:2]

    # EM 热区标记
    img = draw_em_zone(img, img_w, img_h, SIGMA, MIN_WEIGHT, MAX_WEIGHT)

    # 最终检测（红框 + display_score）
    for d in (detections or []):
        try:
            bx = d.get('box', [])
            if len(bx) >= 4:
                x, y, bw_, bh_ = bx
                display_sc = d.get('display_score', d.get('score', 0))
                sw = d.get('spatial_weight', 0)
                label = f"{d.get('class','')} ds:{display_sc:.2f} sw:{sw:.1f}"
                cv2.rectangle(img, (x, y), (x + bw_, y + bh_), (0, 0, 255), 2)
                cv2.putText(img, label, (x, max(0, y - 6)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
        except Exception:
            pass

    # 最佳目标（绿色粗框）
    if best_target:
        try:
            bx = best_target.get('box', [])
            if len(bx) >= 4:
                x, y, bw_, bh_ = bx
                display_sc = best_target.get('display_score', best_target.get('score', 0))
                label = f"TARGET {best_target.get('class','')} ds:{display_sc:.2f}"
                cv2.rectangle(img, (x, y), (x + bw_, y + bh_), (0, 255, 0), 3)
                cv2.putText(img, label, (x, max(0, y - 10)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        except Exception:
            pass

    # ---- 信息叠加 ----
    # 顶部：时间 + 检测数
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    cv2.putText(img, f"ELF2 | {ts} | dets: {len(detections or [])}",
                (8, 16), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)

    # 底部：深度信息
    lines = []
    depth_m = meta.get('depth_m')
    target_d = meta.get('target_depth')
    if depth_m is not None:
        lines.append(f"depth: {depth_m:.2f}m")
        if target_d is not None:
            err = depth_m - target_d
            lines.append(f"target: {target_d:.2f}m  err: {err:+.2f}m")
    if meta.get('reason'):
        lines.append(f"reason: {meta['reason']}")

    for i, line in enumerate(lines):
        y = img_h - 10 - (len(lines) - 1 - i) * 18
        cv2.putText(img, line, (8, y), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)

    return img


# ---------------------------------------------------------------------------
#  节点
# ---------------------------------------------------------------------------
class YoloRknnNode(Node):
    def __init__(self):
        super().__init__('yolo_rknn_node')
        self.bridge = CvBridge()

        # ---- 类别 & NPU ----
        self.classes = load_classes(CLASSES_PATH)
        self.get_logger().info(f"加载类别: {self.classes}")

        self.rknn = RKNNLite()
        self.get_logger().info("加载 RKNN 模型...")
        if self.rknn.load_rknn(MODEL_PATH) != 0:
            self.get_logger().error("加载 RKNN 模型失败！")
            return
        if self.rknn.init_runtime() != 0:
            self.get_logger().error("初始化运行环境失败！")
            return
        self.get_logger().info("RKNN 引擎就绪")

        # ---- 图像缓存（摄像头持续写入，触发时读取最新帧） ----
        self._latest_img = None
        self._latest_img_ts = 0.0
        self._img_lock = threading.Lock()
        self.create_subscription(Image, CAMERA_TOPIC, self._img_cache_cb, 10)

        # ---- 推理触发 & 结果发布 ----
        self.create_subscription(Empty, '/start_yolo_inference', self._inference_trigger_cb, 10)
        self.result_pub = self.create_publisher(String, '/yolo_inference_results', 10)

        # ---- 拍照触发 & 结果发布 ----
        # 拍照触发：String 类型，含深度信息 JSON（由 tracker 发送）
        self.create_subscription(String, '/capture_photo', self._capture_photo_cb, 10)
        self.photo_result_pub = self.create_publisher(String, '/capture_photo_result', 10)

        # auto 模式防重入 + 缓存上一次推理结果
        self._busy = False
        self._busy_lock = threading.Lock()
        self._last_raw_dets = []
        self._last_final_dets = []
        self._last_best_target = None    # 缓存最近一次最佳目标（拍照用）

        # 跳过计数
        self._skipped_triggers = 0
        # 拍照冷却
        self._last_photo_time = 0.0

        # 确保照片保存目录存在
        os.makedirs(PHOTO_SAVE_DIR, exist_ok=True)

        self.get_logger().info(
            f"YOLO 节点就绪（模式: {MODE}），"
            f"{'自动推理中' if MODE == 'auto' else '等待 /start_yolo_inference ...'}"
        )
        self.get_logger().info(
            f"EM 空间加权: {'启用' if ENABLE_SPATIAL_WEIGHT else '关闭'} | "
            f"跟踪用 raw_score | 照片用 display_score (中心×{MAX_WEIGHT}→边缘×{MIN_WEIGHT})"
        )
        self.get_logger().info(f"照片保存目录: {PHOTO_SAVE_DIR}")

    # ------------------------------------------------------------------
    #  回调
    # ------------------------------------------------------------------
    def _img_cache_cb(self, msg):
        """缓存最新帧；auto 模式触发推理；始终刷新可视化窗口"""
        try:
            cv_img = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except CvBridgeError as e:
            if not getattr(self, '_enc_warned', False):
                self.get_logger().warn(
                    f"cv_bridge 转换失败（编码: {msg.encoding}），"
                    f"可能需要检查相机话题: {e}"
                )
                self._enc_warned = True
            return

        if cv_img is None or cv_img.shape[0] == 0 or cv_img.shape[1] == 0:
            if not getattr(self, '_size_warned', False):
                self.get_logger().warn(f"收到空图像 (shape={getattr(cv_img, 'shape', 'None')})")
                self._size_warned = True
            return

        with self._img_lock:
            self._latest_img = cv_img
            self._latest_img_ts = time.time()

        if MODE == 'auto':
            self._run_inference()

        if ENABLE_VIS:
            self._draw_overlay(cv_img, self._last_raw_dets, self._last_final_dets)

    def _inference_trigger_cb(self, msg):
        """外部 Empty 触发（trigger 模式）"""
        self._run_inference()

    def _capture_photo_cb(self, msg):
        """拍照触发：保存带 EM 加权置信度 + 深度信息标注的图片"""
        # 解析 tracker 发来的 JSON（含深度信息）
        meta = {}
        try:
            meta = json.loads(msg.data) if msg.data else {}
        except json.JSONDecodeError:
            pass

        now = time.time()
        if now - self._last_photo_time < PHOTO_COOLDOWN_S:
            self.get_logger().info(
                f"拍照冷却中（{now - self._last_photo_time:.1f}s < {PHOTO_COOLDOWN_S}s），跳过"
            )
            self.photo_result_pub.publish(String(data=json.dumps({
                "success": False,
                "error": "cooldown",
                "cooldown_remaining": round(PHOTO_COOLDOWN_S - (now - self._last_photo_time), 1)
            })))
            return

        with self._img_lock:
            if self._latest_img is None:
                self.get_logger().warn("拍照失败：无可用图像")
                self.photo_result_pub.publish(String(data=json.dumps({
                    "success": False,
                    "error": "no_image_available"
                })))
                return
            img = self._latest_img.copy()

        dets = list(self._last_final_dets) if self._last_final_dets else []
        best = self._last_best_target

        if not dets:
            self.get_logger().warn("拍照：当前无检测结果，保存原始图像")

        annotated = draw_detections_on_image(img, dets, best, meta)

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        depth_str = f"_{meta['depth_m']:.2f}m" if meta.get('depth_m') is not None else ""
        reason_str = f"_{meta.get('reason', '')}" if meta.get('reason') else ""
        filename = f"elf2_car{reason_str}{depth_str}_{timestamp}.jpg".replace('__', '_')
        filepath = os.path.join(PHOTO_SAVE_DIR, filename)

        try:
            cv2.imwrite(filepath, annotated)
            self._last_photo_time = now
            depth_info = f" depth={meta['depth_m']}m" if meta.get('depth_m') else ""
            self.get_logger().info(
                f"📷 照片已保存: {filepath} "
                f"（{len(dets)}个目标{depth_info}）"
            )
            self.photo_result_pub.publish(String(data=json.dumps({
                "success": True,
                "path": filepath,
                "filename": filename,
                "num_detections": len(dets),
                "has_best_target": best is not None,
                "depth_m": meta.get('depth_m'),
                "reason": meta.get('reason')
            })))
        except Exception as e:
            self.get_logger().error(f"照片保存失败: {e}")
            self.photo_result_pub.publish(String(data=json.dumps({
                "success": False,
                "error": str(e)
            })))

    def _run_inference(self):
        """执行一次完整推理并发布结果（auto/trigger 共用）。
        防重入：如果上一次推理还在跑，发布错误信息而非静默丢弃。"""
        with self._busy_lock:
            if self._busy:
                self._skipped_triggers += 1
                if self._skipped_triggers % 10 == 1:
                    self.get_logger().warn(
                        f"推理忙碌，已跳过 {self._skipped_triggers} 次触发 "
                        f"（NPU 推理耗时过长或触发频率过高）"
                    )
                self.result_pub.publish(String(data=json.dumps({
                    "error": "inference_busy",
                    "skipped_count": self._skipped_triggers
                })))
                return
            self._busy = True
            self._skipped_triggers = 0

        try:
            with self._img_lock:
                if self._latest_img is None:
                    self.get_logger().warn("触发推理时无可用图像，跳过")
                    self.result_pub.publish(String(data=json.dumps({
                        "error": "no_image_available"
                    })))
                    return
                cv_image = self._latest_img.copy()
                img_ts = self._latest_img_ts

            t_start = time.time()
            img_h, img_w = cv_image.shape[:2]

            # ---- NPU 推理 ----
            img, ratio, (pad_w, pad_h) = letterbox(cv_image, IMG_SIZE)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img = np.expand_dims(img, 0)

            outputs = self.rknn.inference(inputs=[img])
            inf_ms = (time.time() - t_start) * 1000.0

            # 防御：推理失败返回 None 时跳过本次
            if outputs is None:
                self.get_logger().error(
                    "RKNN 推理返回 None（可能输入尺寸与模型不匹配），跳过本次推理"
                )
                self.result_pub.publish(String(data=json.dumps({
                    "error": "rknn_inference_returned_none",
                    "hint": "Check IMG_SIZE matches model input size"
                })))
                return

            # ---- 解码 & 第一次 NMS（raw_score ≥ 0.30） ----
            raw_candidates = decode_predictions(outputs, img_h, img_w, ratio, pad_w, pad_h,
                                                self.classes, pre_nms_conf=PRE_NMS_CONF)
            raw_filtered = nms_filter_candidates(raw_candidates, conf_thresh=FIRST_NMS_CONF, iou_thres=0.5)

            # ---- 空间加权 & 第二次 NMS（NMS 使用 raw_score，输出含 display_score） ----
            final_dets, _fused = fuse_and_nms(
                raw_filtered, img_w,
                sigma=SIGMA, min_weight=MIN_WEIGHT, max_weight=MAX_WEIGHT,
                conf_thres=CONF_THRES, iou_thres=IOU_THRES
            )

            # ---- 最佳目标（按 raw_score 选择，不受 EM 权重影响） ----
            best_target = None
            if final_dets:
                best = max(final_dets, key=lambda r: r["score"])  # score = raw_score
                bx, by, bw_, bh_ = best["box"]
                best_target = {
                    "class": best["class"],
                    "score": best["score"],                       # raw_score → 跟踪用
                    "display_score": best["display_score"],       # EM 加权 → 照片展示
                    "center_x": bx + bw_ / 2.0,
                    "center_y": by + bh_ / 2.0,
                    "box": best["box"],
                    "spatial_weight": best["spatial_weight"]
                }

            total_ms = (time.time() - t_start) * 1000.0

            # ---- 组装 & 发布 ----
            result = {
                "timestamp": img_ts,
                "total_time_ms": round(total_ms, 2),
                "inference_time_ms": round(inf_ms, 2),
                "image_size": [img_w, img_h],
                "spatial_config": {
                    "enabled": ENABLE_SPATIAL_WEIGHT,
                    "sigma": SIGMA,
                    "min_weight": MIN_WEIGHT,
                    "max_weight": MAX_WEIGHT,
                    "note": "tracking uses raw_score; photo uses display_score (raw × EM weight)"
                },
                "num_detections": len(final_dets),
                "detections": final_dets,
                "best_target": best_target
            }

            self.result_pub.publish(String(data=json.dumps(result)))

            self.get_logger().info(
                f"推理完成 → 检出 {len(final_dets)} 目标 | "
                f"耗时 {total_ms:.1f}ms (推理 {inf_ms:.1f}ms)"
            )
            if best_target:
                self.get_logger().info(
                    f"  最佳: {best_target['class']} "
                    f"@({best_target['center_x']:.0f},{best_target['center_y']:.0f}) "
                    f"raw={best_target['score']:.2f} display={best_target['display_score']:.2f} "
                    f"sw={best_target['spatial_weight']:.1f}"
                )

            # ---- 缓存本次推理结果 ----
            self._last_raw_dets = raw_filtered
            self._last_final_dets = final_dets
            self._last_best_target = best_target

            # ---- 可视化 ----
            if ENABLE_VIS:
                self._draw_overlay(cv_image, raw_filtered, final_dets)

        except Exception as e:
            self.get_logger().error(
                f"推理异常: {type(e).__name__}: {e}，已发布错误结果"
            )
            self.result_pub.publish(String(data=json.dumps({
                "error": "inference_exception",
                "exception_type": type(e).__name__,
                "exception_msg": str(e)
            })))

        finally:
            with self._busy_lock:
                self._busy = False

    # ------------------------------------------------------------------
    #  可视化（调试窗口）
    # ------------------------------------------------------------------
    def _draw_overlay(self, cv_image, raw_dets, final_dets):
        img = cv_image.copy()
        img_h, img_w = img.shape[:2]

        img = draw_em_zone(img, img_w, img_h, SIGMA, MIN_WEIGHT, MAX_WEIGHT)

        # 预过滤候选（蓝框）
        for d in (raw_dets or []):
            try:
                bx = d.get('box', [])
                if len(bx) >= 4:
                    x, y, bw_, bh_ = bx
                    label = f"{d.get('class','')} {d.get('score',0):.2f}"
                    cv2.rectangle(img, (x, y), (x + bw_, y + bh_), (255, 128, 0), 1)
                    cv2.putText(img, label, (x, max(0, y - 6)),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 128, 0), 1)
            except Exception:
                pass

        # 最终检测（红框 + 展示 display_score）
        for d in (final_dets or []):
            try:
                bx = d.get('box', [])
                if len(bx) >= 4:
                    x, y, bw_, bh_ = bx
                    display_sc = d.get('display_score', d.get('score', 0))
                    sw = d.get('spatial_weight', 0)
                    label = f"{d.get('class','')} ds:{display_sc:.2f} sw:{sw:.1f}"
                    cv2.rectangle(img, (x, y), (x + bw_, y + bh_), (0, 0, 255), 2)
                    cv2.putText(img, label, (x, max(0, y - 6)),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
            except Exception:
                pass

        cv2.imshow('ELF2 YOLO + EM', img)
        cv2.waitKey(1)

    def destroy_node(self):
        self.get_logger().info("释放 NPU 资源...")
        try:
            self.rknn.release()
        except Exception:
            pass
        if ENABLE_VIS:
            cv2.destroyAllWindows()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = YoloRknnNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
