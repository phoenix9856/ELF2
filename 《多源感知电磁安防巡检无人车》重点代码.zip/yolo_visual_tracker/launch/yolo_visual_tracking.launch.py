#!/usr/bin/env python3
"""
YOLO视觉跟随一键启动
启动底盘相机 + YOLO推理 + 视觉跟踪节点
"""
import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
from launch_ros.actions import Node

def generate_launch_description():
    # 1. 启动底盘相机
    camera_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('turn_on_wheeltec_robot'),
                'launch',
                'wheeltec_camera.launch.py'
            )
        )
    )

    # 2. 启动YOLO推理节点
    yolo_infer_node = Node(
        package="yolo_inference",
        executable="yolo_em_infer",
        name="yolo_em_infer_node",
        output="screen",
        emulate_tty=True
    )

    # 3. 启动视觉跟踪节点，不加载yaml参数
    tracker_node = Node(
        package="yolo_visual_tracker",
        executable="visual_tracker_node",
        output="screen",
        name="yolo_visual_tracker"
    )

    return LaunchDescription([
        camera_launch,
        yolo_infer_node,
        tracker_node
    ])