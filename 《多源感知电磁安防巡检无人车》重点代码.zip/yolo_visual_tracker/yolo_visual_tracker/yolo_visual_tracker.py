#!/usr/bin/env python3
"""
ELF2 YOLO 视觉跟随节点（深度测距版 + PD控制 + 安全保护）
增加状态发布 /visual_tracking_state
优化：连续丢失 5 帧 YOLO 结果再判定丢失，避免频繁切换射频
"""

import json
import time
import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Empty, String
from sensor_msgs.msg import Image, CameraInfo
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge, CvBridgeError


class YoloVisualTracker(Node):
    # ------------------ 状态定义 ------------------
    STATE_IDLE = 0
    STATE_TRACKING = 1

    # ------------------ 宏定义参数（统一固定参数）------------------
    DEFAULT_KP_ANG = 0.4
    DEFAULT_KD_ANG = 0.15
    DEFAULT_MAX_ANG = 0.35
    DEFAULT_KP_LIN = 0.8
    DEFAULT_KD_LIN = 0.2
    DEFAULT_MAX_LIN = 0.5
    DEFAULT_TARGET_DEPTH = 0.3
    DEFAULT_DEPTH_DEADZONE = 0.08
    DEFAULT_MIN_SAFE_DEPTH = 0.15
    DEFAULT_TARGET_CLASS = "car"
    DEFAULT_SCORE_THRESHOLD = 0.3
    DEFAULT_PERIODIC_PHOTO_INTERVAL = 10.0
    DEFAULT_MAX_LOST_FRAMES = 5

    DT = 0.02
    YOLO_TRIGGER_INTERVAL = 0.05
    DIAG_HEARTBEAT_INTERVAL = 5.0
    PHOTO_COOLDOWN_INTERVAL = 5.0

    def __init__(self):
        super().__init__("yolo_visual_tracker")

        # ---------- ROS 参数（YAML / 命令行可覆盖） ----------
        self.declare_parameter("kp_ang", self.DEFAULT_KP_ANG)
        self.declare_parameter("kd_ang", self.DEFAULT_KD_ANG)
        self.declare_parameter("max_ang", self.DEFAULT_MAX_ANG)
        self.declare_parameter("kp_lin", self.DEFAULT_KP_LIN)
        self.declare_parameter("kd_lin", self.DEFAULT_KD_LIN)
        self.declare_parameter("max_lin", self.DEFAULT_MAX_LIN)
        self.declare_parameter("target_depth", self.DEFAULT_TARGET_DEPTH)
        self.declare_parameter("depth_deadzone", self.DEFAULT_DEPTH_DEADZONE)
        self.declare_parameter("min_safe_depth", self.DEFAULT_MIN_SAFE_DEPTH)
        self.declare_parameter("target_class", self.DEFAULT_TARGET_CLASS)
        self.declare_parameter("score_threshold", self.DEFAULT_SCORE_THRESHOLD)
        self.declare_parameter("periodic_photo_interval", self.DEFAULT_PERIODIC_PHOTO_INTERVAL)
        self.declare_parameter("max_lost_frames", self.DEFAULT_MAX_LOST_FRAMES)

        self.kp_ang = self.get_parameter("kp_ang").value
        self.kd_ang = self.get_parameter("kd_ang").value
        self.max_ang = self.get_parameter("max_ang").value
        self.kp_lin = self.get_parameter("kp_lin").value
        self.kd_lin = self.get_parameter("kd_lin").value
        self.max_lin = self.get_parameter("max_lin").value
        self.target_depth = self.get_parameter("target_depth").value
        self.depth_deadzone = self.get_parameter("depth_deadzone").value
        self.min_safe_depth = self.get_parameter("min_safe_depth").value
        self.target_class = self.get_parameter("target_class").value
        self.score_thresh = self.get_parameter("score_threshold").value
        self.periodic_photo_interval = self.get_parameter("periodic_photo_interval").value
        self.max_lost_frames = self.get_parameter("max_lost_frames").value

        # ---------- 状态变量 ----------
        self.state = self.STATE_IDLE
        self.prev_state = -1
        self.yolo_result = None
        self.img_w = 640
        self.img_h = 480
        self.depth_w = 640
        self.depth_h = 400
        self._depth_info_received = False
        self._consecutive_lost_frames = 0
        self._photo_cooldown_deadline = None
        self._last_photo_time = None
        self._last_yolo_trigger_time = None
        self._last_diag_time = None
        self._last_error_x = 0.0
        self._last_depth_error = 0.0
        self._latest_depth_m = None
        self._loop_time = time.time()

        self.bridge = CvBridge()
        self.depth_image = None
        self.depth_ready = False

        self._cnt_yolo_rcv = 0
        self._cnt_yolo_error = 0
        self._cnt_depth_rcv = 0
        self._cnt_servo = 0
        self._cnt_cmd = 0
        self._cnt_photo = 0
        self._cnt_safe_stop = 0
        self._diag_tick = 0

        # ---------- ROS 接口 ----------
        self.start_sub = self.create_subscription(Empty, "/start_visual_tracking", self.start_callback, 10)
        self.stop_sub = self.create_subscription(Empty, "/stop_visual_tracking", self.stop_callback, 10)
        self.yolo_trigger_pub = self.create_publisher(Empty, "/start_yolo_inference", 10)
        self.yolo_result_sub = self.create_subscription(String, "/yolo_inference_results", self.yolo_result_callback, 10)
        self.depth_sub = self.create_subscription(Image, "/camera/depth/image_raw", self.depth_callback, 10)
        self.depth_info_sub = self.create_subscription(CameraInfo, "/camera/depth/camera_info", self.depth_info_callback, 10)
        self.cmd_vel_pub = self.create_publisher(Twist, "/cmd_vel", 10)
        self.photo_trigger_pub = self.create_publisher(String, "/capture_photo", 10)
        self.state_pub = self.create_publisher(String, "/visual_tracking_state", 10)

        # 主循环 50Hz
        self.timer = self.create_timer(self.DT, self.state_loop)

        self.get_logger().info("=" * 60)
        self.get_logger().info("YOLO 视觉跟踪器（PD控制 + 安全保护）")
        self.get_logger().info(f"目标: {self.target_class}  raw≥{self.score_thresh}")
        self.get_logger().info(f"偏航 PD: kp={self.kp_ang} kd={self.kd_ang} max={self.max_ang}rad/s")
        self.get_logger().info(f"距离 PD: kp={self.kp_lin} kd={self.kd_lin} max={self.max_lin}m/s")
        self.get_logger().info(f"跟随距离: {self.target_depth}m  死区±{self.depth_deadzone}m  安全限{self.min_safe_depth}m")
        self.get_logger().info(f"连续丢失 {self.max_lost_frames} 帧后判定目标丢失")
        self.get_logger().info(f"定期拍照: 每{self.periodic_photo_interval}s | 冷却{self.PHOTO_COOLDOWN_INTERVAL:.0f}s")
        self.get_logger().info("=" * 60)

    # ===================== 状态机主循环 =====================
    def state_loop(self):
        self._loop_time = time.time()

        match self.state:
            case self.STATE_IDLE:
                if self._last_diag_time is None or (self._loop_time - self._last_diag_time) >= self.DIAG_HEARTBEAT_INTERVAL:
                    self._last_diag_time = self._loop_time
                    self.diag_heartbeat()

                # 初次进入逻辑
                if self.state != self.prev_state:
                    self.stop_car()
                    self.prev_state = self.state

            case self.STATE_TRACKING:
                if self._last_diag_time is None or (self._loop_time - self._last_diag_time) >= self.DIAG_HEARTBEAT_INTERVAL:
                    self._last_diag_time = self._loop_time
                    self.diag_heartbeat()

                if self._last_yolo_trigger_time is None or (self._loop_time - self._last_yolo_trigger_time) >= self.YOLO_TRIGGER_INTERVAL:
                    self._last_yolo_trigger_time = self._loop_time
                    self.yolo_trigger_pub.publish(Empty())

                if self._photo_cooldown_deadline is not None and self._loop_time >= self._photo_cooldown_deadline:
                    self._photo_cooldown_deadline = None

                # 初次进入逻辑
                if self.state != self.prev_state:
                    self.get_logger().info(">>> 进入视觉跟随 <<<")
                    self.prev_state = self.state
                    self._consecutive_lost_frames = 0
                    self._last_error_x = 0.0
                    self._last_depth_error = 0.0
                    self._last_photo_time = None
                    self.trigger_photo("first_detection")

                best_target = self.get_best_target()
                # 如果有有效目标，则进行视觉伺服控制
                if best_target is not None:
                    self.visual_servo(best_target)
                    if self._last_photo_time is None or (self._loop_time - self._last_photo_time) >= self.periodic_photo_interval:
                        self.trigger_photo("periodic")
                else:
                    # 否则，连续丢失计数 +1，并根据计数判断是否进入 IDLE
                    if self._consecutive_lost_frames == 1:
                        self.log_why_no_target()
                    if self._consecutive_lost_frames >= self.max_lost_frames:
                        self.get_logger().warn(
                            f"连续丢失 {self._consecutive_lost_frames} 帧目标，进入 IDLE"
                        )
                        self.stop_car()
                        self.state = self.STATE_IDLE
                    else:
                        self.stop_car()

        self.publish_state()

    # ===================== 回调函数 =====================
    def start_callback(self, msg):
        if self.state == self.STATE_IDLE:
            self.get_logger().info("收到启动 → 视觉跟随")
            self._consecutive_lost_frames = 0
            self._last_yolo_trigger_time = None
            self._last_diag_time = None
            self.state = self.STATE_TRACKING
        else:
            self.get_logger().info(f"已在状态{self.state}，忽略启动")

    def stop_callback(self, msg):
        if self.state != self.STATE_IDLE:
            self.get_logger().info("收到停止 → IDLE")
            self.stop_car()
            self.state = self.STATE_IDLE
        else:
            self.get_logger().info("已在 IDLE，忽略停止")

    def yolo_result_callback(self, msg):
        try:
            data = json.loads(msg.data)
            if "error" in data:
                self._cnt_yolo_error += 1
                if self._cnt_yolo_error <= 3:
                    self.get_logger().warn(f"YOLO 错误: {data['error']}")
                self._consecutive_lost_frames += 1
                return

            self.yolo_result = data
            self._cnt_yolo_rcv += 1

            if "image_size" in data:
                self.img_w = data["image_size"][0]
                self.img_h = data["image_size"][1]

            best = data.get("best_target")
            has_valid_target = False
            if best is not None:
                if (best.get("score", 0) >= self.score_thresh
                        and best.get("class", "") == self.target_class):
                    has_valid_target = True

            if has_valid_target:
                self._consecutive_lost_frames = 0
            else:
                self._consecutive_lost_frames += 1

            if self._cnt_yolo_rcv <= 5:
                bt = data.get("best_target")
                nd = data.get("num_detections", 0)
                self.get_logger().info(
                    f"[YOLO#{self._cnt_yolo_rcv}] 检出={nd} | "
                    f"best={'YES' if bt else 'NONE'} | {self.img_w}x{self.img_h}"
                )
                if bt:
                    self.get_logger().info(
                        f"  best: {bt.get('class')} raw={bt.get('score',0):.3f} "
                        f"ds={bt.get('display_score',0):.3f} "
                        f"cx={bt.get('center_x',0):.0f}"
                    )
        except Exception as e:
            self.get_logger().error(f"JSON 解析失败: {e}")
            self._consecutive_lost_frames += 1

    def depth_callback(self, msg):
        try:
            cv_depth = self.bridge.imgmsg_to_cv2(msg, desired_encoding="passthrough")
        except CvBridgeError as e:
            if not getattr(self, "_depth_enc_warned", False):
                self.get_logger().warn(f"深度图编码 {msg.encoding}: {e}")
                self._depth_enc_warned = True
            return
        if cv_depth is None or cv_depth.shape[0] == 0:
            return
        self.depth_image = cv_depth
        if not self._depth_info_received:
            self.depth_h, self.depth_w = cv_depth.shape[:2]
        self.depth_ready = True
        self._cnt_depth_rcv += 1
        if self._cnt_depth_rcv == 1:
            src = "CameraInfo" if self._depth_info_received else "图像回退"
            self.get_logger().info(
                f"深度图就绪: {self.depth_w}×{self.depth_h} "
                f"编码={msg.encoding} dtype={cv_depth.dtype} ({src})"
            )

    def depth_info_callback(self, msg):
        self.depth_w = msg.width
        self.depth_h = msg.height
        self._depth_info_received = True
        self.get_logger().info(f"深度内参就绪: {self.depth_w}×{self.depth_h}")
        self.destroy_subscription(self.depth_info_sub)
        self.depth_info_sub = None

    # ===================== 内部工具函数 =====================
    def maybe_trigger_yolo(self):
        if self._last_yolo_trigger_time is None or (self._loop_time - self._last_yolo_trigger_time) >= self.YOLO_TRIGGER_INTERVAL:
            self._last_yolo_trigger_time = self._loop_time
            self.yolo_trigger_pub.publish(Empty())

    def publish_state(self):
        if self.state == self.STATE_IDLE:
            state_str = "IDLE"
        elif self.state == self.STATE_TRACKING:
            state_str = "TRACKING"
        else:
            state_str = "UNKNOWN"
        self.state_pub.publish(String(data=state_str))

    def _state_to_str(self):
        return {
            self.STATE_IDLE: "IDLE",
            self.STATE_TRACKING: "TRACKING",
        }.get(self.state, f"UNKNOWN({self.state})")

    def visual_servo(self, best_target):
        cx = best_target["center_x"]
        error_x = (self.img_w / 2.0 - cx) / (self.img_w / 2.0)
        d_error_x = (error_x - self._last_error_x) / self.DT
        ang_z = self.kp_ang * error_x + self.kd_ang * d_error_x
        ang_z = max(-self.max_ang, min(self.max_ang, ang_z))
        self._last_error_x = error_x

        depth_m = self.read_depth_at(cx, best_target["center_y"])

        if depth_m is not None and 0 < depth_m < self.min_safe_depth:
            self.publish_cmd(0.0, 0.0)
            self._cnt_safe_stop += 1
            if self._cnt_safe_stop % 10 == 1:
                self.get_logger().warn(
                    f"⚠ 安全停车: depth={depth_m:.2f}m < {self.min_safe_depth}m"
                )
            return

        if depth_m is not None and depth_m > 0.1:
            depth_error = depth_m - self.target_depth
            if abs(depth_error) < self.depth_deadzone:
                lin_x = 0.0
            else:
                abs_err = abs(depth_error)
                if abs_err > 0.5:
                    scale = 1.4
                elif abs_err < 0.15:
                    scale = 0.6
                else:
                    scale = 1.0
                d_depth_error = (depth_error - self._last_depth_error) / self.DT
                lin_x = self.kp_lin * scale * depth_error + self.kd_lin * d_depth_error
                lin_x = max(-self.max_lin, min(self.max_lin, lin_x))
            self._last_depth_error = depth_error
            self._latest_depth_m = depth_m
        else:
            lin_x = 0.0
            depth_m = -1.0
            self._last_depth_error = 0.0

        self.publish_cmd(lin_x, ang_z)
        self._cnt_servo += 1

        if self._cnt_servo % 17 == 1:
            depth_str = f"{depth_m:.2f}m" if depth_m and depth_m > 0 else "无效"
            self.get_logger().info(
                f"[跟随] {best_target['class']} "
                f"raw={best_target.get('score',0):.2f} "
                f"err_x={error_x:+.2f}→ang={ang_z:+.2f} "
                f"depth={depth_str}"
                f"{'→lin='+str(round(lin_x,2)) if depth_m and depth_m>0 else ''}"
            )

    def read_depth_at(self, color_cx, color_cy):
        if self.depth_image is None:
            return None
        dx = int(color_cx)
        dy = int(color_cy * self.depth_h / self.img_h)
        dx = max(0, min(self.depth_w - 1, dx))
        dy = max(0, min(self.depth_h - 1, dy))
        r = 1
        y0, y1 = max(0, dy - r), min(self.depth_h - 1, dy + r)
        x0, x1 = max(0, dx - r), min(self.depth_w - 1, dx + r)
        patch = self.depth_image[y0:y1+1, x0:x1+1]
        valid = patch[patch > 0]
        if len(valid) == 0:
            return None
        return float(np.median(valid)) / 1000.0

    def trigger_photo(self, reason="unknown"):
        now = time.time()
        if self._photo_cooldown_deadline is not None and now < self._photo_cooldown_deadline:
            return
        depth_val = round(self._latest_depth_m, 2) if self._latest_depth_m else None
        photo_msg = String()
        photo_msg.data = json.dumps({
            "reason": reason,
            "depth_m": depth_val,
            "target_depth": self.target_depth,
            "target_class": self.target_class
        })
        self.photo_trigger_pub.publish(photo_msg)
        self._photo_cooldown_deadline = now + self.PHOTO_COOLDOWN_INTERVAL
        self._last_photo_time = now
        self._cnt_photo += 1
        self.get_logger().info(f"📷 拍照 #{self._cnt_photo} ({reason})" +
                               (f" depth={depth_val}m" if depth_val else ""))

    def get_best_target(self):
        if self.yolo_result is None:
            return None
        best = self.yolo_result.get("best_target")
        if best is None:
            return None
        if best.get("score", 0) < self.score_thresh:
            return None
        if best.get("class", "") != self.target_class:
            return None
        return best

    def log_why_no_target(self):
        if self.yolo_result is None:
            self.get_logger().warn("  ↳ yolo_result=None")
        elif self.yolo_result.get("best_target") is None:
            nd = self.yolo_result.get("num_detections", 0)
            self.get_logger().warn(f"  ↳ best_target=None（检出{nd}个）")
        else:
            bt = self.yolo_result["best_target"]
            if bt.get("score", 0) < self.score_thresh:
                self.get_logger().warn(f"  ↳ raw={bt['score']:.2f} < {self.score_thresh}")
            elif bt.get("class", "") != self.target_class:
                self.get_logger().warn(f"  ↳ class='{bt['class']}' ≠ '{self.target_class}'")

    def diag_heartbeat(self):
        state_names = {0: "IDLE", 1: "TRACKING"}
        depth_status = f"{self._cnt_depth_rcv}帧" if self.depth_ready else "⚠未收到"
        safe_info = f" 安全停车{self._cnt_safe_stop}次" if self._cnt_safe_stop else ""
        yolo_status = "无数据"
        if self.yolo_result is not None:
            bt = self.yolo_result.get("best_target")
            if bt:
                yolo_status = f"{bt.get('class')} raw={bt.get('score',0):.2f}"
            else:
                yolo_status = f"检出{self.yolo_result.get('num_detections',0)}个"
        self.get_logger().info(
            f"[诊断] {state_names[self.state]} | 连续丢失帧: {self._consecutive_lost_frames}/{self.max_lost_frames} | "
            f"YOLO×{self._cnt_yolo_rcv} 深度×{depth_status}{safe_info} | "
            f"伺服×{self._cnt_servo} cmd×{self._cnt_cmd} 📷×{self._cnt_photo} | "
            f"目标: {yolo_status}"
        )

    def publish_cmd(self, lin_x, ang_z):
        twist = Twist()
        twist.linear.x = lin_x
        twist.angular.z = ang_z
        self.cmd_vel_pub.publish(twist)
        self._cnt_cmd += 1

    def stop_car(self):
        self.publish_cmd(0.0, 0.0)

    def destroy_node(self):
        self.stop_car()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = YoloVisualTracker()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()